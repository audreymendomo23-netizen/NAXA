# Messagerie client ↔ pharmacie, notifications et profil client (12 octobre 2026)

Migration candidate `supabase/migration_076_messagerie_profil_client.sql` (non appliquée en Production), test `supabase/tests/076_messagerie_profil_client.sql`. Compteurs CI : 90 migrations, 59 tests.

## Modèle
- `fils_messages` : un fil par couple client × pharmacie. Lisible uniquement par le client ; la pharmacie n'y accède jamais directement (l'identité reste protégée).
- `messages_pharmacie` : messages (1 à 1000 caractères). Lecture : le client du fil ou le personnel de la pharmacie (`can_access_pharmacy`). Aucune écriture directe : tout passe par les RPC.
- `notifications` : destinataire = un client (`user_id`) ou une pharmacie (`pharmacie_id`).
- `client_preferences` : adresse, quartier, mode et numéro de paiement (6XXXXXXXX), langue, alertes, anonymat par défaut, note et avis sur l'app.
- RPC : `envoyer_message_client` (limite 20 messages/heure), `repondre_message` (client ou pharmacie), `marquer_fil_lu`, `boite_pharmacie` (libellé « Client anonyme » si demandé, jamais d'identifiant client).

## Parcours
1. Résultats (`/resultats`) : lien vers l'offre `/offre/[pharmacie]/[produit]` + bouton « Contacter ».
2. Offre : en-tête et onglets conservés, prix/stock réels, quantité plafonnée au stock, ajout au panier existant, bulle « Contacter la pharmacie » (message + « Rester anonyme », coché par défaut selon la préférence).
3. Pharmacie : reçoit une notification et lit/répond dans `/pharmacie/messages`.
4. Client : la cloche (compteur) mène à `/notifications` ; il lit et répond dans le fil, en temps réel (Supabase Realtime).
5. Profil (`/client?onglet=profil`) : menu Adresse, Paiement, Langue, Historique (→ Achats), Factures (achats payés/retirés, impression PDF), Centre d'aide (FAQ), Contacter NAXA, Noter l'app, Notifications, Confidentialité, Déconnexion. Pages : `/client/profil/[section]`.
6. Contacter NAXA : Gmail (`mailto:naxa.home@gmail.com`, objet et corps préremplis) et WhatsApp (`wa.me/237681972237`, message prêt à envoyer). Constantes dans `src/lib/contact-naxa.ts`.

## Limites connues
- Alerte téléphone : aujourd'hui `Notification` du navigateur (application ouverte ou en arrière-plan). Pour une vraie push application fermée : Web Push (clés VAPID, table d'abonnements, service worker, envoi serveur). Non réalisé.
- Mentions de la maquette non reprises (règles produit) : Douala, livraison, promo, avis/notes de pharmacies (aucune donnée), téléphone de pharmacie (privé).
- Onglet Langue : seul le français est traduit.
- Non compilé ni testé en navigateur (pas de `node_modules`) : `npm install && npm run build` requis ; migration à rejouer en préproduction.
