/** Joue le mouvement de recherche de la loupe du header, puis lance immédiatement la navigation.
 *  Le header client reste affiché sur /resultats : l'animation se poursuit sans retarder la page. */
export function lancerRechercheAnimee(aller: () => void): void {
  if (typeof window !== "undefined" && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    window.dispatchEvent(new CustomEvent("naxa:recherche-lancee"));
  }
  aller();
}
