import Link from "next/link";
import { redirect } from "next/navigation";
import { supabaseServer } from "@/lib/supabase/server";
import { creerPharmacie } from "./actions";
import { ImportAdmin } from "@/components/ImportAdmin";
import { Logo } from "@/components/Logo";

export default async function Admin({ searchParams }: { searchParams: { ok?: string; erreur?: string } }) {
  const sb = supabaseServer();
  const { data: u } = await sb.auth.getUser();
  if (!u.user) redirect("/connexion?retour=/admin");
  const { data: p } = await sb.from("profiles").select("role").eq("id", u.user.id).single();
  if (p?.role !== "admin") redirect("/");
  const { data: pharmacies } = await sb.from("pharmacies").select("id,nom,quartier,stock_updated_at").order("created_at", { ascending: false });

  const champ = "champ mt-1";
  return (
    <main className="mx-auto max-w-2xl space-y-6 px-4 pb-16">
      <header className="-mx-4 flex items-center justify-between bg-naxa-green-900 px-4 py-3 text-white"><Logo taille={32} /><span className="font-semibold">Équipe NAXA</span></header>
      {searchParams.ok && <p role="status" className="carte bg-naxa-green-100">Pharmacie créée. Transmettez-lui son e-mail et son mot de passe provisoire pendant la formation.</p>}
      {searchParams.erreur && <p role="alert" className="carte text-red-700">La création a échoué ({searchParams.erreur}). Vérifiez les champs.</p>}

      <form action={creerPharmacie} className="carte space-y-3">
        <h1 className="text-xl font-extrabold">Créer une pharmacie</h1>
        <label className="block text-sm font-semibold">Nom<input name="nom" required className={champ} /></label>
        <div className="grid grid-cols-2 gap-3">
          <label className="block text-sm font-semibold">Ville<input name="ville" defaultValue="Yaoundé" className={champ} /></label>
          <label className="block text-sm font-semibold">Quartier<input name="quartier" className={champ} /></label>
        </div>
        <label className="block text-sm font-semibold">Adresse<input name="adresse" className={champ} /></label>
        <div className="grid grid-cols-2 gap-3">
          <label className="block text-sm font-semibold">Latitude<input name="lat" type="number" step="any" required className={champ} placeholder="3.8480" /></label>
          <label className="block text-sm font-semibold">Longitude<input name="lng" type="number" step="any" required className={champ} placeholder="11.5021" /></label>
        </div>
        <p className="text-xs text-slate-600">Astuce : sur OpenStreetMap, clic droit sur la pharmacie puis « Afficher l'adresse » donne les coordonnées.</p>
        <label className="block text-sm font-semibold">WhatsApp de la pharmacie (ex. 2376XXXXXXXX, jamais affiché au client)<input name="whatsapp" required className={champ} /></label>
        <label className="block text-sm font-semibold">Code marchand (facultatif)<input name="code_marchand" className={champ} /></label>
        <label className="block text-sm font-semibold">E-mail de connexion<input name="email" type="email" required className={champ} /></label>
        <label className="block text-sm font-semibold">Mot de passe provisoire<input name="motdepasse" type="text" minLength={8} required className={champ} /></label>
        <button className="btn btn-vert w-full">Créer la pharmacie et son accès</button>
      </form>

      <Link href="/admin/produits" className="carte block font-bold underline underline-offset-4">Fiches produits : photos, descriptions, brouillons IA →</Link>

      <ImportAdmin pharmacies={(pharmacies ?? []).map((x) => ({ id: x.id, nom: x.nom }))} />

      <section className="carte">
        <h2 className="mb-2 text-lg font-bold">Pharmacies ({pharmacies?.length ?? 0})</h2>
        <ul className="space-y-1 text-sm">
          {pharmacies?.map((x) => <li key={x.id}>{x.nom} · {x.quartier} · {x.stock_updated_at ? "stock mis à jour " + new Date(x.stock_updated_at).toLocaleDateString("fr-FR") : "stock vide"}</li>)}
        </ul>
      </section>
    </main>
  );
}
