"use client";
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

export type LignePanier = { produit_id: string; nom: string; dosage: string; quantite: number };

const CLE = "naxa-panier-v1";
const MAX_LIGNES = 10;
const MAX_QTE = 10;

type Ctx = {
  lignes: LignePanier[];
  nombre: number;
  pret: boolean;
  ajouter: (l: Omit<LignePanier, "quantite">, quantite?: number) => void;
  changerQuantite: (produitId: string, quantite: number) => void;
  retirer: (produitId: string) => void;
  vider: () => void;
};

const PanierContext = createContext<Ctx | null>(null);

function lire(): LignePanier[] {
  try {
    const brut = localStorage.getItem(CLE);
    const liste = brut ? JSON.parse(brut) : [];
    return Array.isArray(liste) ? liste.filter((l) => l?.produit_id && l?.quantite > 0).slice(0, MAX_LIGNES) : [];
  } catch {
    return [];
  }
}

/** Le panier reste sur le téléphone (aucune donnée envoyée). Il ne sert qu'à chercher les pharmacies qui ont tout. */
export function PanierProvider({ children }: { children: React.ReactNode }) {
  const [lignes, setLignes] = useState<LignePanier[]>([]);
  const [pret, setPret] = useState(false);

  useEffect(() => {
    setLignes(lire());
    setPret(true);
    const sync = (e: StorageEvent) => e.key === CLE && setLignes(lire());
    window.addEventListener("storage", sync);
    return () => window.removeEventListener("storage", sync);
  }, []);

  const enregistrer = useCallback((suite: LignePanier[]) => {
    setLignes(suite);
    try { localStorage.setItem(CLE, JSON.stringify(suite)); } catch { /* stockage indisponible : le panier reste en mémoire */ }
  }, []);

  const ajouter: Ctx["ajouter"] = useCallback((l, quantite = 1) => {
    const base = lire();
    const existant = base.find((x) => x.produit_id === l.produit_id);
    if (existant) existant.quantite = Math.min(MAX_QTE, existant.quantite + quantite);
    else if (base.length < MAX_LIGNES) base.push({ ...l, quantite: Math.min(MAX_QTE, Math.max(1, quantite)) });
    enregistrer(base);
  }, [enregistrer]);

  const changerQuantite: Ctx["changerQuantite"] = useCallback((id, quantite) => {
    enregistrer(lire().map((x) => (x.produit_id === id ? { ...x, quantite: Math.min(MAX_QTE, Math.max(1, quantite)) } : x)));
  }, [enregistrer]);

  const retirer: Ctx["retirer"] = useCallback((id) => enregistrer(lire().filter((x) => x.produit_id !== id)), [enregistrer]);
  const vider = useCallback(() => enregistrer([]), [enregistrer]);

  const valeur = useMemo(
    () => ({ lignes, nombre: lignes.reduce((n, l) => n + l.quantite, 0), pret, ajouter, changerQuantite, retirer, vider }),
    [lignes, pret, ajouter, changerQuantite, retirer, vider]
  );
  return <PanierContext.Provider value={valeur}>{children}</PanierContext.Provider>;
}

export function usePanier(): Ctx {
  const c = useContext(PanierContext);
  if (!c) throw new Error("usePanier doit être utilisé dans PanierProvider");
  return c;
}

export { MAX_QTE, MAX_LIGNES };
