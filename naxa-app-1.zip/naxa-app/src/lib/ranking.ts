import type { PharmacieClassee, ResultatPharmacie, Trajet } from "./types";

export type Priorite = "equilibre" | "prix" | "proche" | "rapide";

const POIDS: Record<Priorite, { prix: number; distance: number; temps: number }> = {
  equilibre: { prix: 0.4, distance: 0.3, temps: 0.3 },
  prix: { prix: 0.7, distance: 0.15, temps: 0.15 },
  proche: { prix: 0.15, distance: 0.7, temps: 0.15 },
  rapide: { prix: 0.15, distance: 0.15, temps: 0.7 },
};

const norm = (v: number, min: number, max: number) => (max === min ? 0 : (v - min) / (max - min));

/** Classe les pharmacies : rapport prix / distance / temps d'arrivée. Les résultats complets passent avant les partiels. */
export function classer(
  liste: (ResultatPharmacie & { trajet: Trajet })[],
  priorite: Priorite = "equilibre"
): PharmacieClassee[] {
  if (!liste.length) return [];
  const prix = liste.map((p) => p.total_prix);
  const dist = liste.map((p) => p.trajet.km);
  const temps = liste.map((p) => p.trajet.minutes);
  const [pMin, pMax] = [Math.min(...prix), Math.max(...prix)];
  const [dMin, dMax] = [Math.min(...dist), Math.max(...dist)];
  const [tMin, tMax] = [Math.min(...temps), Math.max(...temps)];
  const w = POIDS[priorite];

  const complets = liste.filter((p) => p.trouves === p.demandes);
  const moinsCher = complets.length ? Math.min(...complets.map((p) => p.total_prix)) : null;
  const plusProche = Math.min(...dist);
  const plusRapide = Math.min(...temps);

  return liste
    .map((p) => {
      const penalite = w.prix * norm(p.total_prix, pMin, pMax) + w.distance * norm(p.trajet.km, dMin, dMax) + w.temps * norm(p.trajet.minutes, tMin, tMax);
      const badges: string[] = [];
      if (p.trouves === p.demandes && p.total_prix === moinsCher) badges.push("Meilleur prix");
      if (p.trajet.km === plusProche) badges.push("Plus proche");
      if (p.trajet.minutes === plusRapide) badges.push("Plus rapide");
      if (p.de_garde) badges.push("De garde");
      return { ...p, score: Math.round((1 - penalite) * 100), badges };
    })
    .sort((a, b) => Number(b.trouves === b.demandes) - Number(a.trouves === a.demandes) || b.score - a.score);
}

export function fraicheur(iso: string | null): string {
  if (!iso) return "Stock non daté";
  const min = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
  if (min < 1) return "Stock mis à jour à l'instant";
  if (min < 60) return `Stock mis à jour il y a ${min} min`;
  const h = Math.round(min / 60);
  if (h < 48) return `Stock mis à jour il y a ${h} h`;
  return `Stock mis à jour il y a ${Math.round(h / 24)} j`;
}

export const fcfa = (n: number) => `${n.toLocaleString("fr-FR")} FCFA`;
