import { supabaseBrowser } from "./supabase/client";

const clean = (s: unknown) => String(s ?? "").trim();
const cle = (s: string) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, "");
const NOM = ["nom", "designation", "produit", "libelle", "medicament", "article"];
const PRIX = ["prix", "pu", "prixvente", "prixdevente", "pvttc", "tarif"];
const QTE = ["quantite", "qte", "stock", "qtestock"];
const DOSAGE = ["dosage", "conditionnement"];
const PEREMPTION = ["peremption", "dateperemption", "expiration", "dlc"];

function trouver(row: Record<string, unknown>, cles: string[]) {
  for (const k of Object.keys(row)) if (cles.includes(cle(k))) return row[k];
  return "";
}

/** Importe un fichier Excel/CSV d'un ancien logiciel. Colonnes reconnues : nom, prix, quantité, dosage, péremption. */
export async function importerStock(file: File, pharmacieId: string) {
  const XLSX = await import("xlsx");
  const wb = XLSX.read(await file.arrayBuffer(), { cellDates: true });
  const lignes = XLSX.utils.sheet_to_json<Record<string, unknown>>(wb.Sheets[wb.SheetNames[0]], { defval: "" });

  const valides = lignes
    .map((r) => ({
      nom: clean(trouver(r, NOM)),
      dosage: clean(trouver(r, DOSAGE)),
      prix: Math.round(Number(String(trouver(r, PRIX)).replace(/\s/g, "").replace(",", "."))) || 0,
      quantite: Math.max(0, Math.round(Number(trouver(r, QTE))) || 0),
      per: trouver(r, PEREMPTION),
    }))
    .filter((r) => r.nom.length > 1 && r.prix > 0);

  const sb = supabaseBrowser();
  let importes = 0;
  for (let i = 0; i < valides.length; i += 200) {
    const lot = valides.slice(i, i + 200);
    const { data: produits, error } = await sb
      .from("produits")
      .upsert(lot.map((r) => ({ nom: r.nom, dosage: r.dosage })), { onConflict: "nom,dosage,forme", ignoreDuplicates: false })
      .select("id,nom,dosage");
    if (error) throw error;
    const index = new Map((produits ?? []).map((p) => [`${p.nom}|${p.dosage}`, p.id]));
    const stocks = lot
      .map((r) => ({
        pharmacie_id: pharmacieId,
        produit_id: index.get(`${r.nom}|${r.dosage}`),
        prix: r.prix,
        quantite: r.quantite,
        date_peremption: r.per instanceof Date ? r.per.toISOString().slice(0, 10) : null,
      }))
      .filter((s) => s.produit_id);
    const { error: e2 } = await sb.from("stocks").upsert(stocks, { onConflict: "pharmacie_id,produit_id" });
    if (e2) throw e2;
    importes += stocks.length;
  }
  return { lus: lignes.length, importes, ignores: lignes.length - valides.length };
}
