"use client";

import { useCallback, useEffect, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/client";

export type ProfilClient = {
  charge: boolean;
  connecte: boolean;
  estClient: boolean;
  prenom: string;
  nom: string;
  initiales: string;
  photoUrl: string | null;
  /** Règle NAXA : photo de profil configurée = utilisateur vérifié (coche bleue). */
  verifie: boolean;
};

const VIDE: ProfilClient = {
  charge: false,
  connecte: false,
  estClient: false,
  prenom: "",
  nom: "",
  initiales: "",
  photoUrl: null,
  verifie: false,
};

export function calculerInitiales(prenom: string, nom: string): string {
  const a = Array.from(prenom.trim())[0] ?? "";
  const b = Array.from(nom.trim())[0] ?? "";
  return (a + b).toLocaleUpperCase("fr") || "?";
}

export function useProfilClient(): ProfilClient & { rafraichir: () => Promise<void> } {
  const [profil, setProfil] = useState<ProfilClient>(VIDE);

  const rafraichir = useCallback(async () => {
    try {
      const sb = supabaseBrowser();
      const { data: auth } = await sb.auth.getUser();
      if (!auth.user) {
        setProfil({ ...VIDE, charge: true });
        return;
      }
      const { data: p } = await sb
        .from("profiles")
        .select("first_name,last_name,role,photo_profil_path")
        .eq("id", auth.user.id)
        .maybeSingle();
      const prenom = p?.first_name ?? "";
      const nom = p?.last_name ?? "";
      const chemin = (p?.photo_profil_path as string | null | undefined) ?? null;
      let photoUrl: string | null = null;
      if (chemin) {
        const { data: signee } = await sb.storage.from("profils-photos").createSignedUrl(chemin, 3600);
        photoUrl = signee?.signedUrl ?? null;
      }
      setProfil({
        charge: true,
        connecte: true,
        estClient: p?.role === "client",
        prenom,
        nom,
        initiales: calculerInitiales(prenom, nom),
        photoUrl,
        // Vérifié dès qu'une photo est configurée, même si l'URL signée échoue temporairement.
        verifie: Boolean(chemin),
      });
    } catch {
      setProfil({ ...VIDE, charge: true });
    }
  }, []);

  useEffect(() => {
    void rafraichir();
  }, [rafraichir]);

  return { ...profil, rafraichir };
}
