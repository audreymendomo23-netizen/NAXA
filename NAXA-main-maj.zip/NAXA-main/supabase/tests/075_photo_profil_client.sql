-- Test structurel migration_075 : photo de profil client / profil vérifié.
do $$
begin
  if not exists (select 1 from information_schema.columns where table_schema='public' and table_name='profiles' and column_name='photo_profil_path') then
    raise exception '075: colonne profiles.photo_profil_path absente';
  end if;
  if not exists (select 1 from storage.buckets where id='profils-photos' and public=false) then
    raise exception '075: bucket profils-photos absent ou public';
  end if;
  if not exists (select 1 from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname='definir_ma_photo_profil' and p.prosecdef) then
    raise exception '075: RPC definir_ma_photo_profil absente ou non security definer';
  end if;
  if has_function_privilege('anon','public.definir_ma_photo_profil(text)','execute') then
    raise exception '075: RPC exécutable par anon';
  end if;
end
$$;
