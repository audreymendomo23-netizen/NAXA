"use client";
import Link from "next/link";
import { Suspense, useEffect, useState } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/client";
import { fcfa } from "@/lib/ranking";
import { MAX_QTE, usePanier } from "@/lib/panier";
import { Logo } from "@/components/Logo";
import { BoutonNotifications } from "@/components/BoutonNotifications";
import { ContacterPharmacie } from "@/components/ContacterPharmacie";
type Ph = { nom: string; quartier: string | null; adresse: string | null; de_garde: boolean; horaires: string | null };
type Pr = { nom: string; dci: string; dosage: string; forme: string; photo_url: string | null; description: string | null };

function Offre() {
  const { pharmacieId, produitId } = useParams<{ pharmacieId: string; produitId: string }>(), router = useRouter(), km = useSearchParams().get("km");
  const { ajouter } = usePanier();
  const [ph, setPh] = useState<Ph | null>(null), [pr, setPr] = useState<Pr | null>(null), [stock, setStock] = useState<{ prix: number; quantite: number } | null>(null);
  const [qte, setQte] = useState(1), [ok, setOk] = useState(false), [chargé, setChargé] = useState(false);
  useEffect(() => { (async () => {
    const sb = supabaseBrowser();
    const [a, b, c] = await Promise.all([
      sb.from("pharmacies").select("nom,quartier,adresse,de_garde,horaires").eq("id", pharmacieId).maybeSingle(),
      sb.from("produits").select("nom,dci,dosage,forme,photo_url,description").eq("id", produitId).maybeSingle(),
      sb.from("stocks").select("prix,quantite").eq("pharmacie_id", pharmacieId).eq("produit_id", produitId).maybeSingle()]);
    setPh(a.data as Ph | null); setPr(b.data as Pr | null); setStock(c.data); setChargé(true);
  })(); }, [pharmacieId, produitId]);
  const dispo = stock?.quantite ?? 0;
  async function ajouterAuPanier() {
    const { data } = await supabaseBrowser().auth.getUser();
    if (!data.user) return router.push("/connexion?retour=" + encodeURIComponent(location.pathname));
    if (pr) { ajouter({ produit_id: produitId, nom: pr.nom, dosage: pr.dosage }, qte); setOk(true); }
  }
  return <main className="mx-auto min-h-screen max-w-2xl bg-slate-50 px-4 pb-32">
    <header className="-mx-4 mb-4 flex items-center justify-between bg-naxa-green-900 px-4 py-3"><button type="button" onClick={() => router.back()} aria-label="Retour" className="text-2xl text-white">←</button><Link href="/"><Logo taille={32} /></Link><BoutonNotifications /></header>
    {chargé && (!ph || !pr) ? <p className="carte">Cette offre n'est plus disponible.</p> : ph && pr && <>
      <section className="carte"><h1 className="text-xl font-extrabold">{ph.nom}</h1>
        <p className={"mt-1 text-sm font-semibold " + (ph.de_garde ? "text-naxa-green-700" : "text-slate-600")}>{ph.de_garde ? "● De garde aujourd'hui" : ph.horaires ?? "Horaires à confirmer"}</p>
        <p className="mt-1 text-sm">{[ph.quartier, ph.adresse].filter(Boolean).join(" · ")}</p>{km && <p className="text-sm text-slate-600">{Number(km).toFixed(1)} km</p>}</section>
      <section className="carte mt-3"><div className="flex gap-3">{pr.photo_url ? <img src={pr.photo_url} alt="" className="h-24 w-24 rounded-xl object-contain" /> : <div className="flex h-24 w-24 items-center justify-center rounded-xl bg-naxa-green-100 text-xs">NAXA</div>}
        <div><h2 className="text-lg font-extrabold">{pr.nom}</h2><p className="text-sm text-slate-600">{[pr.dci, pr.dosage, pr.forme].filter(Boolean).join(" · ")}</p>
          {dispo > 0 ? <p className="mt-1 inline-block rounded-full bg-naxa-green-100 px-2 py-0.5 text-xs font-bold">{dispo} boîte{dispo > 1 ? "s" : ""} · En stock</p> : <p className="mt-1 text-sm font-bold text-red-700">Rupture de stock</p>}
          {stock && <p className="mt-1 text-2xl font-black">{fcfa(stock.prix)}</p>}</div></div>
        {dispo > 0 && <div className="mt-3 flex items-center gap-2"><button type="button" className="btn btn-clair !px-0 w-12" aria-label="Moins" onClick={() => setQte(Math.max(1, qte - 1))}>−</button><output className="w-8 text-center text-xl font-extrabold">{qte}</output><button type="button" className="btn btn-clair !px-0 w-12" aria-label="Plus" onClick={() => setQte(Math.min(MAX_QTE, dispo, qte + 1))}>+</button></div>}</section>
      {pr.description && <section className="mt-4"><h2 className="text-lg font-extrabold">Description</h2><p className="text-sm">{pr.description}</p><p className="mt-1 text-xs font-semibold">Demandez conseil à votre pharmacien. NAXA n'indique jamais de dose.</p></section>}
      <section className="mt-4"><h2 className="text-lg font-extrabold">Disponibilité</h2><p className="text-sm text-slate-600">{dispo > 0 ? `En stock · ${dispo} boîte${dispo > 1 ? "s" : ""}` : "Indisponible actuellement"}</p></section>
      <button type="button" disabled={dispo < 1} className="btn btn-canari mt-5 w-full disabled:opacity-50" onClick={ajouterAuPanier}>Ajouter au panier</button>
      {ok && <p role="status" className="mt-2 text-sm">Ajouté. <Link href="/panier" className="font-semibold underline">Voir mon panier</Link></p>}
      <ContacterPharmacie pharmacieId={pharmacieId} produitId={produitId} /></>}
  </main>;
}
export default function Page() { return <Suspense fallback={null}><Offre /></Suspense>; }
