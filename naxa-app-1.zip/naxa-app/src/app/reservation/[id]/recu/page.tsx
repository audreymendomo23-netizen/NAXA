"use client";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/client";
import { fcfa } from "@/lib/ranking";
import { Logo } from "@/components/Logo";

type Ligne = { quantite: number; prix_unitaire: number; produits: { nom: string; dosage: string } | null };

export default function Recu() {
  const { id } = useParams<{ id: string }>();
  const [d, setD] = useState<{ r: { total: number; statut: string; paiement_ref: string | null; created_at: string; pharmacies: { nom: string } | null }; lignes: Ligne[] } | null>(null);

  useEffect(() => {
    (async () => {
      const sb = supabaseBrowser();
      const { data: r } = await sb.from("reservations").select("total,statut,paiement_ref,created_at,pharmacies(nom)").eq("id", id).single();
      const { data: l } = await sb.from("reservation_items").select("quantite,prix_unitaire,produits(nom,dosage)").eq("reservation_id", id);
      if (r) setD({ r: r as never, lignes: (l ?? []) as never });
    })();
  }, [id]);

  if (!d) return <main className="p-6">Chargement…</main>;
  return (
    <main className="mx-auto max-w-md space-y-4 p-6">
      <Logo clair={false} />
      <h1 className="text-xl font-extrabold">Reçu de réservation</h1>
      <p className="text-sm">N° {id.slice(0, 8).toUpperCase()} · {new Date(d.r.created_at).toLocaleString("fr-FR")}<br />Pharmacie : {d.r.pharmacies?.nom}<br />Référence de paiement : {d.r.paiement_ref ?? "—"}</p>
      <table className="w-full text-sm">
        <tbody>
          {d.lignes.map((l, i) => (
            <tr key={i} className="border-b"><td className="py-1">{l.quantite} × {l.produits?.nom} {l.produits?.dosage}</td><td className="py-1 text-right">{fcfa(l.prix_unitaire * l.quantite)}</td></tr>
          ))}
        </tbody>
      </table>
      <p className="text-right text-lg font-extrabold">Total : {fcfa(d.r.total)}</p>
      <button className="btn btn-vert no-print w-full" onClick={() => window.print()}>Imprimer ou enregistrer en PDF</button>
    </main>
  );
}
