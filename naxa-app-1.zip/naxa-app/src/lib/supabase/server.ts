import { createServerClient } from "@supabase/ssr";
import { createClient } from "@supabase/supabase-js";
import { cookies } from "next/headers";

/** Client serveur lié à la session de l'utilisateur (respecte la RLS). */
export function supabaseServer() {
  const store = cookies();
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll: () => store.getAll(),
        setAll: (list) => {
          try {
            list.forEach(({ name, value, options }) => store.set(name, value, options));
          } catch {
            /* appelé depuis un composant serveur : ignoré */
          }
        },
      },
    }
  );
}

/** Client administrateur : contourne la RLS. Serveur uniquement (numéros WhatsApp, codes marchand). */
export function supabaseAdmin() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

/** Client public (clé anonyme, sans session) pour des données publiques mises en cache (ex. bandeau « les plus recherchés »). */
export function supabasePublic(revalidateSecondes = 600) {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      auth: { persistSession: false },
      global: { fetch: (url, init) => fetch(url, { ...init, next: { revalidate: revalidateSecondes } }) },
    }
  );
}
