"use client";
import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/client";
import { Logo } from "@/components/Logo";

function Formulaire() {
  const router = useRouter();
  const retour = useSearchParams().get("retour") || "/";
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [envoye, setEnvoye] = useState(false);
  const [erreur, setErreur] = useState("");
  const [occupe, setOccupe] = useState(false);

  async function envoyer(e: React.FormEvent) {
    e.preventDefault();
    setOccupe(true); setErreur("");
    const { error } = await supabaseBrowser().auth.signInWithOtp({ email, options: { shouldCreateUser: true } });
    setOccupe(false);
    if (error) setErreur("Impossible d'envoyer le code. Vérifiez l'adresse e-mail et réessayez dans une minute.");
    else setEnvoye(true);
  }

  async function verifier(e: React.FormEvent) {
    e.preventDefault();
    setOccupe(true); setErreur("");
    const { error } = await supabaseBrowser().auth.verifyOtp({ email, token: code, type: "email" });
    setOccupe(false);
    if (error) setErreur("Code incorrect ou expiré. Demandez un nouveau code.");
    else { router.push(retour); router.refresh(); }
  }

  return (
    <form onSubmit={envoye ? verifier : envoyer} className="carte w-full max-w-sm space-y-4">
      <h1 className="text-2xl font-extrabold">Se connecter</h1>
      {!envoye ? (
        <>
          <label className="block text-sm font-semibold">Adresse e-mail
            <input className="champ mt-1" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
          </label>
          <button className="btn btn-vert w-full" disabled={occupe}>Recevoir mon code</button>
        </>
      ) : (
        <>
          <p className="text-sm text-slate-600">Un code a été envoyé à {email}.</p>
          <label className="block text-sm font-semibold">Code reçu
            <input className="champ mt-1 tracking-widest" inputMode="numeric" required value={code} onChange={(e) => setCode(e.target.value)} autoComplete="one-time-code" />
          </label>
          <button className="btn btn-vert w-full" disabled={occupe}>Valider</button>
        </>
      )}
      {erreur && <p role="alert" className="text-sm text-red-700">{erreur}</p>}
    </form>
  );
}

export default function Connexion() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-6 bg-naxa-green-900 px-5">
      <Logo />
      <Suspense><Formulaire /></Suspense>
    </main>
  );
}
