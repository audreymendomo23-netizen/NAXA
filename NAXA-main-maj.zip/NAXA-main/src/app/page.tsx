"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { EnTeteAccueil } from "@/components/EnTeteAccueil";
import { Recherche } from "@/components/Recherche";
import { supabaseBrowser } from "@/lib/supabase/client";
import { NAXA_WHATSAPP } from "@/lib/contact-naxa";
import { textes, type Langue } from "@/lib/accueil-textes";
import { coordonneesValides, distanceKm, formatKm, type Position } from "@/lib/distance";

type PharmacieAccueil = {
  id: string;
  nom: string;
  quartier: string | null;
  lat: number | null;
  lng: number | null;
  de_garde: boolean;
};

export default function Accueil() {
  const [langue, setLangue] = useState<Langue>("fr");
  const langueInitialisee = useRef(false);
  const [position, setPosition] = useState<Position | null>(null);
  const [pharmacies, setPharmacies] = useState<PharmacieAccueil[]>([]);
  const t = textes[langue];

  useEffect(() => {
    try {
      const sauvegardee = window.localStorage.getItem("naxa-langue");
      if (sauvegardee === "fr" || sauvegardee === "en") {
        setLangue(sauvegardee);
      } else if (window.navigator.language?.toLowerCase().startsWith("en")) {
        setLangue("en");
      }
    } catch {
      // La page reste utilisable si le stockage local est indisponible.
    } finally {
      langueInitialisee.current = true;
    }
  }, []);

  useEffect(() => {
    if (!langueInitialisee.current) return;
    try {
      window.localStorage.setItem("naxa-langue", langue);
    } catch {
      // La langue reste active pendant la session.
    }
    document.documentElement.lang = langue;
  }, [langue]);

  function localiser() {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (p) => setPosition({ lat: p.coords.latitude, lng: p.coords.longitude }),
      () => undefined,
      { maximumAge: 300000, timeout: 8000 },
    );
  }

  useEffect(() => {
    let annule = false;
    (async () => {
      try {
        const { data, error } = await supabaseBrowser()
          .from("pharmacies")
          .select("id,nom,quartier,lat,lng,de_garde")
          .eq("actif", true)
          .eq("de_garde", true)
          .limit(100);
        if (!annule && !error) setPharmacies((data ?? []) as PharmacieAccueil[]);
      } catch {
        // L'accueil reste utilisable : la recherche ne dépend pas de ce bloc.
      }
      // Distances automatiques seulement si la localisation est déjà autorisée (aucune fenêtre de demande).
      try {
        const etat = await navigator.permissions?.query({ name: "geolocation" });
        if (!annule && etat?.state === "granted") localiser();
      } catch {
        // API indisponible : le bouton « Afficher les distances » reste proposé.
      }
    })();
    return () => {
      annule = true;
    };
  }, []);

  const gardes = useMemo(() => {
    const liste = pharmacies.map((p) => ({
      ...p,
      km: position && coordonneesValides(p.lat, p.lng) ? distanceKm(position, p.lat as number, p.lng as number) : null,
    }));
    return liste.sort((a, b) => (a.km ?? Infinity) - (b.km ?? Infinity)).slice(0, 2);
  }, [pharmacies, position]);

  const lienPharmacien = `https://wa.me/${NAXA_WHATSAPP}?text=${encodeURIComponent(t.pharmacienMessage)}`;

  return (
    <main className="home-ecran flex flex-col bg-naxa-green-50">
      <EnTeteAccueil langue={langue} setLangue={setLangue} />

      <div className="relative z-10 mx-auto -mt-5 w-full max-w-xl shrink-0 px-4">
        <div className="carte !p-5">
          <Recherche langue={langue} />
        </div>
      </div>

      <div className="mx-auto flex min-h-0 w-full max-w-xl flex-1 flex-col gap-3 px-4 pt-4">
        <section aria-labelledby="titre-gardes">
          <div className="mb-2 flex items-center justify-between gap-3">
            <h2 id="titre-gardes" className="text-sm font-extrabold uppercase tracking-wide text-slate-600">
              {t.gardesAujourdhui}
            </h2>
            <Link href="/gardes" className="shrink-0 text-sm font-bold text-naxa-green-700 underline underline-offset-4">
              {t.voirTout}
            </Link>
          </div>
          {gardes.length === 0 ? (
            <p className="carte text-sm text-slate-600">{t.aucuneGarde}</p>
          ) : (
            <ul className="space-y-2">
              {gardes.map((p) => (
                <li key={p.id} className="carte flex items-center gap-3 !px-4 !py-3">
                  <span className="h-2.5 w-2.5 shrink-0 rounded-full bg-green-600" aria-hidden="true" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-extrabold text-naxa-green-900">{p.nom}</p>
                    <p className="truncate text-sm text-slate-600">
                      {[p.quartier, p.km !== null ? formatKm(p.km) : null].filter(Boolean).join(" · ")}
                    </p>
                  </div>
                  <span className="shrink-0 rounded-full bg-naxa-green-100 px-3 py-1 text-xs font-bold text-naxa-green-900">
                    {t.deGarde}
                  </span>
                </li>
              ))}
            </ul>
          )}
          {gardes.length > 0 && !position && (
            <button type="button" onClick={localiser} className="mt-1 text-xs font-semibold text-naxa-green-700 underline underline-offset-2">
              {t.afficherDistances}
            </button>
          )}
        </section>

        <p className="text-xs leading-snug text-slate-600">{t.avertissement}</p>
        <p className="text-sm text-slate-700">
          {t.pharmacienQuestion}{" "}
          <a href={lienPharmacien} target="_blank" rel="noopener noreferrer" className="font-extrabold text-naxa-green-700 underline underline-offset-4">
            {t.pharmacienLien}
          </a>
        </p>
      </div>

      <footer className="w-full shrink-0 bg-naxa-green-900 px-5 py-1.5 text-center text-xs font-semibold text-naxa-canari">
        {t.builtWith}
      </footer>
    </main>
  );
}
