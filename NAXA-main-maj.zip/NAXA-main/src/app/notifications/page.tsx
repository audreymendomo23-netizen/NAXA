"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/client";
import { useNotifications } from "@/lib/messagerie";
import { Logo } from "@/components/Logo";
import { FilMessages } from "@/components/FilMessages";
const fmt = (v: string) => new Intl.DateTimeFormat("fr-FR", { dateStyle: "medium", timeStyle: "short" }).format(new Date(v));

export default function NotificationsClient() {
  const router = useRouter(), { liste, recharger } = useNotifications(), [fil, setFil] = useState<{ id: string; titre: string } | null>(null);
  const [perm, setPerm] = useState<string>("inconnu");
  useEffect(() => { (async () => { const { data } = await supabaseBrowser().auth.getUser(); if (!data.user) router.replace("/connexion?retour=/notifications"); })();
    if (typeof Notification !== "undefined") setPerm(Notification.permission); }, [router]);
  async function activer() { if (typeof Notification === "undefined") return; setPerm(await Notification.requestPermission()); }
  return <main className="mx-auto min-h-screen max-w-2xl bg-slate-50 px-4 pb-28">
    <header className="-mx-4 mb-4 flex items-center justify-between bg-naxa-green-900 px-4 py-3 text-white"><Link href="/"><Logo taille={32} /></Link><h1 className="font-extrabold">Notifications</h1></header>
    {fil ? <FilMessages filId={fil.id} moi="client" titre={fil.titre} onRetour={() => { setFil(null); void recharger(); }} /> : <>
      {perm === "default" && <div className="carte mb-3 text-sm"><p>Activez les alertes pour être prévenu dès qu'une pharmacie répond.</p><button type="button" className="btn btn-canari mt-2" onClick={activer}>Activer les alertes</button></div>}
      {liste.length === 0 ? <p className="carte text-sm text-slate-600">Aucune notification pour le moment. Écrivez à une pharmacie depuis une fiche de résultat : sa réponse apparaîtra ici.</p> :
        <ul className="space-y-2">{liste.map((n) => <li key={n.id}><button type="button" disabled={!n.fil_id} onClick={() => n.fil_id && setFil({ id: n.fil_id, titre: n.titre })} className={"carte w-full text-left " + (n.lu_le ? "" : "border-l-4 border-naxa-canari")}>
          <p className="font-bold">{n.titre}</p><p className="text-sm text-slate-600">{n.corps}</p><p className="mt-1 text-xs text-slate-500">{fmt(n.created_at)}</p></button></li>)}</ul>}</>}
  </main>;
}
