"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { usePanier } from "@/lib/panier";
export function BoutonPanierEntete(){
 const {nombre,pret}=usePanier();const [arrival,setArrival]=useState(false);const [anime,setAnime]=useState(false);
 useEffect(()=>{const arrived=()=>{setAnime(true);window.setTimeout(()=>setAnime(false),2600);window.setTimeout(()=>{setArrival(true);window.setTimeout(()=>setArrival(false),900)},950)};window.addEventListener("naxa:panier-ajoute",arrived);return()=>window.removeEventListener("naxa:panier-ajoute",arrived)},[]);
 return <Link href="/panier" data-naxa-cart-target aria-label={`Ouvrir le panier, ${nombre} article${nombre===1?"":"s"}`} title="Mon panier" className={`relative -mx-0.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-[#FFE33D] hover:bg-white/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#FFE33D] ${arrival?"naxa-cart-arrival":"naxa-cart-pulse"}`}>
 <img src="/icones-header/panier.png" alt="" aria-hidden="true" width={30} height={30} className="h-[30px] w-[30px] object-contain"/>
 {pret&&[0,1,2].filter(i=>i<Math.min(nombre,3)).map(i=>{const drop=anime&&i===Math.min(nombre,3)-1;const pos=[{left:12,top:13,r:-18},{left:19,top:9,r:6},{left:25,top:13,r:20}][i];return <span key={i} aria-hidden="true" className={`naxa-cart-item ${drop?"naxa-cart-item-drop":""}`} style={{left:pos.left,top:pos.top,transform:drop?undefined:`rotate(${pos.r}deg)`,"--naxa-delay":"950ms"} as React.CSSProperties}>{i===0?<svg viewBox="0 0 10 10" width="8" height="8"><rect x="1" y="2" width="8" height="7" rx="1.2" fill="#fff" stroke="#064B2A" strokeWidth=".9"/><path d="M5 3.6v3.8M3.1 5.5h3.8" stroke="#16A34A" strokeWidth="1.2"/></svg>:i===1?<svg viewBox="0 0 10 10" width="8" height="8"><rect x="1" y="3.2" width="8" height="3.6" rx="1.8" fill="#fff" stroke="#064B2A" strokeWidth=".8"/><path d="M5 3.2h2a1.8 1.8 0 0 1 0 3.6H5Z" fill="#DC2626"/></svg>:<svg viewBox="0 0 10 10" width="8" height="8"><rect x="2.4" y="1" width="5.2" height="8" rx="1.2" fill="#FFE33D" stroke="#064B2A" strokeWidth=".8"/><rect x="3.2" y="3.4" width="3.6" height="2.8" rx=".5" fill="#fff"/></svg>}</span>})}
 {pret&&nombre>0&&<span className="absolute right-0 top-0 flex min-h-[17px] min-w-[17px] items-center justify-center rounded-full bg-[#FFE33D] px-1 text-[10px] font-black leading-none text-[#064B2A]">{nombre>99?"99+":nombre}</span>}
 </Link>;
}
