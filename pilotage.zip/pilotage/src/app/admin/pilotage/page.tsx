"use client";
import Link from "next/link";
import { useCallback, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/client";
import { fcfa } from "@/lib/ranking";
import { Barres, Liste, Section, Tuile, exporterCsv, useTempsReel } from "@/components/Pilotage";

/* eslint-disable @typescript-eslint/no-explicit-any */
export default function PilotageAdmin() {
  const [jours, setJours] = useState(7);
  const [d, setD] = useState<any>(null);
  const [alertes, setAlertes] = useState<any[]>([]);
  const [rapports, setRapports] = useState<any[]>([]);
  const [erreur, setErreur] = useState("");

  const charger = useCallback(async () => {
    const sb = supabaseBrowser();
    const [s, a, r] = await Promise.all([
      sb.rpc("stats_admin", { p_jours: jours }),
      sb.from("alertes").select("id,message,created_at").is("pharmacie_id", null).eq("lue", false).order("created_at", { ascending: false }).limit(10),
      sb.from("rapports").select("id,periode,du,au,texte").eq("portee", "admin").order("created_at", { ascending: false }).limit(4),
    ]);
    if (s.error) { setErreur("Accès refusé ou statistiques indisponibles."); return; }
    setErreur(""); setD(s.data); setAlertes(a.data ?? []); setRapports(r.data ?? []);
  }, [jours]);

  useTempsReel(charger, (rappel) => {
    const sb = supabaseBrowser();
    const canal = sb.channel("pilotage-admin")
      .on("postgres_changes", { event: "*", schema: "public", table: "reservations" }, rappel)
      .on("postgres_changes", { event: "*", schema: "public", table: "alertes" }, rappel)
      .subscribe();
    return () => { void sb.removeChannel(canal); };
  });

  async function lue(id: number) {
    await supabaseBrowser().from("alertes").update({ lue: true }).eq("id", id);
    setAlertes(alertes.filter((a) => a.id !== id));
  }

  const e = d?.entonnoir;
  const pct = (a: number, b: number) => (b ? `${Math.round((100 * a) / b)} %` : "-");
  return (
    <main className="mx-auto max-w-3xl space-y-4 px-4 pb-16 pt-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-extrabold">Pilotage NAXA</h1>
        <Link href="/admin" className="text-sm font-semibold underline underline-offset-4">Espace NAXA</Link>
      </div>
      <div className="flex gap-2" role="group" aria-label="Période">
        {[7, 30, 90].map((j) => (
          <button key={j} onClick={() => setJours(j)} aria-pressed={jours === j} className={`btn !min-h-[44px] flex-1 ${jours === j ? "btn-vert" : "btn-clair"}`}>{j} jours</button>
        ))}
      </div>
      {erreur && <p role="alert" className="carte text-red-700">{erreur}</p>}
      {!d && !erreur && <p>Chargement…</p>}

      {alertes.map((a) => (
        <div key={a.id} role="status" className="flex items-start justify-between gap-3 rounded-xl2 bg-naxa-canari p-3 text-sm font-semibold text-naxa-green-900">
          <span>{a.message}</span><button onClick={() => lue(a.id)} className="shrink-0 underline underline-offset-4">Compris</button>
        </div>
      ))}

      {d && (
        <>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Tuile titre="Pharmacies actives" valeur={d.pharmacies.actives} note={`${d.pharmacies.a_jour} à jour`} />
            <Tuile titre="Pharmacies à risque" valeur={d.pharmacies.a_risque} alerte={d.pharmacies.a_risque > 0} note="Stock > 7 jours" />
            <Tuile titre="Recherches" valeur={d.recherches.total} note={`${pct(d.recherches.sans_resultat, d.recherches.total)} sans résultat`} alerte={d.recherches.total > 0 && d.recherches.sans_resultat / d.recherches.total > 0.4} />
            <Tuile titre="Revenu mensuel" valeur={fcfa(d.abonnements.mrr)} note={`${d.abonnements.actifs} abonnements, ${d.abonnements.impayes} impayés`} />
          </div>

          <Section titre="De la recherche au retrait">
            <Liste vide="" lignes={[
              { cle: "r", texte: "Recherches", valeur: String(e.recherches) },
              { cle: "f", texte: "Fiches vues", valeur: `${e.fiches_vues} (${pct(e.fiches_vues, e.recherches)})` },
              { cle: "p", texte: "Ajouts au panier", valeur: `${e.paniers} (${pct(e.paniers, e.fiches_vues)})` },
              { cle: "s", texte: "Réservations", valeur: `${e.reservations} (${pct(e.reservations, e.recherches)})` },
              { cle: "t", texte: "Retirées en pharmacie", valeur: `${e.retirees} (${pct(e.retirees, e.reservations)})` },
            ]} />
          </Section>

          <Section titre="Recherches par jour"><Barres points={d.serie.map((x: any) => ({ jour: x.jour, n: x.recherches }))} etiquette="Recherches par jour" /></Section>
          <Section titre="Réservations par jour"><Barres points={d.serie.map((x: any) => ({ jour: x.jour, n: x.reservations }))} etiquette="Réservations par jour" /></Section>

          <Section titre="Produits les plus recherchés" action={<button className="text-sm underline" onClick={() => exporterCsv("top-recherches", d.top_recherches)}>CSV</button>}>
            <Liste vide="Pas encore de données." lignes={d.top_recherches.map((x: any, i: number) => ({ cle: `${i}`, texte: `${x.nom} ${x.dosage}`, valeur: String(x.n) }))} />
          </Section>

          <Section titre="Recherches sans résultat (demande non satisfaite)" action={<button className="text-sm underline" onClick={() => exporterCsv("sans-resultat", d.sans_resultat)}>CSV</button>}>
            <Liste vide="Aucun terme répété au moins 3 fois." lignes={d.sans_resultat.map((x: any, i: number) => ({ cle: `${i}`, texte: x.terme, valeur: String(x.n) }))} />
          </Section>

          <Section titre="Zones où la demande n'est pas servie (cellules d'environ 2 km, 5 cas minimum)" action={<button className="text-sm underline" onClick={() => exporterCsv("zones", d.zones_non_servies)}>CSV</button>}>
            <Liste vide="Pas assez de données." lignes={d.zones_non_servies.map((x: any, i: number) => ({ cle: `${i}`, texte: `${x.lat.toFixed(2)}, ${x.lng.toFixed(2)}`, valeur: `${x.n} recherches` }))} />
          </Section>

          <Section titre="Qualité du catalogue">
            <Liste vide="" lignes={[
              { cle: "a", texte: "Produits", valeur: String(d.qualite.produits) },
              { cle: "b", texte: "Sans fiche", valeur: String(d.qualite.sans_fiche) },
              { cle: "c", texte: "Fiches à relire", valeur: String(d.qualite.a_relire) },
              { cle: "d", texte: "Sans photo", valeur: String(d.qualite.sans_photo) },
            ]} />
            <Link href="/admin/produits" className="text-sm font-semibold underline underline-offset-4">Compléter les fiches</Link>
          </Section>

          <Section titre="Pharmacies" action={<button className="text-sm underline" onClick={() => exporterCsv("pharmacies", d.classement)}>CSV</button>}>
            <Liste vide="Aucune pharmacie." lignes={d.classement.map((x: any, i: number) => ({ cle: `${i}`, texte: `${x.nom}${x.quartier ? `, ${x.quartier}` : ""}`, valeur: `${x.reservations} réservations` }))} />
          </Section>

          <Section titre="Rapports">
            {rapports.length === 0 && <p className="text-sm text-slate-600">Le premier rapport arrive lundi matin.</p>}
            {rapports.map((x) => (
              <details key={x.id} className="rounded-xl2 border border-naxa-green-100 p-3">
                <summary className="min-h-[44px] cursor-pointer font-semibold">{x.periode === "mensuel" ? "Rapport mensuel" : "Rapport hebdomadaire"} du {x.du} au {x.au}</summary>
                <p className="mt-2 text-sm">{x.texte}</p>
              </details>
            ))}
          </Section>
        </>
      )}
    </main>
  );
}
