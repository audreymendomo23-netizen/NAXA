"use client";
import { useEffect, useState } from "react";
import type { CSSProperties } from "react";

type Flight = { id: number; nom: string; x: number; y: number; dx: number; dy: number };
type Detail = { nom?: string; dosage?: string; origine?: { x: number; y: number } | null };

// Le médicament part de son bouton « Ajouter », se miniaturise et entre dans l'icône du panier du header.
export function AnimationPanierGlobale() {
  const [flight, setFlight] = useState<Flight | null>(null);
  useEffect(() => {
    let seq = 0;
    let timer: number | undefined;
    const onAdd = (event: Event) => {
      if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
      const detail = (event as CustomEvent<Detail>).detail;
      const x = detail?.origine?.x ?? Math.round(window.innerWidth * 0.5);
      const y = detail?.origine?.y ?? Math.round(window.innerHeight * 0.62);
      const cible = document.querySelector("[data-naxa-cart-target]")?.getBoundingClientRect();
      const tx = cible && cible.width > 0 ? cible.left + cible.width / 2 : window.innerWidth - 48;
      const ty = cible && cible.height > 0 ? cible.top + cible.height / 2 : 38;
      const id = ++seq;
      setFlight({ id, nom: detail?.nom || "Article ajouté", x, y, dx: tx - x, dy: ty - y });
      window.clearTimeout(timer);
      timer = window.setTimeout(() => setFlight(current => (current?.id === id ? null : current)), 1450);
    };
    window.addEventListener("naxa:panier-ajoute", onAdd);
    return () => { window.removeEventListener("naxa:panier-ajoute", onAdd); window.clearTimeout(timer); };
  }, []);
  if (!flight) return null;
  return (
    <div key={flight.id} aria-hidden="true" className="naxa-cart-flight" style={{ left: flight.x, top: flight.y, "--naxa-flight-x": `${flight.dx}px`, "--naxa-flight-y": `${flight.dy}px` } as CSSProperties}>
      <div className="naxa-cart-flight-in">
        <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0" fill="none" aria-hidden="true"><g transform="rotate(-35 12 12)"><rect x="3" y="8" width="18" height="8" rx="4" fill="#fff" stroke="#064B2A" strokeWidth="1.6"/><path d="M12 8h5a4 4 0 0 1 0 8h-5Z" fill="#DC2626" stroke="#064B2A" strokeWidth="1.6"/></g></svg>
        <span className="truncate">{flight.nom}</span>
      </div>
    </div>
  );
}
