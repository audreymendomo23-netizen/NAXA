export type Langue = "fr" | "en";

export const textes = {
  fr: {
    menu: "Menu",
    langue: "Langue",
    ouvrirMenu: "Ouvrir le menu",
    fermerMenu: "Fermer le menu",
    espaceClient: "Espace client",
    espacePharmacie: "Espace pharmacie",
    universSection: "Explorer les univers NAXA",
    universPharmacie: "Pharmacie",
    universParapharmacie: "Parapharmacie",
    universBebeMaman: "Bébé & maman",
    universDispositifs: "Dispositifs médicaux",
    universExamens: "Examens médicaux",
    universPrestations: "Prestations et soins à domicile",
    besoinAide: "Besoin d’aide ?",
    titreLigne1: "Votre médicament,",
    titreLigne2: "trouvé en 2 minutes.",
    recherchePlaceholder: "Ex. Paracétamol 500 mg",
    chercher: "Chercher",
    scanner: "Scanner mon ordonnance",
    confidentialiteScan:
      "Votre ordonnance reste sur votre téléphone. Elle n'est jamais envoyée à NAXA.",
    lectureOrdonnance: "Lecture de l'ordonnance…",
    importImage: "Importer depuis mon téléphone",
    camera: "Utiliser la caméra",
    annuler: "Annuler",
    verifierLecture: "Vérifiez les médicaments lus",
    confianceLecture: "Fiabilité de la lecture",
    faibleConfiance:
      "La fiabilité est faible : corrigez ou supprimez les lignes erronées. Seul le pharmacien confirme le médicament.",
    ajouterLigne: "Ajouter une ligne",
    chercherStock: "Chercher en stock",
    erreurLecture:
      "La lecture a échoué. Prenez la photo bien à plat, avec de la lumière, ou tapez le nom du médicament.",
    recherchesFrequentes: "Recherches fréquentes",
    etapes: ["Rechercher", "Trouver", "Comparer", "Réserver"],
    pharmacienCta: "Rejoindre NAXA",
    avertissement:
      "NAXA donne une information de disponibilité, pas un avis médical. En cas d'urgence, appelez les secours au 118 (pompiers) ou 119 (SAMU), ou rendez-vous à la pharmacie la plus proche.",
    presDeMoi: "Près de moi",
    localisationEnCours: "Localisation en cours…",
    positionEnregistree: "Position enregistrée",
    yaoundeDefaut: "Yaoundé par défaut",
    gardes: "Pharmacies de garde",
    builtWith: "Built with ❤️ by NAXA",
  },
  en: {
    menu: "Menu",
    langue: "Language",
    ouvrirMenu: "Open menu",
    fermerMenu: "Close menu",
    espaceClient: "Customer area",
    espacePharmacie: "Pharmacy area",
    universSection: "Explore NAXA spaces",
    universPharmacie: "Pharmacy",
    universParapharmacie: "Parapharmacy",
    universBebeMaman: "Baby & Mom",
    universDispositifs: "Medical devices",
    universExamens: "Medical tests",
    universPrestations: "Home services and care",
    besoinAide: "Need help?",
    titreLigne1: "Your medicine,",
    titreLigne2: "found in 2 minutes.",
    recherchePlaceholder: "E.g. Paracetamol 500 mg",
    chercher: "Search",
    scanner: "Scan my prescription",
    confidentialiteScan:
      "Your prescription stays on your phone. It is never sent to NAXA.",
    lectureOrdonnance: "Reading prescription…",
    importImage: "Import from my phone",
    camera: "Use camera",
    annuler: "Cancel",
    verifierLecture: "Check the detected medicines",
    confianceLecture: "Reading confidence",
    faibleConfiance:
      "Confidence is low: correct or remove inaccurate lines. Only a pharmacist can confirm the medicine.",
    ajouterLigne: "Add a line",
    chercherStock: "Search availability",
    erreurLecture:
      "Reading failed. Take a well-lit, flat photo or type the medicine name.",
    recherchesFrequentes: "Frequent searches",
    etapes: ["Search", "Find", "Compare", "Reserve"],
    pharmacienCta: "Join NAXA",
    avertissement:
      "NAXA provides availability information, not medical advice. In an emergency, call 118 (fire) or 119 (ambulance), or go to the nearest pharmacy.",
    presDeMoi: "Near me",
    localisationEnCours: "Locating…",
    positionEnregistree: "Location saved",
    yaoundeDefaut: "Yaoundé by default",
    gardes: "On-duty pharmacies",
    builtWith: "Built with ❤️ by NAXA",
  },
} satisfies Record<Langue, Record<string, string | string[]>>;

export const recherchesFrequentes = [
  { fr: "Paracétamol", en: "Paracetamol" },
  { fr: "Amoxicilline", en: "Amoxicillin" },
  { fr: "Ibuprofène", en: "Ibuprofen" },
  { fr: "Artéméther/Luméfantrine", en: "Artemether/Lumefantrine" },
  { fr: "Sels de réhydratation", en: "Oral rehydration salts" },
];

export const suggestionsMedicaments = [
  { fr: "Paracétamol", en: "Paracetamol" },
  { fr: "Paracétamol 500 mg", en: "Paracetamol 500 mg" },
  { fr: "Amoxicilline", en: "Amoxicillin" },
  { fr: "Amoxicilline 500 mg", en: "Amoxicillin 500 mg" },
  { fr: "Ibuprofène", en: "Ibuprofen" },
  { fr: "Ibuprofène 400 mg", en: "Ibuprofen 400 mg" },
  { fr: "Artéméther/Luméfantrine", en: "Artemether/Lumefantrine" },
  { fr: "Sels de réhydratation", en: "Oral rehydration salts" },
  { fr: "Coartem", en: "Coartem" },
  { fr: "Metformine", en: "Metformin" },
  { fr: "Cétirizine", en: "Cetirizine" },
  { fr: "Oméprazole", en: "Omeprazole" },
  { fr: "Azithromycine", en: "Azithromycin" },
  { fr: "Métronidazole", en: "Metronidazole" },
];

export function normaliserRecherche(valeur: string): string {
  return valeur
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase("fr")
    .trim();
}
