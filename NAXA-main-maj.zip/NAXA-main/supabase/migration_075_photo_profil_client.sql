-- NAXA — photo de profil client + statut « profil vérifié » (additif)
-- Règle produit : un client qui a une photo de profil est un utilisateur vérifié (coche bleue).
-- Sans photo : l'interface affiche les initiales du nom. Le statut est DÉRIVÉ de la photo
-- (aucune colonne « vérifié » modifiable à la main).

alter table public.profiles
  add column if not exists photo_profil_path text;

comment on column public.profiles.photo_profil_path is
  'Chemin dans le bucket privé profils-photos (<user_id>/<fichier>.webp). Non nul = profil vérifié (coche bleue).';

-- Contrainte : le chemin doit commencer par l''identifiant du propriétaire.
do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conrelid = 'public.profiles'::regclass
      and conname = 'profiles_photo_profil_path_ck'
  ) then
    alter table public.profiles
      add constraint profiles_photo_profil_path_ck
      check (photo_profil_path is null or photo_profil_path like id::text || '/%') not valid;
  end if;
end
$$;

-- Bucket privé (lecture par URL signée uniquement), 512 Ko max.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('profils-photos', 'profils-photos', false, 524288, array['image/webp', 'image/jpeg', 'image/png'])
on conflict (id) do update
  set public = false,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists profils_photos_select_own on storage.objects;
create policy profils_photos_select_own on storage.objects for select to authenticated
  using (bucket_id = 'profils-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);

drop policy if exists profils_photos_insert_own on storage.objects;
create policy profils_photos_insert_own on storage.objects for insert to authenticated
  with check (bucket_id = 'profils-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);

drop policy if exists profils_photos_update_own on storage.objects;
create policy profils_photos_update_own on storage.objects for update to authenticated
  using (bucket_id = 'profils-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);

drop policy if exists profils_photos_delete_own on storage.objects;
create policy profils_photos_delete_own on storage.objects for delete to authenticated
  using (bucket_id = 'profils-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);

-- Aucune politique UPDATE client sur profiles : l'écriture passe par cette RPC contrôlée.
create or replace function public.definir_ma_photo_profil(p_path text default null)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_path text := nullif(trim(p_path), '');
begin
  if v_uid is null then
    raise exception 'Connexion requise';
  end if;
  if not exists (select 1 from public.profiles where id = v_uid and role = 'client') then
    raise exception 'Réservé aux clients';
  end if;
  if v_path is not null and v_path not like v_uid::text || '/%' then
    raise exception 'Chemin de photo invalide';
  end if;
  update public.profiles set photo_profil_path = v_path where id = v_uid;
  return v_path is not null;
end
$$;

revoke all on function public.definir_ma_photo_profil(text) from public, anon;
grant execute on function public.definir_ma_photo_profil(text) to authenticated;
