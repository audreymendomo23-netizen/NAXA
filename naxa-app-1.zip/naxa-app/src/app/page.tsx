import Link from "next/link";
import { Logo } from "@/components/Logo";
import { Recherche } from "@/components/Recherche";

const ETAPES = [
  { n: 1, titre: "Je cherche", texte: "Je tape le médicament ou je scanne mon ordonnance." },
  { n: 2, titre: "Je trouve", texte: "Je vois les pharmacies qui l'ont en stock, avec le prix et la distance." },
  { n: 3, titre: "Je compare", texte: "Prix, distance, temps de trajet : je choisis la meilleure option." },
  { n: 4, titre: "Je réserve", texte: "Facultatif : je réserve par WhatsApp et je retire en pharmacie." },
];

export default function Accueil() {
  return (
    <main>
      <section className="bg-naxa-green-900 px-5 pb-14 pt-6 text-white">
        <div className="mx-auto max-w-3xl">
          <div className="flex items-center justify-between">
            <Logo />
            <Link href="/connexion" className="text-sm font-semibold underline underline-offset-4">Se connecter</Link>
          </div>
          <p className="mt-2 text-lg">Votre médicament, à 2 minutes.</p>
          <h1 className="mt-8 text-4xl font-extrabold leading-tight sm:text-5xl">
            Trouvez votre médicament en <span className="text-naxa-canari">quelques secondes.</span>
          </h1>
          <p className="mt-4 max-w-lg text-lg text-naxa-green-100">Recherchez. Vérifiez la disponibilité. Comparez les pharmacies. Réservez.</p>
          <div className="mt-8"><Recherche /></div>
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-5 py-10">
        <ol className="grid gap-4 sm:grid-cols-2">
          {ETAPES.map((e) => (
            <li key={e.n} className="carte flex gap-4">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-naxa-canari text-xl font-extrabold text-naxa-green-900">{e.n}</span>
              <div><h2 className="text-lg font-bold">{e.titre}</h2><p className="text-slate-600">{e.texte}</p></div>
            </li>
          ))}
        </ol>
        <p className="mt-8 text-sm text-slate-600">
          NAXA donne une information de disponibilité, pas un avis médical. En cas d'urgence, appelez les secours ou rendez-vous à la pharmacie de garde la plus proche. Le pharmacien reste seul juge du médicament délivré.
        </p>
      </section>
      <footer className="bg-naxa-green-900 px-5 py-6 text-center text-sm text-naxa-green-100">
        NAXA · Yaoundé, Douala, partout au Cameroun · Une santé plus accessible pour tous
      </footer>
    </main>
  );
}
