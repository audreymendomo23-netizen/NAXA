"use client";
import { Suspense, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/client";
import { calculerTrajet, lienItineraire } from "@/lib/travel";
import { estimerCirculation } from "@/lib/traffic";
import { classer, fcfa, fraicheur, type Priorite } from "@/lib/ranking";
import type { ResultatPharmacie, Trajet } from "@/lib/types";
import { Logo } from "@/components/Logo";

const YAOUNDE = { lat: 3.848, lng: 11.502 };
const PRIORITES: { id: Priorite; label: string }[] = [
  { id: "equilibre", label: "Équilibré" },
  { id: "prix", label: "Moins cher" },
  { id: "proche", label: "Plus proche" },
  { id: "rapide", label: "Plus rapide" },
];

function Resultats() {
  const router = useRouter();
  const params = useSearchParams();
  const termes = params.getAll("q");
  const panierParam = params.getAll("p"); // « produit_id:quantité »
  const modePanier = panierParam.length > 0;
  const panierItems = useMemo(
    () => panierParam.map((x) => ({ produit_id: x.split(":")[0], quantite: Math.max(1, Math.min(10, Number(x.split(":")[1]) || 1)) })),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [panierParam.join("|")]
  );
  const [position, setPosition] = useState<{ lat: number; lng: number; approx: boolean } | null>(null);
  const [brut, setBrut] = useState<(ResultatPharmacie & { trajet: Trajet })[] | null>(null);
  const [priorite, setPriorite] = useState<Priorite>("equilibre");
  const [erreur, setErreur] = useState("");
  const [reserve, setReserve] = useState<string | null>(null);
  const circulation = useMemo(() => estimerCirculation(), []);

  useEffect(() => {
    if (!navigator.geolocation) return setPosition({ ...YAOUNDE, approx: true });
    navigator.geolocation.getCurrentPosition(
      (p) => setPosition({ lat: p.coords.latitude, lng: p.coords.longitude, approx: false }),
      () => setPosition({ ...YAOUNDE, approx: true }),
      { timeout: 6000 }
    );
  }, []);

  useEffect(() => {
    if (!position || (!termes.length && !modePanier)) return;
    (async () => {
      const sb = supabaseBrowser();
      const { data, error } = modePanier
        ? await sb.rpc("search_pharmacies_panier", { p_items: panierItems, p_lat: position.lat, p_lng: position.lng })
        : await sb.rpc("search_pharmacies", { p_terms: termes, p_lat: position.lat, p_lng: position.lng });
      if (error) return setErreur("La recherche est momentanément indisponible. Réessayez dans un instant.");
      const proches = ((data ?? []) as ResultatPharmacie[]).slice(0, 8);
      const avecTrajet = await Promise.all(
        proches.map(async (p) => ({ ...p, trajet: await calculerTrajet(position, p, p.distance_km) }))
      );
      setBrut(avecTrajet);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [position, termes.join("|"), panierItems, modePanier]);

  // Alimente « Les plus recherchés » : seulement le produit cherché, ni identité ni position.
  useEffect(() => {
    if (termes.length && !modePanier) void supabaseBrowser().rpc("log_recherche", { p_terms: termes });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [termes.join("|"), modePanier]);

  const liste = useMemo(() => (brut ? classer(brut, priorite) : null), [brut, priorite]);

  async function reserver(pharmacieId: string, items: { produit_id: string; quantite_demandee?: number }[]) {
    const sb = supabaseBrowser();
    const { data: u } = await sb.auth.getUser();
    if (!u.user) return router.push(`/connexion?retour=${encodeURIComponent("/resultats?" + params.toString())}`);
    setReserve(pharmacieId); setErreur("");
    const { data, error } = await sb.rpc("reserve_stock", { p_pharmacie: pharmacieId, p_items: items.map((i) => ({ produit_id: i.produit_id, quantite: i.quantite_demandee ?? 1 })) });
    setReserve(null);
    if (error) return setErreur("Réservation impossible : le stock vient peut-être de changer. Relancez la recherche.");
    router.push(`/reservation/${data}`);
  }

  return (
    <main className="mx-auto max-w-2xl px-4 pb-16">
      <header className="-mx-4 mb-4 flex items-center justify-between bg-naxa-green-900 px-4 py-3">
        <Link href="/"><Logo taille={32} /></Link>
        <Link href="/" className="text-sm font-semibold text-white underline underline-offset-4">Nouvelle recherche</Link>
      </header>

      <h1 className="text-xl font-extrabold">{modePanier ? `Mon panier (${panierItems.length} produit${panierItems.length > 1 ? "s" : ""})` : termes.join(" · ") || "Aucun médicament indiqué"}</h1>
      {position?.approx && <p className="mt-1 text-sm text-slate-600">Position approximative (centre de Yaoundé). Autorisez la localisation pour des distances exactes.</p>}
      <p className={`mt-2 rounded-xl2 px-4 py-2 text-sm ${circulation.niveau === "fluide" ? "bg-naxa-green-100" : "bg-naxa-canari/60"}`}>{circulation.message}</p>

      <div className="mt-4 flex flex-wrap gap-2" role="group" aria-label="Classer par">
        {PRIORITES.map((p) => (
          <button key={p.id} onClick={() => setPriorite(p.id)} aria-pressed={priorite === p.id} className={`btn !min-h-[40px] !px-4 text-sm ${priorite === p.id ? "btn-vert" : "btn-clair"}`}>{p.label}</button>
        ))}
      </div>

      {erreur && <p role="alert" className="mt-4 text-red-700">{erreur}</p>}
      {!liste && !erreur && <p className="mt-6 text-slate-600">Recherche des pharmacies en cours…</p>}
      {liste && liste.length === 0 && (
        <div className="carte mt-6">
          <p className="font-bold">Aucune pharmacie partenaire n'a ce produit en stock pour le moment.</p>
          <p className="mt-1 text-slate-600">Vérifiez l'orthographe, essayez le nom de la molécule (ex. paracétamol), ou demandez conseil à une pharmacie de garde.</p>
        </div>
      )}

      <ul className="mt-6 space-y-4">
        {liste?.map((p) => (
          <li key={p.pharmacie_id} className="carte">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold">{p.nom}</h2>
                <p className="text-sm text-slate-600">{[p.quartier, p.adresse].filter(Boolean).join(" · ")}</p>
              </div>
              <p className="text-right text-xl font-extrabold text-naxa-green-700">{fcfa(p.total_prix)}</p>
            </div>
            <div className="mt-2 flex flex-wrap gap-2">
              {p.badges.map((b) => <span key={b} className="rounded-full bg-naxa-canari px-3 py-1 text-xs font-bold text-naxa-green-900">{b}</span>)}
              {p.trouves < p.demandes && <span className="rounded-full bg-red-100 px-3 py-1 text-xs font-bold text-red-800">{p.trouves} sur {p.demandes} médicaments en quantité suffisante</span>}
            </div>
            <p className="mt-3 text-sm">
              <strong>{p.trajet.minutes} min</strong> · {p.trajet.km.toFixed(1)} km{p.trajet.estime ? " (estimé)" : ""} · {fraicheur(p.stock_updated_at)}
            </p>
            <ul className="mt-2 text-sm text-slate-700">
              {p.items.map((i) => (
                <li key={i.produit_id}>
                  {i.quantite_demandee ? `${i.quantite_demandee} × ` : ""}
                  <Link href={`/produit/${i.produit_id}`} className="font-semibold underline underline-offset-4">{i.nom} {i.dosage}</Link>
                  {" : "}{fcfa(i.prix)}{i.quantite_demandee ? " l'unité" : ""} · {i.quantite} en stock
                </li>
              ))}
            </ul>
            <div className="mt-4 flex gap-2">
              <a className="btn btn-clair flex-1" target="_blank" rel="noreferrer" href={lienItineraire(position!, p)}>Itinéraire</a>
              <button className="btn btn-vert flex-1" disabled={reserve === p.pharmacie_id} onClick={() => reserver(p.pharmacie_id, p.items)}>
                {reserve === p.pharmacie_id ? "Réservation…" : "Réserver (facultatif)"}
              </button>
            </div>
          </li>
        ))}
      </ul>
      <p className="mt-8 text-xs text-slate-500">Information de disponibilité, pas un avis médical. Les stocks peuvent changer : confirmez auprès de la pharmacie.</p>
    </main>
  );
}

export default function Page() {
  return <Suspense><Resultats /></Suspense>;
}
