"use client";

import Link from "next/link";
import { Suspense, type ReactNode } from "react";
import { usePathname, useSearchParams } from "next/navigation";

type Onglet = { id: string; libelle: string; href: string; icone: ReactNode; actif: boolean };

const ROUTES_VISIBLES = ["/client", "/resultats", "/produit", "/gardes", "/pharmacies", "/offre", "/notifications"];

function Ico({ children }: { children: ReactNode }) {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-6 w-6"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.9"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {children}
    </svg>
  );
}

function BarreInterne() {
  const chemin = usePathname();
  const params = useSearchParams();
  const visible = chemin === "/" || ROUTES_VISIBLES.some((r) => chemin === r || chemin.startsWith(r + "/"));
  if (!visible) return null;

  const onglet = params.get("onglet");
  const surClient = chemin === "/client" || chemin.startsWith("/client/");
  const surProfil = (surClient && (onglet === "profil" || chemin.startsWith("/client/profil"))) || chemin.startsWith("/notifications");

  const onglets: Onglet[] = [
    {
      id: "accueil",
      libelle: "Accueil",
      href: "/",
      actif: chemin === "/",
      icone: (
        <Ico>
          <path d="M4 11l8-7 8 7v8.5a1.5 1.5 0 0 1-1.5 1.5H15v-6H9v6H5.5A1.5 1.5 0 0 1 4 19.5Z" />
        </Ico>
      ),
    },
    {
      id: "recherche",
      libelle: "Recherche",
      href: "/?champ=recherche",
      actif: chemin.startsWith("/resultats") || chemin.startsWith("/produit") || chemin.startsWith("/offre"),
      icone: (
        <Ico>
          <circle cx="11" cy="11" r="6.5" />
          <path d="M16 16l4.5 4.5" />
        </Ico>
      ),
    },
    {
      id: "scanner",
      libelle: "Scanner",
      href: "/?scanner=1",
      actif: false,
      icone: (
        <Ico>
          <path d="M4 8V6a2 2 0 0 1 2-2h2M16 4h2a2 2 0 0 1 2 2v2M20 16v2a2 2 0 0 1-2 2h-2M8 20H6a2 2 0 0 1-2-2v-2" />
          <path d="M4 12h16" />
        </Ico>
      ),
    },
    {
      id: "achats",
      libelle: "Achats",
      href: "/client?onglet=achats",
      actif: surClient && onglet === "achats",
      icone: (
        <Ico>
          <path d="M5 7h14l-1.2 11a2 2 0 0 1-2 1.8H8.2a2 2 0 0 1-2-1.8Z" />
          <path d="M9 7a3 3 0 0 1 6 0" />
        </Ico>
      ),
    },
    {
      id: "profil",
      libelle: "Profil",
      href: "/client?onglet=profil",
      actif: surProfil,
      icone: (
        <Ico>
          <circle cx="12" cy="8" r="3.5" />
          <path d="M5 20c.5-4 3-6 7-6s6.5 2 7 6" />
        </Ico>
      ),
    },
  ];

  return (
    <nav
      aria-label="Navigation principale"
      className="barre-onglets no-print fixed inset-x-0 bottom-0 z-40 border-t border-naxa-green-100 bg-white pb-[env(safe-area-inset-bottom,0px)]"
    >
      <ul className="mx-auto flex max-w-xl items-stretch justify-between gap-1 px-2 py-1.5">
        {onglets.map((o) => (
          <li key={o.id} className="min-w-0 flex-1">
            <Link
              href={o.href}
              aria-current={o.actif ? "page" : undefined}
              className={`flex min-h-[52px] flex-col items-center justify-center gap-0.5 rounded-2xl px-1 text-[11px] font-semibold transition-colors ${
                o.actif
                  ? "bg-naxa-canari text-naxa-green-900"
                  : "text-naxa-green-900/70 hover:bg-naxa-green-100"
              }`}
            >
              {o.icone}
              <span className={o.actif ? "font-extrabold" : ""}>{o.libelle}</span>
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  );
}

export function BarreOnglets() {
  return (
    <Suspense fallback={null}>
      <BarreInterne />
    </Suspense>
  );
}
