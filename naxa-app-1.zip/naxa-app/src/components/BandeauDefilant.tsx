"use client";
import Link from "next/link";
import { useState } from "react";
import { usePathname } from "next/navigation";
import { fcfa } from "@/lib/ranking";

export type Populaire = { produit_id: string; nom: string; dosage: string; photo_url: string | null; prix_min: number | null };

const MASQUE = ["/admin", "/pharmacie", "/connexion", "/reservation"];

/** Bandeau défilant « Les plus recherchés ». Pause au survol, au clavier et avec le bouton. Sans animation si le téléphone la désactive. */
export function BandeauDefilant({ produits }: { produits: Populaire[] }) {
  const chemin = usePathname();
  const [pause, setPause] = useState(false);
  if (!produits.length || MASQUE.some((p) => chemin.startsWith(p))) return null;

  const carte = (p: Populaire, copie: boolean) => (
    <Link
      key={`${copie ? "b" : "a"}-${p.produit_id}`}
      href={`/produit/${p.produit_id}`}
      className="flex min-h-[48px] shrink-0 items-center gap-2 rounded-full bg-white/10 py-1 pl-1 pr-4 text-sm text-white hover:bg-white/20"
      aria-hidden={copie || undefined}
      tabIndex={copie ? -1 : undefined}
    >
      {p.photo_url ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={p.photo_url} alt="" width={40} height={40} loading="lazy" className="h-10 w-10 rounded-full bg-white object-contain" />
      ) : (
        <span className="flex h-10 w-10 items-center justify-center rounded-full bg-naxa-canari text-lg font-extrabold text-naxa-green-900" aria-hidden="true">+</span>
      )}
      <span className="font-semibold">{p.nom} {p.dosage}</span>
      {p.prix_min ? <span className="text-naxa-canari">dès {fcfa(p.prix_min)}</span> : null}
    </Link>
  );

  return (
    <section className="bandeau no-print bg-naxa-green-700" aria-label="Les médicaments les plus recherchés">
      <div className="mx-auto flex max-w-5xl items-center gap-3 px-3 py-2">
        <p className="shrink-0 text-xs font-extrabold uppercase tracking-wide text-naxa-canari">Les plus recherchés</p>
        <div className="bandeau-piste min-w-0 flex-1">
          <div className="defile flex w-max gap-3" data-pause={pause}>
            {produits.map((p) => carte(p, false))}
            {produits.map((p) => carte(p, true))}
          </div>
        </div>
        <button type="button" onClick={() => setPause(!pause)} aria-pressed={pause} className="shrink-0 rounded-full border border-white/40 px-3 text-xs font-semibold text-white min-h-[48px]">
          {pause ? "Reprendre" : "Pause"}
        </button>
      </div>
    </section>
  );
}
