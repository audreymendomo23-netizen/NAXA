"use client";
import Link from "next/link";
import { useCallback, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/client";
import { fcfa } from "@/lib/ranking";
import { Barres, Liste, Section, Tuile, exporterCsv, useTempsReel } from "@/components/Pilotage";

/* eslint-disable @typescript-eslint/no-explicit-any */
export default function PilotagePharmacie() {
  const [ph, setPh] = useState<string | null>(null);
  const [jours, setJours] = useState(7);
  const [d, setD] = useState<any>(null);
  const [alertes, setAlertes] = useState<any[]>([]);
  const [rapports, setRapports] = useState<any[]>([]);
  const [erreur, setErreur] = useState("");

  const charger = useCallback(async () => {
    const sb = supabaseBrowser();
    let id = ph;
    if (!id) {
      const { data: u } = await sb.auth.getUser();
      if (!u.user) return;
      const { data: p } = await sb.from("profiles").select("pharmacie_id").eq("id", u.user.id).single();
      id = new URLSearchParams(window.location.search).get("pharmacie") ?? p?.pharmacie_id ?? null;
      if (!id) { setErreur("Aucune pharmacie n'est liée à ce compte."); return; }
      setPh(id);
    }
    const [s, a, r] = await Promise.all([
      sb.rpc("stats_pharmacie", { p_ph: id, p_jours: jours }),
      sb.from("alertes").select("id,message,created_at").eq("pharmacie_id", id).eq("lue", false).order("created_at", { ascending: false }).limit(10),
      sb.from("rapports").select("id,periode,du,au,texte").eq("pharmacie_id", id).order("created_at", { ascending: false }).limit(4),
    ]);
    if (s.error) { setErreur("Statistiques indisponibles."); return; }
    setErreur(""); setD(s.data); setAlertes(a.data ?? []); setRapports(r.data ?? []);
  }, [ph, jours]);

  useTempsReel(charger, (rappel) => {
    const sb = supabaseBrowser();
    const canal = sb.channel("pilotage-pharmacie")
      .on("postgres_changes", { event: "*", schema: "public", table: "reservations" }, rappel)
      .on("postgres_changes", { event: "*", schema: "public", table: "alertes" }, rappel)
      .subscribe();
    return () => { void sb.removeChannel(canal); };
  });

  async function lue(id: number) {
    await supabaseBrowser().from("alertes").update({ lue: true }).eq("id", id);
    setAlertes(alertes.filter((a) => a.id !== id));
  }

  const r = d?.reservations;
  return (
    <main className="mx-auto max-w-2xl space-y-4 px-4 pb-16 pt-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-extrabold">Pilotage de ma pharmacie</h1>
        <Link href="/pharmacie" className="text-sm font-semibold underline underline-offset-4">Mon stock</Link>
      </div>
      <div className="flex gap-2" role="group" aria-label="Période">
        {[7, 30].map((j) => (
          <button key={j} onClick={() => setJours(j)} aria-pressed={jours === j} className={`btn !min-h-[44px] flex-1 ${jours === j ? "btn-vert" : "btn-clair"}`}>{j} jours</button>
        ))}
      </div>
      {erreur && <p role="alert" className="carte text-red-700">{erreur}</p>}
      {!d && !erreur && <p>Chargement…</p>}

      {alertes.map((a) => (
        <div key={a.id} role="status" className="flex items-start justify-between gap-3 rounded-xl2 bg-naxa-canari p-3 text-sm font-semibold text-naxa-green-900">
          <span>{a.message}</span>
          <button onClick={() => lue(a.id)} className="shrink-0 underline underline-offset-4">Compris</button>
        </div>
      ))}

      {d && (
        <>
          <div className="grid grid-cols-2 gap-3">
            <Tuile titre="Réservations" valeur={r.total} note={`${r.en_attente} en attente`} alerte={d.attente_longue > 0} />
            <Tuile titre="Taux de retrait" valeur={d.taux_retrait == null ? "-" : `${d.taux_retrait} %`} note={`${r.retirees} retirées, ${r.perdues} perdues`} />
            <Tuile titre="Chiffre d'affaires estimé" valeur={fcfa(r.ca_estime)} note="Réservations retirées ou payées" />
            <Tuile titre="Fiches vues" valeur={d.fiches_vues} note="Vos produits en stock" />
          </div>
          <Tuile titre="Mise à jour du stock" valeur={d.stock_age_heures == null ? "Jamais" : `il y a ${d.stock_age_heures} h`} alerte={d.stock_age_heures == null || d.stock_age_heures > 168} note="Au-delà de 7 jours, vous perdez en visibilité." />

          <Section titre="Réservations par jour"><Barres points={d.serie} etiquette="Réservations par jour" /></Section>

          <Section titre="Ce que les clients de votre zone cherchent et que vous n'avez pas"
            action={<button className="text-sm underline" onClick={() => exporterCsv("demande", d.demande_non_servie)}>CSV</button>}>
            <Liste vide="Pas assez de recherches pour l'instant." lignes={d.demande_non_servie.map((x: any) => ({ cle: x.produit_id, texte: `${x.nom} ${x.dosage}`, valeur: `${x.n} recherches` }))} />
          </Section>

          <Section titre="Ruptures et stock bas"
            action={<button className="text-sm underline" onClick={() => exporterCsv("ruptures", d.ruptures)}>CSV</button>}>
            <Liste vide="Aucune rupture." lignes={d.ruptures.map((x: any, i: number) => ({ cle: `${i}`, texte: `${x.nom} ${x.dosage}`, valeur: `${x.quantite} en stock` }))} />
          </Section>

          <Section titre="Mes prix comparés à la médiane des pharmacies"
            action={<button className="text-sm underline" onClick={() => exporterCsv("prix", d.prix_vs_mediane)}>CSV</button>}>
            <Liste vide="Pas assez de pharmacies pour comparer (3 minimum)." lignes={d.prix_vs_mediane.map((x: any, i: number) => ({ cle: `${i}`, texte: `${x.nom} ${x.dosage} : ${fcfa(x.mon_prix)} (médiane ${fcfa(x.mediane)})`, valeur: `${x.ecart_pct > 0 ? "+" : ""}${x.ecart_pct} %` }))} />
          </Section>

          <Section titre="Rapports">
            {rapports.length === 0 && <p className="text-sm text-slate-600">Le premier rapport arrive lundi matin.</p>}
            {rapports.map((x) => (
              <details key={x.id} className="rounded-xl2 border border-naxa-green-100 p-3">
                <summary className="min-h-[44px] cursor-pointer font-semibold">{x.periode === "mensuel" ? "Rapport mensuel" : "Rapport hebdomadaire"} du {x.du} au {x.au}</summary>
                <p className="mt-2 text-sm">{x.texte}</p>
              </details>
            ))}
          </Section>
        </>
      )}
    </main>
  );
}
