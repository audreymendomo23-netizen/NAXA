// OCR gratuit dans le navigateur (Tesseract.js) : l'image de l'ordonnance n'est jamais envoyée au serveur.
export type LectureOrdonnance = { texte: string; confiance: number; candidats: string[] };

const BRUIT = /^(dr\.?|docteur|date|nom|pr[ée]nom|age|âge|ordonnance|signature|cachet|le\s|n°|tel|t[ée]l)/i;

export async function lireOrdonnance(image: File | Blob): Promise<LectureOrdonnance> {
  const { createWorker } = await import("tesseract.js");
  const worker = await createWorker("fra");
  try {
    const { data } = await worker.recognize(image);
    const candidats = Array.from(
      new Set(
        data.text
          .split("\n")
          .map((l) => l.replace(/^[\s\-•*\d.)]+/, "").replace(/\s+/g, " ").trim())
          .filter((l) => l.length >= 3 && /[a-zA-ZÀ-ÿ]{3,}/.test(l) && !BRUIT.test(l))
      )
    ).slice(0, 12);
    return { texte: data.text, confiance: Math.round(data.confidence), candidats };
  } finally {
    await worker.terminate();
  }
}
