-- Contrôle structurel de la migration 076 (RLS actives, fonctions présentes, pas d'accès anon).
do $$
declare t text;
begin
  foreach t in array array['client_preferences','fils_messages','messages_pharmacie','notifications'] loop
    if not exists (select 1 from pg_class c join pg_namespace n on n.oid=c.relnamespace
                   where n.nspname='public' and c.relname=t and c.relrowsecurity) then
      raise exception 'RLS absente sur %', t; end if;
  end loop;
  foreach t in array array['envoyer_message_client','repondre_message','marquer_fil_lu','boite_pharmacie'] loop
    if not exists (select 1 from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname=t) then
      raise exception 'fonction % absente', t; end if;
    if exists (select 1 from pg_proc p join pg_namespace n on n.oid=p.pronamespace
               where n.nspname='public' and p.proname=t and has_function_privilege('anon', p.oid, 'execute')) then
      raise exception 'fonction % exécutable par anon', t; end if;
  end loop;
  if has_table_privilege('authenticated','public.fils_messages','insert') and
     exists (select 1 from pg_policies where tablename='fils_messages' and cmd in ('INSERT','ALL')) then
    raise exception 'fils_messages ne doit pas être inscriptible directement'; end if;
end $$;
