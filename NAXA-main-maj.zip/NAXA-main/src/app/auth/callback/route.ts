import { NextResponse } from "next/server";
import { supabaseServer } from "@/lib/supabase/server";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const code = url.searchParams.get("code");
  let next = url.searchParams.get("next") ?? "/";

  if (!next.startsWith("/") || next.startsWith("//")) next = "/";

  if (code) {
    const response = NextResponse.redirect(new URL(next, url.origin));
    const supabase = supabaseServer(response);
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    if (!error) return response;
    console.error("NAXA_OAUTH_EXCHANGE_FAILED", error.message);
  } else {
    console.error("NAXA_OAUTH_CALLBACK_SANS_CODE", url.searchParams.get("error_description"));
  }

  return NextResponse.redirect(new URL("/connexion?erreur=oauth", url.origin));
}
