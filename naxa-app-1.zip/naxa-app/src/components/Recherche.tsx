"use client";
import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { lireOrdonnance, type LectureOrdonnance } from "@/lib/ocr";

export function Recherche() {
  const router = useRouter();
  const [q, setQ] = useState("");
  const [lecture, setLecture] = useState<LectureOrdonnance | null>(null);
  const [liste, setListe] = useState<string[]>([]);
  const [etat, setEtat] = useState<"repos" | "lecture" | "erreur">("repos");
  const fichier = useRef<HTMLInputElement>(null);

  const aller = (termes: string[]) => {
    const p = new URLSearchParams();
    termes.filter(Boolean).forEach((t) => p.append("q", t));
    router.push(`/resultats?${p.toString()}`);
  };

  async function scanner(f: File) {
    setEtat("lecture");
    try {
      const l = await lireOrdonnance(f);
      setLecture(l);
      setListe(l.candidats);
      setEtat("repos");
    } catch {
      setEtat("erreur");
    }
  }

  return (
    <div className="w-full max-w-xl space-y-3">
      <form onSubmit={(e) => { e.preventDefault(); if (q.trim()) aller([q.trim()]); }} className="flex flex-col gap-3 sm:flex-row">
        <input className="champ" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ex. Paracétamol 500mg" aria-label="Médicament recherché" />
        <button className="btn btn-canari" type="submit">Rechercher</button>
      </form>

      <input ref={fichier} type="file" accept="image/*" capture="environment" hidden onChange={(e) => e.target.files?.[0] && scanner(e.target.files[0])} />
      <button className="btn btn-clair w-full" type="button" onClick={() => fichier.current?.click()} disabled={etat === "lecture"}>
        {etat === "lecture" ? "Lecture de l'ordonnance…" : "Scanner mon ordonnance"}
      </button>
      {etat === "erreur" && <p role="alert" className="text-sm text-red-700">La lecture a échoué. Prenez la photo bien à plat, avec de la lumière, ou tapez le nom du médicament.</p>}

      {lecture && (
        <div className="carte space-y-3">
          <p className="font-semibold">Vérifiez les médicaments lus</p>
          <p className="text-sm text-slate-600">
            Fiabilité de la lecture : {lecture.confiance} %.{" "}
            {lecture.confiance < 70 && "Elle est faible : corrigez ou supprimez les lignes erronées. Seul le pharmacien confirme le médicament."}
          </p>
          <ul className="space-y-2">
            {liste.map((m, i) => (
              <li key={i} className="flex gap-2">
                <input className="champ !min-h-[44px]" value={m} onChange={(e) => setListe(liste.map((x, j) => (j === i ? e.target.value : x)))} aria-label={`Médicament ${i + 1}`} />
                <button type="button" className="btn btn-clair !px-4" onClick={() => setListe(liste.filter((_, j) => j !== i))} aria-label="Supprimer cette ligne">×</button>
              </li>
            ))}
          </ul>
          <div className="flex gap-2">
            <button type="button" className="btn btn-clair" onClick={() => setListe([...liste, ""])}>Ajouter une ligne</button>
            <button type="button" className="btn btn-vert flex-1" onClick={() => aller(liste)} disabled={!liste.some((l) => l.trim())}>Chercher en stock</button>
          </div>
        </div>
      )}
    </div>
  );
}
