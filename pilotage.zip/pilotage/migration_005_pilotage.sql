-- NAXA : migration 005 — pilotage 360° (événements, statistiques, alertes, rapports, abonnements).
-- Ordre : schema, 002, 003, 004, puis ce fichier. Sans danger si relancée. Ne supprime aucune donnée existante.

-- 1. Événements anonymes (pas d'identifiant client, position arrondie à ~2 km).
create table if not exists public.evenements (
  id bigserial primary key,
  type text not null check (type in ('recherche','fiche_vue','panier_ajout','scan_ordonnance')),
  produit_id uuid references public.produits(id) on delete set null,
  pharmacie_id uuid references public.pharmacies(id) on delete set null,
  terme text,
  resultats int,
  zone_lat double precision,
  zone_lng double precision,
  created_at timestamptz not null default now()
);
create index if not exists evenements_type_date on public.evenements (type, created_at desc);
create index if not exists evenements_produit_date on public.evenements (produit_id, created_at desc);
alter table public.evenements enable row level security;
drop policy if exists evenements_admin_lecture on public.evenements;
create policy evenements_admin_lecture on public.evenements for select using ((select public.is_admin()));
revoke all on table public.evenements from anon, authenticated;
grant select on table public.evenements to authenticated;

create or replace function public.log_evenement(
  p_type text, p_produit uuid default null, p_pharmacie uuid default null,
  p_terme text default null, p_resultats int default null, p_lat float8 default null, p_lng float8 default null)
returns void language plpgsql security definer set search_path = public, extensions as $$
declare tn text; pid uuid := p_produit; zl float8; zg float8; t_stocke text; res int;
begin
  if p_type not in ('recherche','fiche_vue','panier_ajout','scan_ordonnance') then return; end if;
  res := case when p_resultats is null then null else least(greatest(p_resultats, 0), 1000) end;
  if p_type = 'recherche' and p_terme is not null then
    tn := left(lower(unaccent(trim(p_terme))), 60);
    if pid is null and length(tn) >= 3 then
      select id into pid from public.produits
       where nom_norm % tn or nom_norm ilike '%' || tn || '%'
       order by similarity(nom_norm, tn) desc limit 1;
    end if;
    -- le texte libre n'est gardé que pour les recherches sans résultat, et jamais s'il ressemble à un numéro ou un e-mail
    if res = 0 and length(tn) >= 3 and tn !~ '[0-9]{5,}' and tn !~ '@' then t_stocke := tn; end if;
  end if;
  if p_lat is not null and p_lng is not null and p_lat between -5 and 15 and p_lng between 5 and 20 then
    zl := (round(p_lat::numeric / 0.02) * 0.02)::float8;
    zg := (round(p_lng::numeric / 0.02) * 0.02)::float8;
  end if;
  insert into public.evenements (type, produit_id, pharmacie_id, terme, resultats, zone_lat, zone_lng)
  values (p_type, pid, p_pharmacie, t_stocke, res, zl, zg);
end $$;
revoke execute on function public.log_evenement(text, uuid, uuid, text, int, float8, float8) from public;
grant execute on function public.log_evenement(text, uuid, uuid, text, int, float8, float8) to anon, authenticated;

-- 2. Abonnements (revenus récurrents), réservés à l'admin.
create table if not exists public.abonnements (
  id uuid primary key default gen_random_uuid(),
  pharmacie_id uuid not null references public.pharmacies(id) on delete cascade,
  formule text not null check (formule in ('pilote','essentiel','pro')),
  montant_mensuel integer not null default 0 check (montant_mensuel >= 0),
  debut date not null default current_date,
  fin date,
  statut text not null default 'actif' check (statut in ('actif','resilie','impaye')),
  created_at timestamptz not null default now()
);
alter table public.abonnements enable row level security;
drop policy if exists abonnements_admin on public.abonnements;
create policy abonnements_admin on public.abonnements for all using ((select public.is_admin())) with check ((select public.is_admin()));
revoke all on table public.abonnements from anon, authenticated;
grant select, insert, update, delete on table public.abonnements to authenticated;

-- 3. Alertes (pharmacie_id nul = alerte pour l'équipe NAXA).
create table if not exists public.alertes (
  id bigserial primary key,
  pharmacie_id uuid references public.pharmacies(id) on delete cascade,
  type text not null,
  message text not null,
  lue boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists alertes_lecture on public.alertes (pharmacie_id, lue, created_at desc);
alter table public.alertes enable row level security;
drop policy if exists alertes_lecture on public.alertes;
drop policy if exists alertes_maj on public.alertes;
create policy alertes_lecture on public.alertes for select
  using ((select public.is_admin()) or pharmacie_id = (select public.my_pharmacie()));
create policy alertes_maj on public.alertes for update
  using ((select public.is_admin()) or pharmacie_id = (select public.my_pharmacie()))
  with check ((select public.is_admin()) or pharmacie_id = (select public.my_pharmacie()));
revoke all on table public.alertes from anon, authenticated;
grant select on table public.alertes to authenticated;
grant update (lue) on table public.alertes to authenticated;

-- 4. Rapports générés automatiquement.
create table if not exists public.rapports (
  id bigserial primary key,
  portee text not null check (portee in ('pharmacie','admin')),
  pharmacie_id uuid references public.pharmacies(id) on delete cascade,
  periode text not null check (periode in ('hebdo','mensuel')),
  du date not null,
  au date not null,
  contenu jsonb not null,
  texte text not null,
  created_at timestamptz not null default now()
);
create index if not exists rapports_lecture on public.rapports (pharmacie_id, created_at desc);
alter table public.rapports enable row level security;
drop policy if exists rapports_lecture on public.rapports;
create policy rapports_lecture on public.rapports for select
  using ((select public.is_admin()) or (portee = 'pharmacie' and pharmacie_id = (select public.my_pharmacie())));
revoke all on table public.rapports from anon, authenticated;
grant select on table public.rapports to authenticated;

-- 5. Statistiques d'une pharmacie (fonction interne, sans contrôle d'accès : jamais exposée directement).
create or replace function public._stats_pharmacie(p_ph uuid, p_jours int) returns jsonb
language sql stable security definer set search_path = public as $$
with fen as (select now() - make_interval(days => greatest(1, least(p_jours, 365))) as debut),
ph as (select id, lat, lng, stock_updated_at from public.pharmacies where id = p_ph),
resa as (select r.* from public.reservations r cross join fen where r.pharmacie_id = p_ph and r.created_at >= fen.debut),
ra as (
  select count(*)::int as total,
         count(*) filter (where statut = 'en_attente')::int as en_attente,
         count(*) filter (where statut in ('confirmee','payee'))::int as a_retirer,
         count(*) filter (where statut = 'retiree')::int as retirees,
         count(*) filter (where statut in ('expiree','annulee'))::int as perdues,
         coalesce(sum(total) filter (where statut in ('retiree','payee')), 0)::int as ca_estime
  from resa
),
mes as (select produit_id from public.stocks where pharmacie_id = p_ph and quantite > 0),
vues as (
  select count(*)::int as n from public.evenements e cross join fen
  where e.type = 'fiche_vue' and e.created_at >= fen.debut and e.produit_id in (select produit_id from mes)
),
demande as (
  select p.id as produit_id, p.nom, p.dosage, count(*)::int as n
  from public.evenements e
  join public.produits p on p.id = e.produit_id
  cross join ph cross join fen
  where e.type = 'recherche' and e.created_at >= fen.debut and e.zone_lat is not null
    and abs(e.zone_lat - ph.lat) < 0.03 and abs(e.zone_lng - ph.lng) < 0.03
    and e.produit_id not in (select produit_id from mes)
  group by p.id, p.nom, p.dosage
  having count(*) >= 3
  order by n desc limit 10
),
ruptures as (
  select p.nom, p.dosage, s.quantite
  from public.stocks s join public.produits p on p.id = s.produit_id
  where s.pharmacie_id = p_ph and s.quantite <= 3
  order by s.quantite, p.nom limit 20
),
prix as (
  select p.nom, p.dosage, mine.prix as mon_prix, med.mediane::int as mediane,
         round(((mine.prix - med.mediane) / nullif(med.mediane, 0) * 100)::numeric, 0)::int as ecart_pct
  from public.stocks mine
  join public.produits p on p.id = mine.produit_id
  join lateral (
    select percentile_cont(0.5) within group (order by s2.prix) as mediane, count(*) as n
    from public.stocks s2 join public.pharmacies ph2 on ph2.id = s2.pharmacie_id and ph2.actif
    where s2.produit_id = mine.produit_id and s2.pharmacie_id <> p_ph and s2.quantite > 0
  ) med on med.n >= 3
  where mine.pharmacie_id = p_ph and mine.quantite > 0
  order by abs(mine.prix - med.mediane) / nullif(med.mediane, 0) desc nulls last limit 10
),
serie as (
  select g::date as jour, count(r.id)::int as n
  from generate_series(current_date - (greatest(1, least(p_jours, 30)) - 1), current_date, interval '1 day') g
  left join public.reservations r on r.pharmacie_id = p_ph and r.created_at::date = g::date
  group by 1 order by 1
)
select jsonb_build_object(
  'jours', greatest(1, least(p_jours, 365)),
  'reservations', (select to_jsonb(ra) from ra),
  'taux_retrait', (select round(100.0 * retirees / nullif(retirees + perdues, 0))::int from ra),
  'fiches_vues', (select n from vues),
  'attente_longue', (select count(*)::int from public.reservations where pharmacie_id = p_ph and statut = 'en_attente' and created_at < now() - interval '20 minutes' and expires_at > now()),
  'stock_mis_a_jour', (select stock_updated_at from ph),
  'stock_age_heures', (select round(extract(epoch from now() - stock_updated_at) / 3600)::int from ph),
  'demande_non_servie', coalesce((select jsonb_agg(to_jsonb(d)) from demande d), '[]'::jsonb),
  'ruptures', coalesce((select jsonb_agg(to_jsonb(x)) from ruptures x), '[]'::jsonb),
  'prix_vs_mediane', coalesce((select jsonb_agg(to_jsonb(x)) from prix x), '[]'::jsonb),
  'serie', coalesce((select jsonb_agg(to_jsonb(x)) from serie x), '[]'::jsonb)
)
$$;

-- 6. Statistiques de l'équipe NAXA (fonction interne).
create or replace function public._stats_admin(p_jours int) returns jsonb
language sql stable security definer set search_path = public as $$
with fen as (select now() - make_interval(days => greatest(1, least(p_jours, 365))) as debut),
ph as (
  select count(*)::int as total,
         count(*) filter (where actif)::int as actives,
         count(*) filter (where actif and stock_updated_at >= now() - interval '7 days')::int as a_jour,
         count(*) filter (where actif and (stock_updated_at is null or stock_updated_at < now() - interval '7 days'))::int as a_risque
  from public.pharmacies
),
rech as (
  select count(*)::int as total,
         count(*) filter (where resultats > 0)::int as avec_resultat,
         count(*) filter (where resultats = 0)::int as sans_resultat
  from public.evenements e cross join fen where e.type = 'recherche' and e.created_at >= fen.debut
),
ent as (
  select
    (select count(*)::int from public.evenements e cross join fen where e.type = 'recherche' and e.created_at >= fen.debut) as recherches,
    (select count(*)::int from public.evenements e cross join fen where e.type = 'fiche_vue' and e.created_at >= fen.debut) as fiches_vues,
    (select count(*)::int from public.evenements e cross join fen where e.type = 'panier_ajout' and e.created_at >= fen.debut) as paniers,
    (select count(*)::int from public.reservations r cross join fen where r.created_at >= fen.debut) as reservations,
    (select count(*)::int from public.reservations r cross join fen where r.created_at >= fen.debut and r.statut = 'retiree') as retirees
),
top as (
  select p.nom, p.dosage, count(*)::int as n
  from public.evenements e join public.produits p on p.id = e.produit_id cross join fen
  where e.type = 'recherche' and e.created_at >= fen.debut
  group by p.nom, p.dosage order by n desc limit 10
),
sans as (
  select e.terme, count(*)::int as n
  from public.evenements e cross join fen
  where e.type = 'recherche' and e.resultats = 0 and e.terme is not null and e.created_at >= fen.debut
  group by e.terme having count(*) >= 3 order by n desc limit 15
),
zones as (
  select e.zone_lat as lat, e.zone_lng as lng, count(*)::int as n
  from public.evenements e cross join fen
  where e.type = 'recherche' and e.resultats = 0 and e.zone_lat is not null and e.created_at >= fen.debut
  group by e.zone_lat, e.zone_lng having count(*) >= 5 order by n desc limit 10
),
qual as (
  select count(*)::int as produits,
         count(*) filter (where description is null or description = '')::int as sans_fiche,
         count(*) filter (where description is not null and description <> '' and not fiche_validee)::int as a_relire,
         count(*) filter (where photo_url is null)::int as sans_photo
  from public.produits
),
classement as (
  select p.nom, p.quartier, count(r.id) filter (where r.created_at >= (select debut from fen))::int as reservations, p.stock_updated_at
  from public.pharmacies p left join public.reservations r on r.pharmacie_id = p.id
  where p.actif group by p.id, p.nom, p.quartier, p.stock_updated_at
  order by reservations desc, p.nom limit 20
),
abo as (
  select coalesce(sum(montant_mensuel) filter (where statut = 'actif'), 0)::int as mrr,
         count(*) filter (where statut = 'actif')::int as actifs,
         count(*) filter (where statut = 'actif' and formule = 'pilote')::int as pilotes,
         count(*) filter (where statut = 'impaye')::int as impayes
  from public.abonnements
),
serie as (
  select g::date as jour,
    (select count(*)::int from public.evenements e where e.type = 'recherche' and e.created_at::date = g::date) as recherches,
    (select count(*)::int from public.reservations r where r.created_at::date = g::date) as reservations
  from generate_series(current_date - (greatest(1, least(p_jours, 30)) - 1), current_date, interval '1 day') g
)
select jsonb_build_object(
  'jours', greatest(1, least(p_jours, 365)),
  'pharmacies', (select to_jsonb(ph) from ph),
  'recherches', (select to_jsonb(rech) from rech),
  'entonnoir', (select to_jsonb(ent) from ent),
  'top_recherches', coalesce((select jsonb_agg(to_jsonb(x)) from top x), '[]'::jsonb),
  'sans_resultat', coalesce((select jsonb_agg(to_jsonb(x)) from sans x), '[]'::jsonb),
  'zones_non_servies', coalesce((select jsonb_agg(to_jsonb(x)) from zones x), '[]'::jsonb),
  'qualite', (select to_jsonb(qual) from qual),
  'classement', coalesce((select jsonb_agg(to_jsonb(x)) from classement x), '[]'::jsonb),
  'abonnements', (select to_jsonb(abo) from abo),
  'serie', coalesce((select jsonb_agg(to_jsonb(x)) from serie x), '[]'::jsonb)
)
$$;

revoke execute on function public._stats_pharmacie(uuid, int) from public, anon, authenticated;
revoke execute on function public._stats_admin(int) from public, anon, authenticated;

-- 7. Fonctions publiques avec contrôle d'accès.
create or replace function public.stats_pharmacie(p_ph uuid, p_jours int default 7) returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  if not (public.is_admin() or coalesce(p_ph = public.my_pharmacie(), false)) then raise exception 'Accès refusé'; end if;
  return public._stats_pharmacie(p_ph, p_jours);
end $$;

create or replace function public.stats_admin(p_jours int default 7) returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  if not public.is_admin() then raise exception 'Accès refusé'; end if;
  return public._stats_admin(p_jours);
end $$;

revoke execute on function public.stats_pharmacie(uuid, int) from public, anon;
revoke execute on function public.stats_admin(int) from public, anon;
grant execute on function public.stats_pharmacie(uuid, int) to authenticated;
grant execute on function public.stats_admin(int) to authenticated;

-- 8. Alertes automatiques (toutes les 15 minutes).
create or replace function public.generer_alertes() returns int
language plpgsql security definer set search_path = public as $$
declare n int := 0; r record;
begin
  for r in select id, nom from public.pharmacies
           where actif and (stock_updated_at is null or stock_updated_at < now() - interval '7 days') loop
    if not exists (select 1 from public.alertes where pharmacie_id = r.id and type = 'stock_obsolete' and created_at > now() - interval '24 hours') then
      insert into public.alertes (pharmacie_id, type, message)
      values (r.id, 'stock_obsolete', 'Votre stock n''a pas été mis à jour depuis plus de 7 jours. Mettez-le à jour pour rester visible des clients.');
      insert into public.alertes (pharmacie_id, type, message)
      values (null, 'pharmacie_a_risque', r.nom || ' n''a pas mis à jour son stock depuis plus de 7 jours.');
      n := n + 1;
    end if;
  end loop;

  for r in select pharmacie_id, count(*)::int as c from public.reservations
           where statut = 'en_attente' and created_at < now() - interval '20 minutes' and expires_at > now()
           group by pharmacie_id loop
    if not exists (select 1 from public.alertes where pharmacie_id = r.pharmacie_id and type = 'resa_en_attente' and created_at > now() - interval '1 hour') then
      insert into public.alertes (pharmacie_id, type, message)
      values (r.pharmacie_id, 'resa_en_attente', r.c || ' réservation(s) attendent votre réponse depuis plus de 20 minutes.');
      n := n + 1;
    end if;
  end loop;

  for r in select s.pharmacie_id, left(string_agg(distinct p.nom, ', '), 200) as noms
           from public.stocks s join public.produits p on p.id = s.produit_id
           where s.quantite = 0
             and exists (select 1 from public.evenements e where e.type = 'recherche' and e.produit_id = s.produit_id and e.created_at > now() - interval '7 days')
           group by s.pharmacie_id loop
    if not exists (select 1 from public.alertes where pharmacie_id = r.pharmacie_id and type = 'rupture_demandee' and created_at > now() - interval '24 hours') then
      insert into public.alertes (pharmacie_id, type, message)
      values (r.pharmacie_id, 'rupture_demandee', 'Produits en rupture que les clients cherchent : ' || r.noms || '.');
      n := n + 1;
    end if;
  end loop;
  return n;
end $$;
revoke execute on function public.generer_alertes() from public, anon, authenticated;

-- 9. Rapports automatiques (texte rédigé par la base, sans IA).
create or replace function public.generer_rapports(p_periode text) returns int
language plpgsql security definer set search_path = public as $$
declare j int := case when p_periode = 'mensuel' then 30 else 7 end; r record; s jsonb; t text; n int := 0; dem text;
begin
  for r in select id, nom from public.pharmacies where actif loop
    continue when exists (select 1 from public.rapports where portee = 'pharmacie' and pharmacie_id = r.id and periode = p_periode and au = current_date);
    s := public._stats_pharmacie(r.id, j);
    t := format('Sur les %s derniers jours : %s réservation(s), dont %s retirée(s) et %s non retirée(s). Chiffre d''affaires estimé : %s FCFA. %s produit(s) en rupture ou presque.',
      j, s->'reservations'->>'total', s->'reservations'->>'retirees', s->'reservations'->>'perdues',
      s->'reservations'->>'ca_estime', jsonb_array_length(s->'ruptures'));
    select string_agg(q.x->>'nom', ', ') into dem
      from (select x from jsonb_array_elements(s->'demande_non_servie') x limit 3) q;
    if dem is not null then t := t || ' Les clients de votre zone cherchent aussi : ' || dem || '.'; end if;
    insert into public.rapports (portee, pharmacie_id, periode, du, au, contenu, texte)
    values ('pharmacie', r.id, p_periode, current_date - j, current_date, s, t);
    n := n + 1;
  end loop;

  if not exists (select 1 from public.rapports where portee = 'admin' and periode = p_periode and au = current_date) then
    s := public._stats_admin(j);
    t := format('Sur les %s derniers jours : %s recherche(s), dont %s sans résultat. %s réservation(s), %s retirée(s). %s pharmacie(s) active(s), %s à risque (stock non mis à jour depuis 7 jours). Revenu mensuel récurrent : %s FCFA.',
      j, s->'recherches'->>'total', s->'recherches'->>'sans_resultat', s->'entonnoir'->>'reservations', s->'entonnoir'->>'retirees',
      s->'pharmacies'->>'actives', s->'pharmacies'->>'a_risque', s->'abonnements'->>'mrr');
    insert into public.rapports (portee, periode, du, au, contenu, texte)
    values ('admin', p_periode, current_date - j, current_date, s, t);
    n := n + 1;
  end if;
  return n;
end $$;
revoke execute on function public.generer_rapports(text) from public, anon, authenticated;

-- 10. Temps réel : les réservations et alertes sont poussées aux écrans.
do $$
declare t text;
begin
  foreach t in array array['reservations', 'alertes'] loop
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = t) then
      execute format('alter publication supabase_realtime add table public.%I', t);
    end if;
  end loop;
end $$;

-- 11. Planification (pg_cron, heures en UTC). Les événements de plus de 400 jours sont purgés (minimisation des données).
do $$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    perform cron.schedule('naxa-alertes', '*/15 * * * *', 'select public.generer_alertes()');
    perform cron.schedule('naxa-rapport-hebdo', '0 6 * * 1', $q$select public.generer_rapports('hebdo')$q$);
    perform cron.schedule('naxa-rapport-mensuel', '0 6 1 * *', $q$select public.generer_rapports('mensuel')$q$);
    perform cron.schedule('naxa-purge-evenements', '30 3 * * *', $q$delete from public.evenements where created_at < now() - interval '400 days'$q$);
  end if;
end $$;
