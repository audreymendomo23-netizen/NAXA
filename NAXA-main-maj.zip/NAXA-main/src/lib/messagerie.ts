"use client";
import { useCallback, useEffect, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/client";

export type Notif = { id: string; type: string; titre: string; corps: string; fil_id: string | null; lu_le: string | null; created_at: string };
export type Msg = { id: string; fil_id: string; expediteur: "client" | "pharmacie"; corps: string; created_at: string };

/** Alerte système quand l'application est ouverte (la notification push application fermée nécessite Web Push : voir docs). */
export function alerteSysteme(titre: string, corps: string) {
  try {
    if (typeof Notification !== "undefined" && Notification.permission === "granted" && document.visibilityState !== "visible")
      new Notification(titre, { body: corps, icon: "/icon-192.png" });
  } catch { /* ignoré */ }
}

/** Notifications du compte (client) ou des pharmacies gérées, en temps réel. */
export function useNotifications(pharmacies?: string[]) {
  const [liste, setListe] = useState<Notif[]>([]);
  const charger = useCallback(async () => {
    const { data } = await supabaseBrowser().from("notifications").select("id,type,titre,corps,fil_id,lu_le,created_at")
      .order("created_at", { ascending: false }).limit(60);
    setListe((data ?? []) as Notif[]);
  }, []);
  useEffect(() => {
    void charger();
    const sb = supabaseBrowser();
    const canal = sb.channel("notifs-" + Math.random().toString(36).slice(2))
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "notifications" }, (p) => {
        const n = p.new as Notif; setListe((l) => [n, ...l]); alerteSysteme(n.titre, n.corps);
      }).subscribe();
    return () => { void sb.removeChannel(canal); };
  }, [charger, (pharmacies ?? []).join("|")]);
  return { liste, nonLues: liste.filter((n) => !n.lu_le).length, recharger: charger };
}
