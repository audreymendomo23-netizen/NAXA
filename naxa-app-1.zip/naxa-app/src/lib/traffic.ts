// Pas de trafic en direct gratuit au Cameroun : on fournit une ESTIMATION selon l'heure.
// Toujours afficher le libellé "estimation" à l'utilisateur.
export type Circulation = { niveau: "fluide" | "dense" | "tres_dense"; facteur: number; message: string };

export function estimerCirculation(date = new Date()): Circulation {
  const h = date.getHours() + date.getMinutes() / 60;
  const jour = date.getDay(); // 0 = dimanche
  const semaine = jour >= 1 && jour <= 5;
  const pointe = (h >= 7 && h < 9.5) || (h >= 16.5 && h < 19.5);
  if (semaine && pointe) {
    const tres = (h >= 17 && h < 19) || (jour === 5 && h >= 16.5);
    return tres
      ? { niveau: "tres_dense", facteur: 1.8, message: "Heure de pointe : embouteillages probables (estimation)." }
      : { niveau: "dense", facteur: 1.5, message: "Circulation dense probable (estimation)." };
  }
  return { niveau: "fluide", facteur: 1, message: "Circulation probablement fluide (estimation)." };
}
