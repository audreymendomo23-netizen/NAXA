"use client";
import { useState } from "react";
import { importerStock } from "@/lib/importStock";

export function ImportAdmin({ pharmacies }: { pharmacies: { id: string; nom: string }[] }) {
  const [id, setId] = useState(pharmacies[0]?.id ?? "");
  const [msg, setMsg] = useState("");
  async function go(f: File) {
    setMsg("Import en cours…");
    try { const r = await importerStock(f, id); setMsg(`${r.importes} produits importés, ${r.ignores} lignes ignorées sur ${r.lus}.`); }
    catch { setMsg("Import impossible : vérifiez les colonnes (nom, prix, quantité)."); }
  }
  return (
    <div className="carte space-y-3">
      <h2 className="text-lg font-bold">Migrer le stock d'une pharmacie (Excel / CSV)</h2>
      <select className="champ" value={id} onChange={(e) => setId(e.target.value)} aria-label="Pharmacie">
        {pharmacies.map((p) => <option key={p.id} value={p.id}>{p.nom}</option>)}
      </select>
      <label className="btn btn-vert cursor-pointer">Choisir le fichier<input type="file" hidden accept=".xlsx,.xls,.csv" onChange={(e) => e.target.files?.[0] && go(e.target.files[0])} /></label>
      {msg && <p role="status" className="text-sm">{msg}</p>}
    </div>
  );
}
