# NAXA : base de l'application

Votre médicament, à 2 minutes. Next.js 14 + Supabase + Tailwind, PWA, 100 % offre gratuite.

## Démarrage
1. `npm install`
2. Créer un projet Supabase (gratuit). Dans **Database > Extensions**, activer `pg_cron`.
3. Dans l'éditeur SQL, exécuter dans cet ordre : `supabase/schema.sql`, puis `supabase/migration_002_catalogue_panier.sql` (fiches produits, photos, dictionnaire, panier, « les plus recherchés »), puis (démo seulement) `supabase/seed.sql`.
4. Planifier l'expiration des réservations : `select cron.schedule('naxa-expire', '*/5 * * * *', $$select public.expire_reservations()$$);`
5. Copier `.env.example` vers `.env.local` et renseigner les 3 clés (Settings > API). La clé `service_role` ne doit jamais être exposée. Facultatif : `GEMINI_API_KEY` (gratuite, aistudio.google.com) pour les brouillons de fiches par IA.
6. Authentication > SMTP : brancher un SMTP gratuit (ex. Brevo) car l'envoi d'e-mails intégré de Supabase est très limité.
7. `npm run dev`, se connecter avec votre e-mail (code reçu), puis dans l'éditeur SQL :
   `update profiles set role = 'admin' where id = '<votre UUID>';`
8. Ouvrir `/admin` : créer une pharmacie (compte + WhatsApp + code marchand), importer son stock Excel, former la pharmacie.

## Ce qui est en place
Recherche et scan d'ordonnance (OCR dans le navigateur), classement prix / distance / temps, estimation de circulation, réservation 3 h, WhatsApp via `/go/[id]` (numéro lu côté serveur), paiement guidé par code marchand, reçu imprimable, panneau pharmacie, espace admin.

## Nouveau (version 2)
- **Fiche produit** `/produit/[id]` : photo, description, à quoi ça sert, précautions, « mots utiles » (dictionnaire), stock et prix dès. Au clic sur un médicament dans les résultats ou le bandeau.
- **Panier** `/panier` : quantités, gardé sur le téléphone (rien n'est envoyé). « Trouver les pharmacies qui ont tout » : seules comptent les pharmacies qui ont la quantité demandée. La réservation reprend les quantités.
- **Bandeau défilant « Les plus recherchés »** en haut des pages publiques, calculé sur les recherches des 7 derniers jours (complété par les produits les plus disponibles au lancement). Pause, arrêt automatique si le téléphone réduit les animations. Ce n'est pas une publicité vendue.
- **Admin > Fiches produits** `/admin/produits` : photo (compressée dans le navigateur, bucket Storage `produits-photos`), textes, synonymes de recherche, **brouillon IA** (serveur, équipe NAXA seulement), case « relue par un pharmacien ». Tant que la case n'est pas cochée, la fiche s'affiche « en cours de relecture ».
- **Dictionnaire** : table `dictionnaire` (mots simples) et import optionnel de la BDPM (noms, molécules, dosages, formes) : `node scripts/importer-bdpm.mjs CIS_bdpm.txt CIS_COMPO_bdpm.txt > produits_bdpm.csv`.

Aucune photo de médicament n'est fournie : à ajouter par l'équipe NAXA (droits d'usage à vérifier).

## Reste à faire (voir PROMPT_CHATGPT_NAXA.md)
Mode hors-ligne du panneau pharmacie (file d'attente locale), tests, rapport quotidien, page carte, durcissement sécurité.

Version 2 : la syntaxe TypeScript a été contrôlée, mais ni la compilation complète, ni le SQL, ni l'API IA n'ont été exécutés.
Ce code n'a pas été exécuté ni compilé (pas d'installation possible lors de sa génération) : lancer `npm install && npm run build` et corriger les éventuelles erreurs en premier.
