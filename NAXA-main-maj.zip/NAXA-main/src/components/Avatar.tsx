/* Avatar client : photo si configurée, sinon initiales. Coche bleue = profil vérifié. */
export function CocheVerifie({ taille = 18 }: { taille?: number }) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={taille}
      height={taille}
      role="img"
      aria-label="Profil vérifié"
      className="shrink-0"
    >
      <title>Profil vérifié</title>
      <circle cx="12" cy="12" r="11" fill="#1D9BF0" stroke="#fff" strokeWidth="2" />
      <path d="M7 12.5l3.2 3.2L17 8.8" fill="none" stroke="#fff" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Avatar({
  initiales,
  photoUrl,
  verifie,
  taille = 44,
  className = "",
}: {
  initiales: string;
  photoUrl: string | null;
  verifie: boolean;
  taille?: number;
  className?: string;
}) {
  const coche = Math.max(14, Math.round(taille * 0.4));
  return (
    <span
      className={`relative inline-flex shrink-0 ${className}`}
      style={{ width: taille, height: taille }}
    >
      {photoUrl ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={photoUrl}
          alt=""
          width={taille}
          height={taille}
          className="h-full w-full rounded-full border border-white/40 object-cover"
        />
      ) : (
        <span
          aria-hidden="true"
          className="flex h-full w-full items-center justify-center rounded-full border border-white/40 bg-naxa-green-700 font-extrabold text-naxa-canari"
          style={{ fontSize: Math.round(taille * 0.38) }}
        >
          {initiales}
        </span>
      )}
      {verifie && (
        <span className="absolute -bottom-0.5 -right-0.5 rounded-full bg-white leading-none">
          <CocheVerifie taille={coche} />
        </span>
      )}
    </span>
  );
}
