-- Données de DÉMO (pharmacies fictives, coordonnées approximatives de Yaoundé). Ne pas utiliser en production.
insert into pharmacies (id, nom, quartier, adresse, lat, lng, de_garde, stock_updated_at) values
  ('00000000-0000-0000-0000-000000000001', 'Pharmacie Démo Centre', 'Centre-ville', 'Démo', 3.8667, 11.5167, true, now()),
  ('00000000-0000-0000-0000-000000000002', 'Pharmacie Démo Mvan', 'Mvan', 'Démo', 3.8190, 11.5170, false, now()),
  ('00000000-0000-0000-0000-000000000003', 'Pharmacie Démo Biyem-Assi', 'Biyem-Assi', 'Démo', 3.8300, 11.4900, false, now());

insert into pharmacie_privee (pharmacie_id, whatsapp, code_marchand) values
  ('00000000-0000-0000-0000-000000000001', '237600000001', '000001'),
  ('00000000-0000-0000-0000-000000000002', '237600000002', '000002'),
  ('00000000-0000-0000-0000-000000000003', '237600000003', '000003');

insert into produits (nom, dci, dosage, forme) values
  ('Doliprane', 'Paracétamol', '500 mg', 'comprimé'),
  ('Efferalgan', 'Paracétamol', '500 mg', 'comprimé'),
  ('Amoxicilline', 'Amoxicilline', '500 mg', 'gélule');

insert into stocks (pharmacie_id, produit_id, prix, quantite)
select ph.id, pr.id, 1000 + (random() * 800)::int, 3 + (random() * 20)::int
from pharmacies ph cross join produits pr;

-- ---------- Démo fiches (migration 002) : textes de démonstration, NON vérifiés, sans photo ----------
update produits set
  synonymes = array['paracetamol', 'acetaminophen'],
  description = 'Médicament à base de paracétamol, utilisé contre la douleur et la fièvre.',
  indications = 'Douleurs légères à modérées (maux de tête, douleurs dentaires, courbatures) et fièvre.',
  precautions = 'Ne pas associer plusieurs produits contenant du paracétamol. Respectez la dose de la notice ou de l''ordonnance. Demandez conseil au pharmacien en cas de maladie du foie, de grossesse ou pour un enfant.',
  source_fiche = 'admin', fiche_validee = false, fiche_maj = now()
where nom in ('Doliprane', 'Efferalgan');

update produits set
  description = 'Antibiotique de la famille des pénicillines.',
  indications = 'Certaines infections dues à des bactéries, uniquement quand un professionnel de santé l''a décidé.',
  precautions = 'Médicament délivré sur ordonnance. Ne jamais le prendre sans avis médical. Signalez toute allergie à la pénicilline.',
  source_fiche = 'admin', fiche_validee = false, fiche_maj = now()
where nom = 'Amoxicilline';
