"use client";
import { useEffect, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/client";
import { useNotifications } from "@/lib/messagerie";
import { FilMessages } from "@/components/FilMessages";
type Ligne = { fil_id: string; libelle: string; dernier: string | null; dernier_le: string | null; non_lus: number };

export default function MessagesPharmacie() {
  const [pharmacies, setPharmacies] = useState<string[]>([]), [lignes, setLignes] = useState<Ligne[]>([]), [fil, setFil] = useState<{ id: string; titre: string } | null>(null), [erreur, setErreur] = useState("");
  const { liste } = useNotifications(pharmacies);
  useEffect(() => { (async () => { const { data, error } = await supabaseBrowser().rpc("my_pharmacies"); if (error) return setErreur("Accès refusé."); setPharmacies((data ?? []) as string[]); })(); }, []);
  useEffect(() => { (async () => {
    const tout: Ligne[] = [];
    for (const id of pharmacies) { const { data } = await supabaseBrowser().rpc("boite_pharmacie", { p_pharmacie: id }); tout.push(...((data ?? []) as Ligne[])); }
    setLignes(tout);
  })(); }, [pharmacies, liste.length, fil]);
  return <main className="mx-auto min-h-screen max-w-2xl px-4 pb-16"><h1 className="my-4 text-2xl font-black">Messages clients</h1>
    {erreur && <p role="alert" className="carte text-red-800">{erreur}</p>}
    {fil ? <FilMessages filId={fil.id} moi="pharmacie" titre={fil.titre} onRetour={() => setFil(null)} /> :
      lignes.length === 0 ? <p className="carte text-sm text-slate-600">Aucun message pour le moment.</p> :
      <ul className="space-y-2">{lignes.map((l) => <li key={l.fil_id}><button type="button" className="carte w-full text-left" onClick={() => setFil({ id: l.fil_id, titre: l.libelle })}>
        <div className="flex justify-between gap-2"><p className="font-bold">{l.libelle}</p>{l.non_lus > 0 && <span className="rounded-full bg-naxa-canari px-2 text-xs font-black">{l.non_lus}</span>}</div>
        <p className="truncate text-sm text-slate-600">{l.dernier}</p></button></li>)}</ul>}
  </main>;
}
