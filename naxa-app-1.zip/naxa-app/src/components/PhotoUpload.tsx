"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/client";

/** Réduit la photo dans le navigateur (600 px, WebP) avant l'envoi : pages légères sur réseau lent. Réservé à l'équipe NAXA. */
async function reduire(f: File): Promise<Blob> {
  const bmp = await createImageBitmap(f);
  const ratio = Math.min(1, 600 / Math.max(bmp.width, bmp.height));
  const c = document.createElement("canvas");
  c.width = Math.round(bmp.width * ratio);
  c.height = Math.round(bmp.height * ratio);
  c.getContext("2d")!.drawImage(bmp, 0, 0, c.width, c.height);
  return new Promise((ok, ko) => c.toBlob((b) => (b ? ok(b) : ko(new Error("compression"))), "image/webp", 0.8));
}

export function PhotoUpload({ produitId, photoUrl }: { produitId: string; photoUrl: string | null }) {
  const router = useRouter();
  const [etat, setEtat] = useState<"repos" | "envoi" | "ok" | "erreur">("repos");

  async function envoyer(f: File) {
    setEtat("envoi");
    try {
      const sb = supabaseBrowser();
      const blob = await reduire(f);
      const chemin = `${produitId}-${Date.now()}.webp`;
      const { error } = await sb.storage.from("produits-photos").upload(chemin, blob, { contentType: "image/webp" });
      if (error) throw error;
      const { data } = sb.storage.from("produits-photos").getPublicUrl(chemin);
      const { error: e2 } = await sb.from("produits").update({ photo_url: data.publicUrl }).eq("id", produitId);
      if (e2) throw e2;
      setEtat("ok");
      router.refresh();
    } catch {
      setEtat("erreur");
    }
  }

  return (
    <div className="flex items-center gap-3">
      {photoUrl ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={photoUrl} alt="" width={64} height={64} className="h-16 w-16 rounded-lg bg-white object-contain" />
      ) : (
        <span className="flex h-16 w-16 items-center justify-center rounded-lg bg-naxa-green-100 text-xs">Aucune</span>
      )}
      <label className="btn btn-clair cursor-pointer text-sm">
        {etat === "envoi" ? "Envoi…" : photoUrl ? "Changer la photo" : "Ajouter une photo"}
        <input type="file" accept="image/*" hidden disabled={etat === "envoi"} onChange={(e) => e.target.files?.[0] && envoyer(e.target.files[0])} />
      </label>
      {etat === "erreur" && <span role="alert" className="text-sm text-red-700">Échec de l'envoi.</span>}
    </div>
  );
}
