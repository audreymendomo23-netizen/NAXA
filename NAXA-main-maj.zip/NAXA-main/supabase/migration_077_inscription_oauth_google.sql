-- NAXA 077 — inscription Google (OAuth) : le déclencheur n'exigeait que les champs du formulaire e-mail
-- (nom d'utilisateur, téléphone, date de naissance, consentement) et refusait donc tout compte Google
-- ("Database error saving new user"), ce qui ramenait l'utilisateur sur /connexion sans message.
-- Les comptes OAuth sont créés avec un profil client NON validé (age_verified=false) : l'âge et le
-- consentement sont ensuite recueillis par /verification-age avant toute action protégée.
-- Le parcours e-mail reste strictement identique (règles de la migration 074).
begin;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_provider text := lower(coalesce(new.raw_app_meta_data->>'provider', 'email'));
  v_meta jsonb := coalesce(new.raw_user_meta_data, '{}'::jsonb);
  v_username text := lower(trim(v_meta->>'username'));
  v_first_name text := trim(v_meta->>'first_name');
  v_last_name text := trim(v_meta->>'last_name');
  v_phone text := trim(v_meta->>'phone');
  v_country text := upper(trim(v_meta->>'phone_country'));
  v_dob date;
  v_consent boolean := coalesce((v_meta->>'consent_accepted')::boolean, false);
  v_full text;
begin
  if v_provider <> 'email' then
    v_full := trim(coalesce(v_meta->>'full_name', v_meta->>'name', ''));
    v_first_name := nullif(trim(coalesce(v_meta->>'given_name', split_part(v_full, ' ', 1))), '');
    v_last_name := nullif(trim(coalesce(v_meta->>'family_name', nullif(substr(v_full, length(split_part(v_full, ' ', 1)) + 2), ''))), '');
    insert into public.profiles(id, role, username, first_name, last_name, age_verified)
    values (
      new.id, 'client',
      'g' || substr(replace(new.id::text, '-', ''), 1, 12),
      left(coalesce(v_first_name, 'Client'), 80),
      left(coalesce(v_last_name, 'NAXA'), 80),
      false
    )
    on conflict (id) do nothing;
    return new;
  end if;

  v_dob := (v_meta->>'date_of_birth')::date;
  if v_username is null or v_username !~ '^[a-z0-9][a-z0-9._-]{2,29}$' then
    raise exception 'Nom d''utilisateur invalide';
  end if;
  if exists (select 1 from public.profiles where lower(username) = v_username) then
    raise exception 'Nom d''utilisateur déjà pris';
  end if;
  if v_first_name is null or length(v_first_name) < 2 or length(v_first_name) > 80 then
    raise exception 'Prénom invalide';
  end if;
  if v_last_name is null or length(v_last_name) < 2 or length(v_last_name) > 80 then
    raise exception 'Nom invalide';
  end if;
  if v_dob is null or v_dob > current_date or extract(year from age(current_date, v_dob)) < 18 then
    raise exception 'NAXA est réservé aux personnes âgées de 18 ans ou plus';
  end if;
  if not v_consent then
    raise exception 'L''acceptation des conditions est obligatoire';
  end if;
  if v_country is null or v_country not in ('CM','CF','TD','CG','CD','GQ','GA','ST','AO','BI','RW') then
    raise exception 'Pays non pris en charge';
  end if;
  if not private.naxa_phone_valid_for_country(v_country, v_phone) then
    raise exception 'Numéro de téléphone invalide pour le pays sélectionné';
  end if;

  insert into public.profiles(
    id, role, username, first_name, last_name, phone, phone_country,
    date_of_birth, age_verified, consent_accepted_at
  )
  values (
    new.id, 'client', v_username, v_first_name, v_last_name, v_phone, v_country,
    v_dob, true, now()
  );
  return new;
end;
$function$;

commit;
