"use server";
import { redirect } from "next/navigation";
import { supabaseAdmin, supabaseServer } from "@/lib/supabase/server";

async function exigerAdmin() {
  const sb = supabaseServer();
  const { data: u } = await sb.auth.getUser();
  if (!u.user) redirect("/connexion?retour=/admin");
  const { data: p } = await sb.from("profiles").select("role").eq("id", u.user.id).single();
  if (p?.role !== "admin") redirect("/");
}

/** L'équipe NAXA crée la pharmacie, son accès (e-mail + mot de passe provisoire) et ses données privées. */
export async function creerPharmacie(formData: FormData) {
  await exigerAdmin();
  const f = (k: string) => String(formData.get(k) ?? "").trim();
  const db = supabaseAdmin();

  const { data: ph, error } = await db.from("pharmacies").insert({
    nom: f("nom"), ville: f("ville") || "Yaoundé", quartier: f("quartier"), adresse: f("adresse"),
    lat: Number(f("lat")), lng: Number(f("lng")),
  }).select("id").single();
  if (error || !ph) redirect("/admin?erreur=pharmacie");

  await db.from("pharmacie_privee").insert({ pharmacie_id: ph.id, whatsapp: f("whatsapp").replace(/\D/g, ""), code_marchand: f("code_marchand") || null });

  const { data: user, error: e2 } = await db.auth.admin.createUser({ email: f("email"), password: f("motdepasse"), email_confirm: true });
  if (e2 || !user.user) redirect("/admin?erreur=compte");
  await db.from("profiles").update({ role: "pharmacie", pharmacie_id: ph.id }).eq("id", user.user.id);

  redirect("/admin?ok=1");
}
