"use client";
import { useEffect, useRef } from "react";

export function Tuile({ titre, valeur, note, alerte }: { titre: string; valeur: string | number; note?: string; alerte?: boolean }) {
  return (
    <div className={`rounded-xl2 border p-3 ${alerte ? "border-red-300 bg-red-50" : "border-naxa-green-100 bg-white"}`}>
      <p className="text-xs text-slate-600">{titre}</p>
      <p className="text-2xl font-extrabold">{valeur}</p>
      {note && <p className="text-xs text-slate-500">{note}</p>}
    </div>
  );
}

export function Section({ titre, children, action }: { titre: string; children: React.ReactNode; action?: React.ReactNode }) {
  return (
    <section className="carte space-y-2">
      <div className="flex items-center justify-between gap-2"><h2 className="font-bold">{titre}</h2>{action}</div>
      {children}
    </section>
  );
}

/** Barres simples (sans bibliothèque) : une valeur par jour. */
export function Barres({ points, etiquette }: { points: { jour: string; n: number }[]; etiquette: string }) {
  const max = Math.max(1, ...points.map((p) => p.n));
  return (
    <div role="img" aria-label={etiquette} className="flex h-24 items-end gap-1">
      {points.map((p) => (
        <div key={p.jour} className="flex flex-1 flex-col items-center justify-end" title={`${p.jour} : ${p.n}`}>
          <div className="w-full rounded-t bg-naxa-green-600" style={{ height: `${Math.max(4, (p.n / max) * 100)}%` }} />
        </div>
      ))}
    </div>
  );
}

export function Liste({ lignes, vide }: { lignes: { cle: string; texte: string; valeur?: string }[]; vide: string }) {
  if (!lignes.length) return vide ? <p className="text-sm text-slate-600">{vide}</p> : null;
  return (
    <ul className="divide-y divide-naxa-green-100">
      {lignes.map((l) => (
        <li key={l.cle} className="flex justify-between gap-3 py-2 text-sm"><span>{l.texte}</span>{l.valeur && <span className="font-semibold">{l.valeur}</span>}</li>
      ))}
    </ul>
  );
}

export function exporterCsv(nom: string, lignes: Record<string, unknown>[]) {
  if (!lignes.length) return;
  const cols = Object.keys(lignes[0]);
  const esc = (v: unknown) => `"${String(v ?? "").replace(/"/g, '""').replace(/^([=+\-@])/, "'$1")}"`;
  const csv = [cols.join(","), ...lignes.map((l) => cols.map((c) => esc(l[c])).join(","))].join("\n");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8" }));
  a.download = `${nom}-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(a.href);
}

/** Appelle `rafraichir` toutes les 15 s et dès qu'un changement est poussé par la base. */
export function useTempsReel(rafraichir: () => void, abonner: (rappel: () => void) => () => void) {
  const ref = useRef(rafraichir);
  ref.current = rafraichir;
  useEffect(() => {
    const appel = () => ref.current();
    appel();
    const t = setInterval(appel, 15000);
    const quitter = abonner(appel);
    return () => { clearInterval(t); quitter(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
}
