"use client";
import Link from "next/link";
import { useState } from "react";
import { MAX_QTE, usePanier } from "@/lib/panier";

export function AjouterPanier({ produit }: { produit: { produit_id: string; nom: string; dosage: string } }) {
  const { ajouter, lignes } = usePanier();
  const [qte, setQte] = useState(1);
  const [ajoute, setAjoute] = useState(false);
  const dansPanier = lignes.find((l) => l.produit_id === produit.produit_id)?.quantite ?? 0;

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <span className="font-semibold" id="lbl-qte">Quantité</span>
        <div className="flex items-center gap-2" role="group" aria-labelledby="lbl-qte">
          <button type="button" className="btn btn-clair !px-0 w-12" onClick={() => setQte(Math.max(1, qte - 1))} aria-label="Moins">−</button>
          <output className="w-8 text-center text-xl font-extrabold" aria-live="polite">{qte}</output>
          <button type="button" className="btn btn-clair !px-0 w-12" onClick={() => setQte(Math.min(MAX_QTE, qte + 1))} aria-label="Plus">+</button>
        </div>
      </div>
      <button type="button" className="btn btn-vert w-full" onClick={() => { ajouter(produit, qte); setAjoute(true); }}>
        Ajouter au panier
      </button>
      {(ajoute || dansPanier > 0) && (
        <p role="status" className="text-sm">
          {dansPanier} dans votre panier. <Link href="/panier" className="font-semibold underline underline-offset-4">Voir mon panier</Link>
        </p>
      )}
    </div>
  );
}
