"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { MAX_QTE, usePanier } from "@/lib/panier";
import { Logo } from "@/components/Logo";

export default function Panier() {
  const router = useRouter();
  const { lignes, pret, changerQuantite, retirer, vider } = usePanier();

  const chercher = () => {
    const p = new URLSearchParams();
    lignes.forEach((l) => p.append("p", `${l.produit_id}:${l.quantite}`));
    router.push(`/resultats?${p.toString()}`);
  };

  return (
    <main className="mx-auto max-w-lg px-4 pb-16">
      <header className="-mx-4 mb-4 flex items-center justify-between bg-naxa-green-900 px-4 py-3">
        <Link href="/"><Logo taille={32} /></Link>
        <Link href="/" className="text-sm font-semibold text-white underline underline-offset-4">Ajouter un médicament</Link>
      </header>
      <h1 className="text-2xl font-extrabold">Mon panier</h1>
      <p className="mt-1 text-sm text-slate-600">Le panier reste sur votre téléphone. Il sert à trouver les pharmacies qui ont tout. Réserver et payer restent facultatifs.</p>

      {!pret && <p className="mt-6">Chargement…</p>}
      {pret && lignes.length === 0 && (
        <div className="carte mt-6">
          <p className="font-bold">Votre panier est vide.</p>
          <p className="mt-1 text-slate-600">Cherchez un médicament, ouvrez sa fiche et touchez « Ajouter au panier ».</p>
          <Link href="/" className="btn btn-vert mt-4 w-full">Chercher un médicament</Link>
        </div>
      )}

      {lignes.length > 0 && (
        <>
          <ul className="mt-6 space-y-3">
            {lignes.map((l) => (
              <li key={l.produit_id} className="carte">
                <Link href={`/produit/${l.produit_id}`} className="font-bold underline underline-offset-4">{l.nom} {l.dosage}</Link>
                <div className="mt-3 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2" role="group" aria-label={`Quantité de ${l.nom}`}>
                    <button className="btn btn-clair !px-0 w-12" onClick={() => changerQuantite(l.produit_id, l.quantite - 1)} aria-label="Moins" disabled={l.quantite <= 1}>−</button>
                    <output className="w-8 text-center text-xl font-extrabold" aria-live="polite">{l.quantite}</output>
                    <button className="btn btn-clair !px-0 w-12" onClick={() => changerQuantite(l.produit_id, l.quantite + 1)} aria-label="Plus" disabled={l.quantite >= MAX_QTE}>+</button>
                  </div>
                  <button className="min-h-[48px] px-3 text-sm font-semibold text-red-700 underline underline-offset-4" onClick={() => retirer(l.produit_id)}>Retirer</button>
                </div>
              </li>
            ))}
          </ul>
          <button className="btn btn-vert mt-6 w-full" onClick={chercher}>Trouver les pharmacies qui ont tout</button>
          <button className="mt-3 min-h-[48px] w-full text-sm font-semibold underline underline-offset-4" onClick={vider}>Vider le panier</button>
          <p className="mt-6 text-xs text-slate-500">Information de disponibilité, pas un avis médical. Le pharmacien reste seul juge du médicament délivré.</p>
        </>
      )}
    </main>
  );
}
