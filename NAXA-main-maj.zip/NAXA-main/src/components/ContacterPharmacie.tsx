"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/client";

type Props = { pharmacieId: string; produitId?: string; variant?: "flottant" | "bouton" };
export function ContacterPharmacie({ pharmacieId, produitId, variant = "flottant" }: Props) {
  const router = useRouter();
  const [ouvert, setOuvert] = useState(false), [texte, setTexte] = useState(""), [anonyme, setAnonyme] = useState(true);
  const [etat, setEtat] = useState<"saisie" | "envoi" | "envoye">("saisie"), [erreur, setErreur] = useState("");
  useEffect(() => { (async () => {
    const sb = supabaseBrowser(); const { data: u } = await sb.auth.getUser(); if (!u.user) return;
    const { data } = await sb.from("client_preferences").select("anonyme_defaut").eq("user_id", u.user.id).maybeSingle();
    if (data) setAnonyme(data.anonyme_defaut);
  })(); }, []);
  async function ouvrir() {
    const { data } = await supabaseBrowser().auth.getUser();
    if (!data.user) return router.push("/connexion?retour=" + encodeURIComponent(location.pathname + location.search));
    setEtat("saisie"); setErreur(""); setOuvert(true);
  }
  async function envoyer() {
    const corps = texte.trim(); if (!corps) return setErreur("Écrivez votre message.");
    setEtat("envoi"); setErreur("");
    const { error } = await supabaseBrowser().rpc("envoyer_message_client", { p_pharmacie: pharmacieId, p_produit: produitId ?? null, p_corps: corps, p_anonyme: anonyme });
    if (error) { setEtat("saisie"); return setErreur("Envoi impossible pour le moment. Réessayez dans un instant."); }
    setTexte(""); setEtat("envoye");
  }
  return <>
    {variant === "flottant"
      ? <button type="button" onClick={ouvrir} aria-label="Contacter la pharmacie" className="fixed bottom-24 right-4 z-30 flex h-16 w-16 items-center justify-center rounded-full bg-naxa-canari text-naxa-green-900 shadow-lg"><svg viewBox="0 0 24 24" className="h-8 w-8" fill="currentColor" aria-hidden="true"><path d="M4 4h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H9l-5 4v-4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z" /></svg></button>
      : <button type="button" onClick={ouvrir} className="btn btn-clair flex-1">Contacter</button>}
    {ouvert && <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 p-3 sm:items-center" role="dialog" aria-modal="true" aria-label="Contacter la pharmacie" onClick={(e) => { if (e.target === e.currentTarget) setOuvert(false); }}>
      <div className="carte w-full max-w-sm space-y-3">
        <h2 className="text-xl font-extrabold">Contacter la pharmacie</h2>
        {etat === "envoye" ? <>
          <p className="text-sm">Message envoyé. La réponse arrivera dans vos notifications.</p>
          <Link href="/notifications" className="btn btn-vert w-full">Voir mes notifications</Link>
          <button type="button" className="btn btn-clair w-full" onClick={() => setOuvert(false)}>Fermer</button></> : <>
          <textarea className="champ min-h-[96px] w-full" maxLength={1000} value={texte} onChange={(e) => setTexte(e.target.value)} placeholder="Votre message…" aria-label="Votre message" />
          <p className="text-xs text-slate-500">Ne partagez aucune information médicale sensible. NAXA n'indique jamais de dose.</p>
          {erreur && <p role="alert" className="text-sm text-red-700">{erreur}</p>}
          <div className="flex items-center justify-between gap-3">
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={anonyme} onChange={(e) => setAnonyme(e.target.checked)} />Rester anonyme</label>
            <button type="button" className="btn btn-canari" disabled={etat === "envoi"} onClick={envoyer}>{etat === "envoi" ? "Envoi…" : "Envoyer"}</button></div>
          <button type="button" className="text-sm underline" onClick={() => setOuvert(false)}>Annuler</button></>}
      </div></div>}
  </>;
}
