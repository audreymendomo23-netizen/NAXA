import type { Trajet } from "./types";
import { estimerCirculation } from "./traffic";

// OSRM public (gratuit, sans clé). Usage léger uniquement : prévoir un hébergement propre si le trafic augmente.
export async function calculerTrajet(
  de: { lat: number; lng: number },
  vers: { lat: number; lng: number },
  distanceVolOiseauKm: number
): Promise<Trajet> {
  const facteur = estimerCirculation().facteur;
  try {
    const url = `https://router.project-osrm.org/route/v1/driving/${de.lng},${de.lat};${vers.lng},${vers.lat}?overview=false`;
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 4000);
    const r = await fetch(url, { signal: ctrl.signal });
    clearTimeout(t);
    const j = await r.json();
    const route = j.routes?.[0];
    if (!route) throw new Error("no route");
    return { km: route.distance / 1000, minutes: Math.max(1, Math.round((route.duration / 60) * facteur)), estime: false };
  } catch {
    // Repli hors-ligne : distance × 1,4 à 20 km/h de moyenne en ville.
    const km = distanceVolOiseauKm * 1.4;
    return { km, minutes: Math.max(1, Math.round((km / 20) * 60 * facteur)), estime: true };
  }
}

export function lienItineraire(de: { lat: number; lng: number }, vers: { lat: number; lng: number }) {
  return `https://www.openstreetmap.org/directions?engine=fossgis_osrm_car&route=${de.lat}%2C${de.lng}%3B${vers.lat}%2C${vers.lng}`;
}
