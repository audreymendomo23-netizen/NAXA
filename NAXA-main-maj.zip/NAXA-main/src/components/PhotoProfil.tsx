"use client";

import { useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/client";

async function reduire(f: File): Promise<Blob> {
  const bmp = await createImageBitmap(f);
  const cote = Math.min(bmp.width, bmp.height);
  const sortie = Math.min(400, cote);
  const c = document.createElement("canvas");
  c.width = sortie;
  c.height = sortie;
  const ctx = c.getContext("2d");
  if (!ctx) throw new Error("canvas");
  ctx.drawImage(bmp, (bmp.width - cote) / 2, (bmp.height - cote) / 2, cote, cote, 0, 0, sortie, sortie);
  return new Promise((ok, ko) =>
    c.toBlob((b) => (b ? ok(b) : ko(new Error("compression"))), "image/webp", 0.8),
  );
}

export function PhotoProfil({
  userId,
  possedePhoto,
  onChange,
}: {
  userId: string;
  possedePhoto: boolean;
  onChange: () => void | Promise<void>;
}) {
  const [etat, setEtat] = useState<"repos" | "envoi" | "erreur">("repos");

  async function envoyer(f: File) {
    setEtat("envoi");
    try {
      const sb = supabaseBrowser();
      const blob = await reduire(f);
      const chemin = `${userId}/profil-${Date.now()}.webp`;
      const { error } = await sb.storage.from("profils-photos").upload(chemin, blob, { contentType: "image/webp" });
      if (error) throw error;
      const { error: e2 } = await sb.rpc("definir_ma_photo_profil", { p_path: chemin });
      if (e2) throw e2;
      await onChange();
      setEtat("repos");
    } catch {
      setEtat("erreur");
    }
  }

  async function retirer() {
    setEtat("envoi");
    try {
      const { error } = await supabaseBrowser().rpc("definir_ma_photo_profil", { p_path: null });
      if (error) throw error;
      await onChange();
      setEtat("repos");
    } catch {
      setEtat("erreur");
    }
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      <label className="btn btn-clair cursor-pointer !min-h-[40px] !px-4 text-sm">
        {etat === "envoi" ? "Envoi…" : possedePhoto ? "Changer ma photo" : "Ajouter ma photo"}
        <input
          type="file"
          accept="image/*"
          hidden
          disabled={etat === "envoi"}
          onChange={(e) => e.target.files?.[0] && envoyer(e.target.files[0])}
        />
      </label>
      {possedePhoto && (
        <button type="button" onClick={retirer} disabled={etat === "envoi"} className="text-sm font-semibold underline">
          Retirer
        </button>
      )}
      {etat === "erreur" && (
        <span role="alert" className="text-sm text-red-700">
          Échec de l’envoi. Réessayez.
        </span>
      )}
    </div>
  );
}
