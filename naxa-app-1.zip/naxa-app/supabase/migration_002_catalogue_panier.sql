-- NAXA : migration 002 — catalogue enrichi (fiches, photos, dictionnaire), panier, « les plus recherchés ».
-- À exécuter UNE FOIS dans l'éditeur SQL de Supabase, après schema.sql. Sans danger si relancée.

-- ---------- 1. Fiches produits ----------
alter table produits
  add column if not exists synonymes text[] not null default '{}',
  add column if not exists photo_url text,
  add column if not exists description text,
  add column if not exists indications text,
  add column if not exists precautions text,
  add column if not exists source_fiche text not null default 'aucune'
    check (source_fiche in ('aucune', 'bdpm', 'ia', 'admin', 'pharmacien')),
  add column if not exists fiche_validee boolean not null default false,
  add column if not exists fiche_maj timestamptz,
  add column if not exists bdpm_cis text;

-- La recherche tient maintenant compte des synonymes (ex. « acetaminophen » pour paracétamol).
create or replace function produits_norm() returns trigger language plpgsql as $$
begin
  new.nom_norm := lower(unaccent(
    coalesce(new.nom,'') || ' ' || coalesce(new.dci,'') || ' ' || coalesce(new.dosage,'') || ' ' ||
    coalesce(array_to_string(new.synonymes, ' '), '')));
  return new;
end $$;
update produits set nom = nom;  -- recalcule nom_norm pour les produits existants

-- Seule l'équipe NAXA (admin) peut écrire photo et fiche. Les pharmacies peuvent toujours ajouter un produit (import de stock).
create or replace function produits_garde_fiche() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if coalesce(auth.role(), '') not in ('anon', 'authenticated') or is_admin() then return new; end if;
  if tg_op = 'INSERT' then
    new.photo_url := null; new.description := null; new.indications := null; new.precautions := null;
    new.source_fiche := 'aucune'; new.fiche_validee := false; new.fiche_maj := null; new.bdpm_cis := null;
  else
    new.photo_url := old.photo_url; new.description := old.description; new.indications := old.indications;
    new.precautions := old.precautions; new.source_fiche := old.source_fiche; new.fiche_validee := old.fiche_validee;
    new.fiche_maj := old.fiche_maj; new.bdpm_cis := old.bdpm_cis; new.synonymes := old.synonymes;
  end if;
  return new;
end $$;
drop trigger if exists trg_produits_garde on produits;
create trigger trg_produits_garde before insert or update on produits
  for each row execute function produits_garde_fiche();

-- ---------- 2. Photos (Supabase Storage, lecture publique, écriture admin) ----------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('produits-photos', 'produits-photos', true, 524288, array['image/webp', 'image/jpeg', 'image/png'])
on conflict (id) do nothing;

drop policy if exists photos_lecture on storage.objects;
drop policy if exists photos_admin_ajout on storage.objects;
drop policy if exists photos_admin_maj on storage.objects;
drop policy if exists photos_admin_suppr on storage.objects;
create policy photos_lecture on storage.objects for select using (bucket_id = 'produits-photos');
create policy photos_admin_ajout on storage.objects for insert with check (bucket_id = 'produits-photos' and public.is_admin());
create policy photos_admin_maj on storage.objects for update using (bucket_id = 'produits-photos' and public.is_admin());
create policy photos_admin_suppr on storage.objects for delete using (bucket_id = 'produits-photos' and public.is_admin());

-- ---------- 3. Dictionnaire médical (mots simples expliqués au client) ----------
create table if not exists dictionnaire (
  terme text primary key,                 -- en minuscules, ex. « comprimé »
  categorie text not null default 'mot',  -- forme, mot, classe...
  definition text not null,
  source text not null default 'NAXA (à faire valider par un pharmacien)'
);
alter table dictionnaire enable row level security;
drop policy if exists dico_lecture on dictionnaire;
drop policy if exists dico_admin on dictionnaire;
create policy dico_lecture on dictionnaire for select using (true);
create policy dico_admin on dictionnaire for all using (is_admin()) with check (is_admin());

insert into dictionnaire (terme, categorie, definition) values
  ('comprimé', 'forme', 'Forme solide à avaler avec de l''eau. Certains se croquent ou se dissolvent : lisez la notice.'),
  ('gélule', 'forme', 'Petite capsule qui contient une poudre. On l''avale entière avec de l''eau.'),
  ('sirop', 'forme', 'Médicament liquide sucré, souvent utilisé pour les enfants. Utilisez la mesure fournie dans la boîte.'),
  ('suspension buvable', 'forme', 'Liquide à agiter avant de boire, car la poudre se dépose au fond.'),
  ('injectable', 'forme', 'Médicament donné par piqûre, par un professionnel de santé.'),
  ('pommade', 'forme', 'Crème grasse à appliquer sur la peau.'),
  ('collyre', 'forme', 'Gouttes à mettre dans les yeux.'),
  ('effervescent', 'forme', 'Comprimé ou poudre à dissoudre dans un verre d''eau avant de boire.'),
  ('dci', 'mot', 'Dénomination commune internationale : le nom de la substance active, le même partout dans le monde (ex. paracétamol).'),
  ('substance active', 'mot', 'L''élément du médicament qui agit sur le corps.'),
  ('générique', 'mot', 'Médicament qui contient la même substance active qu''un médicament de marque, souvent moins cher. Le pharmacien peut vous conseiller.'),
  ('posologie', 'mot', 'La quantité à prendre et le rythme des prises. Elle vient de l''ordonnance ou de la notice, jamais de NAXA.'),
  ('contre-indication', 'mot', 'Situation dans laquelle un médicament ne doit pas être pris. Demandez au pharmacien en cas de doute.'),
  ('ordonnance', 'mot', 'Papier du médecin qui prescrit un médicament. Certains produits ne sont délivrés que sur ordonnance.')
on conflict (terme) do nothing;

-- ---------- 4. Panier : recherche avec quantités ----------
-- p_items = [{"produit_id": "...", "quantite": 2}, ...]. Une pharmacie « a » un produit seulement si elle en a assez.
create or replace function search_pharmacies_panier(p_items jsonb, p_lat float8, p_lng float8, p_rayon_km float8 default 20)
returns table (
  pharmacie_id uuid, nom text, quartier text, adresse text, lat float8, lng float8,
  de_garde boolean, stock_updated_at timestamptz, distance_km float8,
  total_prix int, items jsonb, trouves int, demandes int
)
language sql stable as $$
  with dem as (
    select (e->>'produit_id')::uuid as produit_id,
           greatest(1, least(coalesce((e->>'quantite')::int, 1), 10)) as qte
    from jsonb_array_elements(p_items) e
  ),
  nb as (select count(*)::int as c from dem),
  ok as (
    select s.pharmacie_id, pr.id as produit_id, pr.nom, pr.dosage, s.prix, s.quantite, d.qte
    from dem d
    join stocks s on s.produit_id = d.produit_id and s.quantite >= d.qte
    join produits pr on pr.id = d.produit_id
  ),
  agg as (
    select pharmacie_id, count(*)::int as trouves, sum(prix * qte)::int as total,
           jsonb_agg(jsonb_build_object('produit_id', produit_id, 'nom', nom, 'dosage', dosage,
                                        'prix', prix, 'quantite', quantite, 'quantite_demandee', qte) order by nom) as items
    from ok group by pharmacie_id
  )
  select ph.id, ph.nom, ph.quartier, ph.adresse, ph.lat, ph.lng, ph.de_garde, ph.stock_updated_at,
         d.km, a.total, a.items, a.trouves, nb.c
  from agg a
  join pharmacies ph on ph.id = a.pharmacie_id and ph.actif
  cross join nb
  cross join lateral (
    select 6371 * 2 * asin(sqrt(
      power(sin(radians(ph.lat - p_lat) / 2), 2) +
      cos(radians(p_lat)) * cos(radians(ph.lat)) * power(sin(radians(ph.lng - p_lng) / 2), 2)
    )) as km
  ) d
  where d.km <= p_rayon_km
  order by (a.trouves = nb.c) desc, d.km;
$$;

-- reserve_stock : même mécanisme (stock mis de côté 3 h), avec contrôle des quantités en plus.
create or replace function reserve_stock(p_pharmacie uuid, p_items jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid; it jsonb; v_total int := 0; v_prix int; v_q int;
begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  if not exists (select 1 from pharmacies where id = p_pharmacie and actif) then
    raise exception 'Pharmacie indisponible';
  end if;
  if jsonb_array_length(p_items) = 0 or jsonb_array_length(p_items) > 10 then
    raise exception 'Panier invalide';
  end if;
  insert into reservations (client_id, pharmacie_id, expires_at)
  values (auth.uid(), p_pharmacie, now() + interval '3 hours') returning id into v_id;

  for it in select * from jsonb_array_elements(p_items) loop
    v_q := coalesce((it->>'quantite')::int, 1);
    if v_q < 1 or v_q > 10 then raise exception 'Quantité invalide'; end if;
    update stocks set quantite = quantite - v_q
     where pharmacie_id = p_pharmacie and produit_id = (it->>'produit_id')::uuid and quantite >= v_q
     returning prix into v_prix;
    if not found then raise exception 'Stock insuffisant pour un des produits'; end if;
    insert into reservation_items values (v_id, (it->>'produit_id')::uuid, v_q, v_prix);
    v_total := v_total + v_prix * v_q;
  end loop;

  update reservations set total = v_total where id = v_id;
  return v_id;
end $$;

-- ---------- 5. « Les plus recherchés » ----------
-- On ne garde ni utilisateur ni position : seulement quel produit a été cherché, et quand.
create table if not exists recherche_events (
  id bigserial primary key,
  produit_id uuid not null references produits(id) on delete cascade,
  created_at timestamptz not null default now()
);
create index if not exists recherche_events_recent on recherche_events (created_at desc, produit_id);
alter table recherche_events enable row level security;  -- aucune policy : écriture et lecture uniquement via les fonctions ci-dessous

create or replace function log_recherche(p_terms text[]) returns void
language plpgsql security definer set search_path = public, extensions as $$
declare i int; t text; pid uuid;
begin
  for i in 1..least(coalesce(array_length(p_terms, 1), 0), 10) loop
    t := lower(unaccent(trim(p_terms[i])));
    if length(t) < 3 or length(t) > 80 then continue; end if;
    select id into pid from produits
     where nom_norm % t or nom_norm ilike '%' || t || '%'
     order by similarity(nom_norm, t) desc limit 1;
    if pid is not null then insert into recherche_events (produit_id) values (pid); end if;
  end loop;
end $$;

-- Produits les plus recherchés (7 jours) qui sont en stock quelque part.
-- Tant qu'il y a peu de recherches, complète avec les produits disponibles dans le plus de pharmacies.
create or replace function produits_populaires(p_limit int default 10, p_jours int default 7)
returns table (produit_id uuid, nom text, dosage text, photo_url text, prix_min int)
language sql stable security definer set search_path = public as $$
  with top as (
    select p.id, p.nom, p.dosage, p.photo_url, min(s.prix)::int as prix_min, count(distinct e.id) as score
    from recherche_events e
    join produits p on p.id = e.produit_id
    join stocks s on s.produit_id = p.id and s.quantite > 0
    where e.created_at > now() - make_interval(days => p_jours)
    group by p.id
  ),
  comp as (
    select p.id, p.nom, p.dosage, p.photo_url, min(s.prix)::int as prix_min, count(distinct s.pharmacie_id) as score
    from produits p
    join stocks s on s.produit_id = p.id and s.quantite > 0
    where p.id not in (select id from top)
    group by p.id
  )
  select id, nom, dosage, photo_url, prix_min from (
    select *, 1 as rang from top
    union all
    select *, 2 as rang from comp
  ) x
  order by rang, score desc
  limit least(p_limit, 20);
$$;
grant execute on function log_recherche(text[]) to anon, authenticated;
grant execute on function produits_populaires(int, int) to anon, authenticated;
grant execute on function search_pharmacies_panier(jsonb, float8, float8, float8) to anon, authenticated;
