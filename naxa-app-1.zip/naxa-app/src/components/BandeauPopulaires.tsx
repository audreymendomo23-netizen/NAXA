import { supabasePublic } from "@/lib/supabase/server";
import { BandeauDefilant, type Populaire } from "./BandeauDefilant";

/** Les produits les plus recherchés (calculés sur les recherches, pas vendus). Mis en cache 10 minutes. */
export async function BandeauPopulaires() {
  let produits: Populaire[] = [];
  try {
    const { data } = await supabasePublic().rpc("produits_populaires", { p_limit: 10, p_jours: 7 });
    produits = (data ?? []) as Populaire[];
  } catch {
    /* pas de bandeau si la base est indisponible : le reste du site fonctionne */
  }
  return <BandeauDefilant produits={produits} />;
}
