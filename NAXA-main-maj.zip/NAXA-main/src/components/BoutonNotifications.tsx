"use client";
import Link from "next/link";
import { useNotifications } from "@/lib/messagerie";
export function BoutonNotifications({ href = "/notifications" }: { href?: string }) {
  const { nonLues } = useNotifications();
  return <Link href={href} aria-label={`Notifications${nonLues ? `, ${nonLues} non lues` : ""}`} className="relative inline-flex h-10 w-10 items-center justify-center rounded-full text-white">
    <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M6 17V11a6 6 0 0 1 12 0v6l1.5 2h-15Z" /><path d="M10 21a2 2 0 0 0 4 0" /></svg>
    {nonLues > 0 && <span className="absolute right-0 top-0 min-w-[18px] rounded-full bg-naxa-canari px-1 text-center text-[11px] font-black text-naxa-green-900">{nonLues > 9 ? "9+" : nonLues}</span>}
  </Link>;
}
