-- Migration additive 076 : messagerie client-pharmacie, notifications, préférences client.
-- Candidate : non appliquée en Production.
create table if not exists public.client_preferences(
  user_id uuid primary key references auth.users on delete cascade,
  adresse_defaut text check (adresse_defaut is null or char_length(adresse_defaut) <= 200),
  quartier text check (quartier is null or char_length(quartier) <= 80),
  paiement_mode text not null default 'mtn_momo' check (paiement_mode in ('mtn_momo','orange_money','especes')),
  paiement_numero text check (paiement_numero is null or paiement_numero ~ '^6[0-9]{8}$'),
  langue text not null default 'fr' check (langue in ('fr','en')),
  notif_messages boolean not null default true,
  notif_reservations boolean not null default true,
  anonyme_defaut boolean not null default true,
  note_app smallint check (note_app between 1 and 5),
  avis_app text check (avis_app is null or char_length(avis_app) <= 500),
  updated_at timestamptz not null default now());
alter table public.client_preferences enable row level security;
drop policy if exists client_preferences_self on public.client_preferences;
create policy client_preferences_self on public.client_preferences for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Un fil = un client x une pharmacie. client_id n'est jamais lisible par la pharmacie.
create table if not exists public.fils_messages(
  id uuid primary key default gen_random_uuid(),
  pharmacie_id uuid not null references public.pharmacies(id) on delete cascade,
  client_id uuid not null references auth.users on delete cascade,
  produit_id uuid references public.produits(id) on delete set null,
  anonyme boolean not null default true,
  created_at timestamptz not null default now(),
  unique (client_id, pharmacie_id));
alter table public.fils_messages enable row level security;
drop policy if exists fils_messages_client on public.fils_messages;
create policy fils_messages_client on public.fils_messages for select to authenticated using (client_id = auth.uid());

create table if not exists public.messages_pharmacie(
  id uuid primary key default gen_random_uuid(),
  fil_id uuid not null references public.fils_messages(id) on delete cascade,
  expediteur text not null check (expediteur in ('client','pharmacie')),
  corps text not null check (char_length(btrim(corps)) between 1 and 1000),
  lu_le timestamptz,
  created_at timestamptz not null default now());
create index if not exists messages_pharmacie_fil_idx on public.messages_pharmacie(fil_id, created_at);
alter table public.messages_pharmacie enable row level security;
drop policy if exists messages_pharmacie_lecture on public.messages_pharmacie;
create policy messages_pharmacie_lecture on public.messages_pharmacie for select to authenticated using (
  exists (select 1 from public.fils_messages f where f.id = fil_id
          and (f.client_id = auth.uid() or public.can_access_pharmacy(f.pharmacie_id))));

-- Notifications : destinataire = un client (user_id) OU une pharmacie (pharmacie_id).
create table if not exists public.notifications(
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users on delete cascade,
  pharmacie_id uuid references public.pharmacies(id) on delete cascade,
  type text not null default 'message',
  titre text not null,
  corps text not null default '',
  fil_id uuid references public.fils_messages(id) on delete cascade,
  lu_le timestamptz,
  created_at timestamptz not null default now(),
  check ((user_id is null) <> (pharmacie_id is null)));
create index if not exists notifications_user_idx on public.notifications(user_id, created_at desc);
create index if not exists notifications_pharmacie_idx on public.notifications(pharmacie_id, created_at desc);
alter table public.notifications enable row level security;
drop policy if exists notifications_lecture on public.notifications;
create policy notifications_lecture on public.notifications for select to authenticated
  using (user_id = auth.uid() or (pharmacie_id is not null and public.can_access_pharmacy(pharmacie_id)));

create or replace function public.envoyer_message_client(p_pharmacie uuid, p_produit uuid, p_corps text, p_anonyme boolean)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_fil uuid; v_nom text;
begin
  if auth.uid() is null or not exists (select 1 from profiles where id = auth.uid() and role = 'client') then
    raise exception 'client requis'; end if;
  if (select count(*) from messages_pharmacie m join fils_messages f on f.id = m.fil_id
      where f.client_id = auth.uid() and m.expediteur = 'client' and m.created_at > now() - interval '1 hour') >= 20 then
    raise exception 'trop de messages, réessayez plus tard'; end if;
  if not exists (select 1 from pharmacies where id = p_pharmacie and actif) then raise exception 'pharmacie inconnue'; end if;
  insert into fils_messages(pharmacie_id, client_id, produit_id, anonyme)
    values (p_pharmacie, auth.uid(), p_produit, coalesce(p_anonyme, true))
    on conflict (client_id, pharmacie_id) do update set produit_id = coalesce(excluded.produit_id, fils_messages.produit_id)
    returning id into v_fil;
  insert into messages_pharmacie(fil_id, expediteur, corps) values (v_fil, 'client', btrim(p_corps));
  select case when f.anonyme then 'Client anonyme' else coalesce(nullif(btrim(coalesce(pr.first_name,'')), ''), 'Client') end
    into v_nom from fils_messages f left join profiles pr on pr.id = f.client_id where f.id = v_fil;
  insert into notifications(pharmacie_id, type, titre, corps, fil_id)
    values (p_pharmacie, 'message', 'Nouveau message de ' || v_nom, left(btrim(p_corps), 140), v_fil);
  return v_fil;
end $$;

create or replace function public.repondre_message(p_fil uuid, p_corps text)
returns void language plpgsql security definer set search_path = public as $$
declare f fils_messages%rowtype; v_ph text;
begin
  select * into f from fils_messages where id = p_fil;
  if not found then raise exception 'fil inconnu'; end if;
  if f.client_id = auth.uid() then
    insert into messages_pharmacie(fil_id, expediteur, corps) values (p_fil, 'client', btrim(p_corps));
    insert into notifications(pharmacie_id, type, titre, corps, fil_id)
      values (f.pharmacie_id, 'message', 'Nouveau message', left(btrim(p_corps), 140), p_fil);
  elsif public.can_access_pharmacy(f.pharmacie_id) then
    select nom into v_ph from pharmacies where id = f.pharmacie_id;
    insert into messages_pharmacie(fil_id, expediteur, corps) values (p_fil, 'pharmacie', btrim(p_corps));
    insert into notifications(user_id, type, titre, corps, fil_id)
      values (f.client_id, 'message', 'Réponse de ' || coalesce(v_ph, 'la pharmacie'), left(btrim(p_corps), 140), p_fil);
  else raise exception 'accès refusé'; end if;
end $$;

create or replace function public.marquer_fil_lu(p_fil uuid)
returns void language plpgsql security definer set search_path = public as $$
declare f fils_messages%rowtype; v_exp text;
begin
  select * into f from fils_messages where id = p_fil;
  if not found then return; end if;
  if f.client_id = auth.uid() then v_exp := 'pharmacie';
  elsif public.can_access_pharmacy(f.pharmacie_id) then v_exp := 'client';
  else return; end if;
  update messages_pharmacie set lu_le = now() where fil_id = p_fil and expediteur = v_exp and lu_le is null;
  update notifications set lu_le = now() where fil_id = p_fil and lu_le is null
    and ((v_exp = 'pharmacie' and user_id = auth.uid()) or (v_exp = 'client' and pharmacie_id = f.pharmacie_id));
end $$;

-- Boîte de la pharmacie : jamais d'identifiant client ; libellé anonyme si demandé.
create or replace function public.boite_pharmacie(p_pharmacie uuid)
returns table(fil_id uuid, libelle text, dernier text, dernier_le timestamptz, non_lus bigint)
language sql stable security definer set search_path = public as $$
  select f.id,
         case when f.anonyme then 'Client anonyme' else coalesce(nullif(btrim(coalesce(pr.first_name,'')), ''), 'Client') end,
         (select m.corps from messages_pharmacie m where m.fil_id = f.id order by m.created_at desc limit 1),
         (select max(m.created_at) from messages_pharmacie m where m.fil_id = f.id),
         (select count(*) from messages_pharmacie m where m.fil_id = f.id and m.expediteur = 'client' and m.lu_le is null)
  from fils_messages f left join profiles pr on pr.id = f.client_id
  where f.pharmacie_id = p_pharmacie and public.can_access_pharmacy(p_pharmacie)
  order by 4 desc nulls last
$$;

revoke all on function public.envoyer_message_client(uuid,uuid,text,boolean), public.repondre_message(uuid,text),
  public.marquer_fil_lu(uuid), public.boite_pharmacie(uuid) from anon, public;
grant execute on function public.envoyer_message_client(uuid,uuid,text,boolean), public.repondre_message(uuid,text),
  public.marquer_fil_lu(uuid), public.boite_pharmacie(uuid) to authenticated;

do $$ begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    begin alter publication supabase_realtime add table public.notifications; exception when duplicate_object then null; end;
    begin alter publication supabase_realtime add table public.messages_pharmacie; exception when duplicate_object then null; end;
  end if;
end $$;
