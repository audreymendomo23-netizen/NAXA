"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/client";
import { coordonneesValides, distanceKm, formatKm, type Position } from "@/lib/distance";

type Pharmacie = {
  id: string;
  nom: string;
  quartier: string | null;
  adresse: string | null;
  lat: number | null;
  lng: number | null;
  de_garde: boolean;
};

export default function PharmaciesProches() {
  const [pharmacies, setPharmacies] = useState<Pharmacie[] | null>(null);
  const [position, setPosition] = useState<Position | null>(null);
  const [etat, setEtat] = useState<"inconnue" | "recherche" | "refusee">("inconnue");

  useEffect(() => {
    (async () => {
      try {
        const { data, error } = await supabaseBrowser()
          .from("pharmacies")
          .select("id,nom,quartier,adresse,lat,lng,de_garde")
          .eq("actif", true)
          .order("nom")
          .limit(500);
        setPharmacies(error ? [] : ((data ?? []) as Pharmacie[]));
      } catch {
        setPharmacies([]);
      }
    })();
  }, []);

  function localiser() {
    if (!navigator.geolocation) {
      setEtat("refusee");
      return;
    }
    setEtat("recherche");
    navigator.geolocation.getCurrentPosition(
      (p) => {
        setPosition({ lat: p.coords.latitude, lng: p.coords.longitude });
        setEtat("inconnue");
      },
      () => setEtat("refusee"),
      { maximumAge: 300000, timeout: 8000 },
    );
  }

  const liste = useMemo(() => {
    const base = (pharmacies ?? []).map((p) => ({
      ...p,
      km: position && coordonneesValides(p.lat, p.lng) ? distanceKm(position, p.lat as number, p.lng as number) : null,
    }));
    return position ? base.sort((a, b) => (a.km ?? Infinity) - (b.km ?? Infinity)) : base;
  }, [pharmacies, position]);

  return (
    <main className="min-h-dvh bg-naxa-green-50 px-4 py-6 text-naxa-ink">
      <div className="mx-auto w-full max-w-xl space-y-5">
        <Link
          href="/"
          className="inline-flex min-h-11 items-center font-semibold text-naxa-green-700 underline underline-offset-4 hover:text-naxa-green-900"
        >
          ← Retour à l’accueil
        </Link>

        <header className="rounded-2xl bg-naxa-green-900 p-5 text-white">
          <h1 className="text-2xl font-extrabold">Pharmacies près de vous</h1>
          <p className="mt-2 text-sm leading-relaxed">
            Distances à vol d’oiseau, données à titre indicatif. Vérifiez la disponibilité avant de vous déplacer.
          </p>
        </header>

        {!position && (
          <div className="carte flex flex-col gap-3">
            <p className="text-sm text-slate-700" aria-live="polite">
              {etat === "refusee"
                ? "Position indisponible. La liste est affichée sans distance."
                : "Activez votre position pour trier les pharmacies de la plus proche à la plus éloignée."}
            </p>
            <button type="button" onClick={localiser} disabled={etat === "recherche"} className="btn btn-canari self-start">
              {etat === "recherche" ? "Localisation…" : "Activer ma position"}
            </button>
          </div>
        )}

        {pharmacies === null ? (
          <p className="carte">Chargement…</p>
        ) : liste.length === 0 ? (
          <p className="carte text-sm text-slate-600">Aucune pharmacie active pour le moment.</p>
        ) : (
          <ul className="space-y-3">
            {liste.map((p) => (
              <li key={p.id} className="carte flex items-center justify-between gap-3 !p-4">
                <div className="min-w-0">
                  <p className="truncate font-extrabold text-naxa-green-900">{p.nom}</p>
                  <p className="truncate text-sm text-slate-600">{[p.quartier, p.adresse].filter(Boolean).join(" · ")}</p>
                </div>
                <div className="flex shrink-0 flex-col items-end gap-1">
                  {p.km !== null && (
                    <span className="rounded-full bg-naxa-canari px-3 py-1 text-xs font-bold text-naxa-green-900">
                      ~{formatKm(p.km)}
                    </span>
                  )}
                  {p.de_garde && (
                    <span className="rounded-full bg-naxa-green-100 px-3 py-1 text-xs font-bold text-naxa-green-900">
                      De garde
                    </span>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </main>
  );
}
