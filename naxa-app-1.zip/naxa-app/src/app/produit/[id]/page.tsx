import Link from "next/link";
import { notFound } from "next/navigation";
import { supabaseServer } from "@/lib/supabase/server";
import { fcfa } from "@/lib/ranking";
import { Logo } from "@/components/Logo";
import { AjouterPanier } from "@/components/AjouterPanier";

type Produit = {
  id: string; nom: string; dci: string; dosage: string; forme: string;
  photo_url: string | null; description: string | null; indications: string | null; precautions: string | null;
  source_fiche: "aucune" | "bdpm" | "ia" | "admin" | "pharmacien"; fiche_validee: boolean; fiche_maj: string | null;
};

export default async function FicheProduit({ params }: { params: { id: string } }) {
  const sb = supabaseServer();
  const { data } = await sb
    .from("produits")
    .select("id,nom,dci,dosage,forme,photo_url,description,indications,precautions,source_fiche,fiche_validee,fiche_maj")
    .eq("id", params.id)
    .maybeSingle();
  if (!data) notFound();
  const p = data as Produit;

  const { data: stocks } = await sb.from("stocks").select("prix,pharmacie_id").eq("produit_id", p.id).gt("quantite", 0);
  const nbPharmacies = new Set((stocks ?? []).map((s) => s.pharmacie_id)).size;
  const prixMin = stocks?.length ? Math.min(...stocks.map((s) => s.prix)) : null;

  // Mots utiles : la forme du médicament et quelques termes de base, expliqués simplement.
  const termes = [p.forme.toLowerCase(), "dci", "générique", "posologie", "contre-indication"].filter(Boolean);
  const { data: mots } = await sb.from("dictionnaire").select("terme,definition").in("terme", termes);

  const aFiche = Boolean(p.description || p.indications || p.precautions);
  const maj = p.fiche_maj ? new Date(p.fiche_maj).toLocaleDateString("fr-FR") : null;

  return (
    <main className="mx-auto max-w-2xl px-4 pb-24">
      <header className="-mx-4 mb-4 flex items-center justify-between bg-naxa-green-900 px-4 py-3">
        <Link href="/"><Logo taille={32} /></Link>
        <Link href="/panier" className="text-sm font-semibold text-white underline underline-offset-4">Mon panier</Link>
      </header>

      <div className="carte flex flex-col items-center gap-4 sm:flex-row sm:items-start">
        {p.photo_url ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={p.photo_url} alt={`Boîte de ${p.nom} ${p.dosage}`} width={160} height={160} className="h-40 w-40 rounded-xl2 bg-white object-contain" />
        ) : (
          <div className="flex h-40 w-40 items-center justify-center rounded-xl2 bg-naxa-green-100 text-sm text-naxa-green-900" role="img" aria-label="Photo non disponible">Photo non disponible</div>
        )}
        <div className="flex-1">
          <h1 className="text-2xl font-extrabold">{p.nom} {p.dosage}</h1>
          <p className="mt-1 text-slate-700">{[p.dci && `Molécule : ${p.dci}`, p.forme].filter(Boolean).join(" · ")}</p>
          <p className="mt-3 font-semibold text-naxa-green-700">
            {nbPharmacies > 0 ? `En stock dans ${nbPharmacies} pharmacie${nbPharmacies > 1 ? "s" : ""}${prixMin ? ` · dès ${fcfa(prixMin)}` : ""}` : "Pas en stock pour le moment chez nos pharmacies partenaires"}
          </p>
        </div>
      </div>
      {p.photo_url && <p className="mt-1 text-xs text-slate-500">Photo à titre indicatif : l'emballage peut varier.</p>}

      <div className="carte mt-4 space-y-4">
        <AjouterPanier produit={{ produit_id: p.id, nom: p.nom, dosage: p.dosage }} />
        <Link href={`/resultats?q=${encodeURIComponent(`${p.nom} ${p.dosage}`.trim())}`} className="btn btn-clair w-full">Voir les pharmacies qui l'ont</Link>
      </div>

      <section className="carte mt-4 space-y-3" aria-labelledby="fiche">
        <h2 id="fiche" className="text-lg font-bold">À propos de ce médicament</h2>
        {aFiche ? (
          <>
            <p className={`inline-block rounded-full px-3 py-1 text-xs font-bold ${p.fiche_validee ? "bg-naxa-green-100 text-naxa-green-900" : "bg-naxa-canari text-naxa-green-900"}`}>
              {p.fiche_validee ? "Fiche relue par l'équipe NAXA" : "Fiche en cours de relecture"}
            </p>
            {p.description && <p>{p.description}</p>}
            {p.indications && <div><h3 className="font-semibold">À quoi ça sert</h3><p>{p.indications}</p></div>}
            {p.precautions && <div><h3 className="font-semibold">Précautions</h3><p>{p.precautions}</p></div>}
            {!p.fiche_validee && p.source_fiche === "ia" && <p className="text-sm text-slate-600">Ce texte a été rédigé avec l'aide d'une IA et n'a pas encore été relu. Lisez la notice et demandez conseil au pharmacien.</p>}
            {p.source_fiche === "bdpm" && <p className="text-sm text-slate-600">Source : Base de données publique des médicaments (ANSM){maj ? `, mise à jour le ${maj}` : ""}.</p>}
          </>
        ) : (
          <p className="text-slate-700">La fiche de ce médicament n'est pas encore disponible. Lisez la notice dans la boîte et demandez conseil au pharmacien.</p>
        )}
        <p className="text-sm font-semibold">Information générale, pas un avis médical. NAXA n'indique jamais de dose : suivez l'ordonnance ou la notice. Aucun médicament n'est remplacé sans l'accord du pharmacien.</p>
      </section>

      {mots && mots.length > 0 && (
        <details className="carte mt-4">
          <summary className="min-h-[48px] cursor-pointer py-3 font-bold">Mots utiles</summary>
          <dl className="space-y-2 pb-2">
            {mots.map((m) => (
              <div key={m.terme}><dt className="font-semibold capitalize">{m.terme}</dt><dd className="text-slate-700">{m.definition}</dd></div>
            ))}
          </dl>
        </details>
      )}
    </main>
  );
}
