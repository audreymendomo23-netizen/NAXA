"use client";
import { supabaseBrowser } from "@/lib/supabase/client";

type Evt = {
  type: "recherche" | "fiche_vue" | "panier_ajout" | "scan_ordonnance";
  produitId?: string; pharmacieId?: string; terme?: string; resultats?: number; lat?: number; lng?: number;
};

/** Enregistre un événement anonyme (aucun identifiant client, position arrondie côté base). N'interrompt jamais l'application. */
export function suivre(e: Evt) {
  try {
    void supabaseBrowser()
      .rpc("log_evenement", {
        p_type: e.type, p_produit: e.produitId ?? null, p_pharmacie: e.pharmacieId ?? null,
        p_terme: e.terme ?? null, p_resultats: e.resultats ?? null, p_lat: e.lat ?? null, p_lng: e.lng ?? null,
      })
      .then(() => undefined, () => undefined);
  } catch { /* le suivi ne doit jamais casser une page */ }
}
