import Image from "next/image";

/**
 * Couvertures illustrées des pages du parcours client.
 * Fichiers : /public/couvertures/*.webp (1024x576, ratio 16:9, pré-optimisés).
 * Purement décoratif : ne remplace aucun composant fonctionnel et ne porte aucune donnée.
 */
const COUVERTURES = {
  accueil: { src: "/couvertures/accueil-client.webp", alt: "Un client est accueilli au comptoir d’une pharmacie par deux pharmaciennes" },
  gardes: { src: "/couvertures/pharmacies-garde.webp", alt: "Une pharmacienne dans une pharmacie de garde" },
  recherche: { src: "/couvertures/recherche.webp", alt: "Un pharmacien consulte une tablette devant les rayons de médicaments" },
  panier: { src: "/couvertures/panier-reservations.webp", alt: "Un sac en papier et des boîtes de médicaments sur un comptoir de pharmacie" },
  historique: { src: "/couvertures/historique-factures.webp", alt: "Un reçu, une pochette et un téléphone sur un comptoir" },
  profil: { src: "/couvertures/profil-client.webp", alt: "Un client consulte son téléphone dans une salle d’attente de pharmacie" },
  favoris: { src: "/couvertures/favoris.webp", alt: "Une main tient un téléphone affichant une liste de produits favoris" },
  notifications: { src: "/couvertures/notifications.webp", alt: "Un téléphone affichant des notifications sur un comptoir de pharmacie" },
  posologie: { src: "/couvertures/posologie.webp", alt: "Un pilulier, un verre d’eau et un téléphone" },
  suivi: { src: "/couvertures/dispositifs-medicaux.webp", alt: "Un tensiomètre, un thermomètre et une montre connectée" },
} as const;

export type CouvertureId = keyof typeof COUVERTURES;

export function CouvertureNaxa({
  id,
  priority = false,
  className = "",
}: {
  id: CouvertureId;
  /** true uniquement pour une couverture visible dès l’ouverture de la page. */
  priority?: boolean;
  className?: string;
}) {
  const couverture = COUVERTURES[id];
  return (
    <div
      className={`relative aspect-[16/9] max-h-[190px] w-full overflow-hidden rounded-2xl bg-[#DCEAE0] shadow-sm sm:max-h-[240px] ${className}`}
    >
      <Image
        src={couverture.src}
        alt={couverture.alt}
        fill
        sizes="(max-width: 480px) 100vw, 480px"
        priority={priority}
        unoptimized
        className="object-cover"
      />
    </div>
  );
}
