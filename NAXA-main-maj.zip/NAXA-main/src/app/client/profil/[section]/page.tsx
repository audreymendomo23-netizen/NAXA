"use client";
import Link from "next/link";
import { useEffect, useState, type ReactNode } from "react";
import { useParams, useRouter } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/client";
import { fcfa } from "@/lib/ranking";
import { useProfilClient } from "@/lib/profil-client";
import { lienGmail, lienWhatsApp, NAXA_EMAIL } from "@/lib/contact-naxa";
import { Logo } from "@/components/Logo";

type Prefs = { adresse_defaut: string; quartier: string; paiement_mode: string; paiement_numero: string; langue: string; notif_messages: boolean; notif_reservations: boolean; anonyme_defaut: boolean; note_app: number | null; avis_app: string };
const DEF: Prefs = { adresse_defaut: "", quartier: "", paiement_mode: "mtn_momo", paiement_numero: "", langue: "fr", notif_messages: true, notif_reservations: true, anonyme_defaut: true, note_app: null, avis_app: "" };
const TITRES: Record<string, string> = { adresse: "Adresse par défaut", paiement: "Paiement", langue: "Langue", factures: "Factures", aide: "Centre d'aide", contact: "Contacter NAXA", noter: "Noter l'app", notifications: "Notifications", confidentialite: "Confidentialité" };
const FAQ: [string, string][] = [
  ["Comment trouver un médicament ?", "Onglet Recherche : tapez le nom (ou la molécule), comparez prix, distance et stock, puis ouvrez l'offre d'une pharmacie."],
  ["Comment réserver et payer ?", "Ajoutez au panier puis réservez auprès d'une pharmacie. Le paiement (Mobile Money) est déclaré puis confirmé par la pharmacie ; suivez l'état dans Achats."],
  ["Comment écrire à une pharmacie ?", "Sur une offre, touchez la bulle jaune. Vous pouvez rester anonyme. La réponse arrive dans vos notifications."],
  ["Les stocks sont-ils fiables ?", "Ils sont mis à jour par les pharmacies et peuvent changer : confirmez auprès de la pharmacie avant de vous déplacer."],
  ["NAXA donne-t-il des conseils médicaux ?", "Non. NAXA donne des informations de disponibilité, jamais de dose ni d'avis médical. Demandez conseil à votre pharmacien."]];
const LABEL_PAIEMENT: Record<string, string> = { mtn_momo: "MTN MoMo", orange_money: "Orange Money", especes: "Espèces au retrait" };
type Ligne = { reservation_id: string; medicament: string; quantite: number; prix_unitaire: number; total_ligne: number; total_transaction: number; pharmacie: string; achat_le: string | null; reservation_creee_le: string; statut: string };

const LogoGmail = () => <svg viewBox="0 0 24 24" className="h-8 w-8" aria-hidden="true"><rect x="2" y="5" width="20" height="14" rx="2" fill="#fff" stroke="#d93025" strokeWidth="1.5" /><path d="M3 7l9 7 9-7" fill="none" stroke="#d93025" strokeWidth="2" /></svg>;
const LogoWhatsApp = () => <svg viewBox="0 0 24 24" className="h-8 w-8" aria-hidden="true"><path d="M12 2a10 10 0 0 0-8.6 15L2 22l5.2-1.4A10 10 0 1 0 12 2Z" fill="#25d366" /><path d="M8.5 7.5c.3-.5.8-.3 1 .1l.7 1.6c.1.3 0 .5-.2.7l-.5.6c.7 1.3 1.7 2.2 3 2.8l.6-.7c.2-.2.5-.3.8-.1l1.5.8c.4.2.4.7.1 1-.9 1-2.2 1.3-3.5.7-2.5-1.1-4.3-3-5-5.4-.2-.8.1-1.5.5-2Z" fill="#fff" /></svg>;

export default function SectionProfil() {
  const { section } = useParams<{ section: string }>(), router = useRouter(), profil = useProfilClient();
  const [uid, setUid] = useState(""), [p, setP] = useState<Prefs>(DEF), [msg, setMsg] = useState(""), [lignes, setLignes] = useState<Ligne[]>([]), [perm, setPerm] = useState("inconnu");
  const nom = [profil.prenom, profil.nom].filter(Boolean).join(" ");
  useEffect(() => { (async () => {
    const sb = supabaseBrowser(); const { data: u } = await sb.auth.getUser();
    if (!u.user) return router.replace("/connexion?retour=" + encodeURIComponent("/client/profil/" + section));
    setUid(u.user.id);
    if (section === "historique") return router.replace("/client?onglet=achats");
    const { data } = await sb.from("client_preferences").select("*").eq("user_id", u.user.id).maybeSingle();
    if (data) setP({ ...DEF, ...data, adresse_defaut: data.adresse_defaut ?? "", quartier: data.quartier ?? "", paiement_numero: data.paiement_numero ?? "", avis_app: data.avis_app ?? "" });
    if (section === "factures") { const { data: a } = await sb.from("client_achats").select("reservation_id,medicament,quantite,prix_unitaire,total_ligne,total_transaction,pharmacie,achat_le,reservation_creee_le,statut").in("statut", ["payee", "retiree"]).order("achat_le", { ascending: false, nullsFirst: false }).limit(300); setLignes((a ?? []) as Ligne[]); }
    if (typeof Notification !== "undefined") setPerm(Notification.permission);
  })(); }, [section, router]);
  async function sauver(patch: Partial<Prefs>, ok = "Enregistré.") {
    const next = { ...p, ...patch }; setP(next); setMsg("");
    const row = { user_id: uid, ...next, adresse_defaut: next.adresse_defaut.trim() || null, quartier: next.quartier.trim() || null, paiement_numero: next.paiement_numero.trim() || null, avis_app: next.avis_app.trim() || null, updated_at: new Date().toISOString() };
    const { error } = await supabaseBrowser().from("client_preferences").upsert(row);
    setMsg(error ? "Enregistrement impossible (vérifiez les champs)." : ok);
  }
  const cadre = (c: ReactNode) => <main className="mx-auto min-h-screen max-w-2xl bg-slate-50 px-4 pb-28"><header className="-mx-4 mb-4 flex items-center gap-3 bg-naxa-green-900 px-4 py-3 text-white"><Link href="/client?onglet=profil" aria-label="Retour au profil" className="text-2xl">←</Link><Logo taille={28} /><h1 className="font-extrabold">{TITRES[section] ?? "Profil"}</h1></header><section className="carte space-y-4">{c}{msg && <p role="status" className="text-sm font-semibold">{msg}</p>}</section></main>;
  const groupes = new Map<string, Ligne[]>(); for (const l of lignes) groupes.set(l.reservation_id, [...(groupes.get(l.reservation_id) ?? []), l]);

  if (section === "adresse") return cadre(<><label className="block text-sm font-semibold">Adresse<input className="champ mt-1 w-full" maxLength={200} value={p.adresse_defaut} onChange={(e) => setP({ ...p, adresse_defaut: e.target.value })} placeholder="Ex. rue, repère connu" /></label><label className="block text-sm font-semibold">Quartier<input className="champ mt-1 w-full" maxLength={80} value={p.quartier} onChange={(e) => setP({ ...p, quartier: e.target.value })} /></label><button className="btn btn-vert w-full" onClick={() => sauver({})}>Enregistrer</button></>);
  if (section === "paiement") return cadre(<>{Object.entries(LABEL_PAIEMENT).map(([k, v]) => <label key={k} className="flex items-center gap-2"><input type="radio" name="pm" checked={p.paiement_mode === k} onChange={() => setP({ ...p, paiement_mode: k })} />{v}</label>)}
    {p.paiement_mode !== "especes" && <label className="block text-sm font-semibold">Numéro Mobile Money (9 chiffres, sans +237)<input className="champ mt-1 w-full" inputMode="numeric" maxLength={9} value={p.paiement_numero} onChange={(e) => setP({ ...p, paiement_numero: e.target.value.replace(/\D/g, "") })} placeholder="6XXXXXXXX" /></label>}
    <button className="btn btn-vert w-full" onClick={() => { if (p.paiement_mode !== "especes" && p.paiement_numero && !/^6\d{8}$/.test(p.paiement_numero)) return setMsg("Numéro invalide : 9 chiffres commençant par 6."); void sauver({}); }}>Enregistrer</button><p className="text-xs text-slate-500">NAXA ne stocke ni code secret ni solde. Ce choix préremplit votre déclaration de paiement.</p></>);
  if (section === "langue") return cadre(<>{[["fr", "Français"], ["en", "English (bientôt)"]].map(([k, v]) => <label key={k} className="flex items-center gap-2"><input type="radio" name="l" checked={p.langue === k} onChange={() => sauver({ langue: k })} />{v}</label>)}<p className="text-xs text-slate-500">Seul le français est traduit pour l'instant ; votre choix est conservé pour l'anglais.</p></>);
  if (section === "factures") return cadre(<>{groupes.size === 0 ? <p className="text-sm text-slate-600">Aucune facture : elles apparaissent après un achat payé.</p> : [...groupes.entries()].map(([id, ls]) => <article key={id} className="rounded-2xl border p-3"><p className="font-bold">Facture #{id.slice(0, 8).toUpperCase()}</p><p className="text-xs text-slate-500">{new Date(ls[0].achat_le ?? ls[0].reservation_creee_le).toLocaleDateString("fr-FR")} · {ls[0].pharmacie}</p><ul className="mt-2 text-sm">{ls.map((l, i) => <li key={i}>{l.quantite} × {l.medicament} : {fcfa(l.total_ligne)}</li>)}</ul><p className="mt-1 font-extrabold">Total {fcfa(ls[0].total_transaction)}</p></article>)}{groupes.size > 0 && <button className="btn btn-clair no-print w-full" onClick={() => window.print()}>Imprimer / enregistrer en PDF</button>}</>);
  if (section === "aide") return cadre(<>{FAQ.map(([q, r]) => <details key={q} className="rounded-xl border p-3"><summary className="cursor-pointer font-bold">{q}</summary><p className="mt-2 text-sm">{r}</p></details>)}<Link href="/client/profil/contact" className="btn btn-canari w-full">Je n'ai pas trouvé ma réponse</Link></>);
  if (section === "contact") return cadre(<><p className="text-sm">Choisissez comment nous écrire. Le message est prêt : il ne vous reste qu'à l'envoyer.</p>
    <a href={lienGmail(nom)} className="btn btn-clair flex w-full items-center justify-center gap-3"><LogoGmail />Par Gmail</a>
    <a href={lienWhatsApp(nom)} target="_blank" rel="noopener noreferrer" className="btn btn-clair flex w-full items-center justify-center gap-3"><LogoWhatsApp />Par WhatsApp</a><p className="text-xs text-slate-500">{NAXA_EMAIL} · WhatsApp 681 97 22 37</p></>);
  if (section === "noter") return cadre(<><div className="flex justify-center gap-2" role="radiogroup" aria-label="Note">{[1, 2, 3, 4, 5].map((n) => <button key={n} type="button" role="radio" aria-checked={p.note_app === n} aria-label={`${n} étoile${n > 1 ? "s" : ""}`} onClick={() => setP({ ...p, note_app: n })} className={"text-4xl " + ((p.note_app ?? 0) >= n ? "text-naxa-canari" : "text-slate-300")}>★</button>)}</div>
    <textarea className="champ min-h-[80px] w-full" maxLength={500} value={p.avis_app} onChange={(e) => setP({ ...p, avis_app: e.target.value })} placeholder="Un commentaire ? (facultatif)" aria-label="Commentaire" /><button className="btn btn-vert w-full" disabled={!p.note_app} onClick={() => sauver({}, "Merci pour votre avis !")}>Envoyer</button></>);
  if (section === "notifications") return cadre(<>{[["notif_messages", "Réponses des pharmacies"], ["notif_reservations", "Suivi de mes réservations"]].map(([k, v]) => <label key={k} className="flex items-center justify-between gap-3"><span>{v}</span><input type="checkbox" checked={p[k as "notif_messages"]} onChange={(e) => sauver({ [k]: e.target.checked } as Partial<Prefs>)} /></label>)}
    {perm === "default" && <button className="btn btn-canari w-full" onClick={async () => setPerm(await Notification.requestPermission())}>Activer les alertes sur ce téléphone</button>}{perm === "denied" && <p className="text-sm text-slate-600">Alertes bloquées : autorisez-les dans les réglages du navigateur.</p>}{perm === "granted" && <p className="text-sm font-semibold">Alertes activées sur cet appareil.</p>}</>);
  if (section === "confidentialite") return cadre(<><label className="flex items-center justify-between gap-3"><span>Rester anonyme par défaut quand j'écris à une pharmacie</span><input type="checkbox" checked={p.anonyme_defaut} onChange={(e) => sauver({ anonyme_defaut: e.target.checked })} /></label><Link className="block underline" href="/politique-confidentialite">Politique de confidentialité</Link><Link className="block underline" href="/politique-securite">Politique de sécurité</Link><Link className="block underline" href="/conditions-utilisation">Conditions d'utilisation</Link></>);
  return cadre(<p>Section introuvable.</p>);
}
