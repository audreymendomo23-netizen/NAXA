-- Contrôle structurel : le déclencheur distingue les comptes OAuth et ne les valide pas d'office.
do $$
declare d text;
begin
  select pg_get_functiondef('public.handle_new_user()'::regprocedure) into d;
  if d not like '%v_provider <> ''email''%' then raise exception 'branche OAuth absente'; end if;
  if d not like '%false%' or d not like '%Nom d''utilisateur invalide%' then raise exception 'règles e-mail ou age_verified=false manquantes'; end if;
end $$;
