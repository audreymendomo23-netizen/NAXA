-- NAXA : migration 006 — promoteur et caisses (comptes parent-enfant), journal d'activité, coûts et marge,
-- fidélisation des clients, schéma BI en lecture seule, rapports à envoyer par e-mail.
-- Ordre : schema, 002, 003, 004, 005, puis ce fichier. Sans danger si relancée. Ne supprime aucune donnée.

-- 1. Comptes : le promoteur est le compte principal, les caisses sont ses comptes filles (même pharmacie, même stock).
alter table public.profiles
  add column if not exists niveau text not null default 'promoteur' check (niveau in ('promoteur', 'caisse')),
  add column if not exists parent_id uuid references public.profiles(id) on delete set null,
  add column if not exists statut text not null default 'actif' check (statut in ('actif', 'bloque', 'retire')),
  add column if not exists nom_affiche text,
  add column if not exists formation_terminee boolean not null default false;
alter table public.pharmacies add column if not exists max_caisses int not null default 5 check (max_caisses between 0 and 50);

-- Un compte bloqué perd immédiatement l'accès aux données de la pharmacie.
create or replace function public.my_pharmacie() returns uuid
language sql stable security definer set search_path = public as $$
  select pharmacie_id from public.profiles where id = auth.uid() and statut = 'actif'
$$;

create or replace function public.est_promoteur() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles
                 where id = auth.uid() and role = 'pharmacie' and niveau = 'promoteur' and statut = 'actif')
$$;

drop policy if exists profiles_equipe on public.profiles;
create policy profiles_equipe on public.profiles for select using (parent_id = (select auth.uid()));

-- 2. Invitations : le promoteur crée un code lié à l'adresse e-mail de la personne ; elle se connecte puis saisit le code.
create table if not exists public.invitations_caisse (
  id uuid primary key default gen_random_uuid(),
  pharmacie_id uuid not null references public.pharmacies(id) on delete cascade,
  cree_par uuid not null references public.profiles(id) on delete cascade,
  email text not null,
  nom_affiche text,
  code text not null unique,
  expire_le timestamptz not null default now() + interval '7 days',
  utilise_le timestamptz,
  created_at timestamptz not null default now()
);
alter table public.invitations_caisse enable row level security;
drop policy if exists invitations_lecture on public.invitations_caisse;
create policy invitations_lecture on public.invitations_caisse for select
  using ((select public.is_admin()) or (pharmacie_id = (select public.my_pharmacie()) and (select public.est_promoteur())));
revoke all on table public.invitations_caisse from anon, authenticated;
grant select on table public.invitations_caisse to authenticated;

-- 3. Journal d'activité (qui a fait quoi).
create table if not exists public.journal_actions (
  id bigserial primary key,
  pharmacie_id uuid references public.pharmacies(id) on delete cascade,
  profile_id uuid references public.profiles(id) on delete set null,
  action text not null,
  detail jsonb,
  created_at timestamptz not null default now()
);
create index if not exists journal_actions_ph on public.journal_actions (pharmacie_id, created_at desc);
alter table public.journal_actions enable row level security;
drop policy if exists journal_lecture on public.journal_actions;
create policy journal_lecture on public.journal_actions for select
  using ((select public.is_admin()) or (pharmacie_id = (select public.my_pharmacie()) and (select public.est_promoteur())));
revoke all on table public.journal_actions from anon, authenticated;
grant select on table public.journal_actions to authenticated;

-- 4. Fonctions du promoteur.
create or replace function public.creer_invitation(p_email text, p_nom text default null) returns text
language plpgsql security definer set search_path = public, extensions as $$
declare v_ph uuid; v_code text; n int; m int;
begin
  if auth.uid() is null or not public.est_promoteur() then raise exception 'Réservé au promoteur'; end if;
  v_ph := public.my_pharmacie();
  if p_email is null or p_email !~* '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$' then raise exception 'Adresse e-mail invalide'; end if;
  select count(*) into n from public.profiles where parent_id = auth.uid() and statut in ('actif', 'bloque');
  select count(*) into m from public.invitations_caisse where pharmacie_id = v_ph and utilise_le is null and expire_le > now();
  if n + m >= (select max_caisses from public.pharmacies where id = v_ph) then raise exception 'Limite de caisses atteinte'; end if;
  v_code := upper(substr(encode(gen_random_bytes(6), 'hex'), 1, 10));
  insert into public.invitations_caisse (pharmacie_id, cree_par, email, nom_affiche, code)
  values (v_ph, auth.uid(), lower(trim(p_email)), left(p_nom, 60), v_code);
  insert into public.journal_actions (pharmacie_id, profile_id, action, detail)
  values (v_ph, auth.uid(), 'invitation_creee', jsonb_build_object('email', lower(trim(p_email))));
  return v_code;
end $$;

create or replace function public.accepter_invitation(p_code text) returns uuid
language plpgsql security definer set search_path = public as $$
declare inv public.invitations_caisse%rowtype; v_email text;
begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  v_email := lower(coalesce(auth.jwt() ->> 'email', ''));
  select * into inv from public.invitations_caisse where code = upper(trim(p_code)) for update;
  if not found or inv.utilise_le is not null or inv.expire_le < now() or inv.email <> v_email then
    raise exception 'Invitation invalide ou expirée';
  end if;
  if exists (select 1 from public.profiles where id = auth.uid() and role in ('admin', 'pharmacie')) then
    raise exception 'Ce compte ne peut pas rejoindre une pharmacie';
  end if;
  update public.profiles
     set role = 'pharmacie', niveau = 'caisse', pharmacie_id = inv.pharmacie_id, parent_id = inv.cree_par,
         nom_affiche = inv.nom_affiche, statut = 'actif'
   where id = auth.uid();
  update public.invitations_caisse set utilise_le = now() where id = inv.id;
  insert into public.journal_actions (pharmacie_id, profile_id, action, detail)
  values (inv.pharmacie_id, auth.uid(), 'caisse_rejointe', null);
  return inv.pharmacie_id;
end $$;

create or replace function public.gerer_caisse(p_id uuid, p_action text) returns void
language plpgsql security definer set search_path = public as $$
declare v_ph uuid;
begin
  if auth.uid() is null or not public.est_promoteur() then raise exception 'Réservé au promoteur'; end if;
  v_ph := public.my_pharmacie();
  if not exists (select 1 from public.profiles where id = p_id and parent_id = auth.uid() and pharmacie_id = v_ph) then
    raise exception 'Caisse introuvable';
  end if;
  if p_action = 'bloquer' then update public.profiles set statut = 'bloque' where id = p_id;
  elsif p_action = 'debloquer' then update public.profiles set statut = 'actif' where id = p_id;
  elsif p_action = 'retirer' then
    -- la personne redevient simple cliente ; son historique d'actions est conservé dans le journal
    update public.profiles set role = 'client', niveau = 'promoteur', pharmacie_id = null, parent_id = null, statut = 'actif' where id = p_id;
  else raise exception 'Action inconnue'; end if;
  insert into public.journal_actions (pharmacie_id, profile_id, action, detail)
  values (v_ph, auth.uid(), 'caisse_' || p_action, jsonb_build_object('caisse', p_id));
end $$;

create or replace function public.terminer_formation() returns void
language sql security definer set search_path = public as $$
  update public.profiles set formation_terminee = true where id = auth.uid() and role = 'pharmacie'
$$;

create or replace function public.equipe(p_ph uuid default null) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare v_ph uuid := coalesce(p_ph, public.my_pharmacie());
begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  if not (public.is_admin() or (public.est_promoteur() and coalesce(v_ph = public.my_pharmacie(), false))) then
    raise exception 'Accès refusé';
  end if;
  return jsonb_build_object(
    'membres', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id', p.id, 'nom', coalesce(p.nom_affiche, p.username, 'Sans nom'), 'niveau', p.niveau, 'statut', p.statut,
        'formation_terminee', p.formation_terminee,
        'actions_stock_30j', (select count(*) from public.journal_actions j where j.profile_id = p.id and j.action = 'stock' and j.created_at > now() - interval '30 days'),
        'reservations_traitees_30j', (select count(*) from public.reservations r where r.traite_par = p.id and r.traite_le > now() - interval '30 days'),
        'derniere_activite', (select max(j.created_at) from public.journal_actions j where j.profile_id = p.id)
      ) order by p.niveau, p.created_at)
      from public.profiles p where p.pharmacie_id = v_ph and p.role = 'pharmacie'), '[]'::jsonb),
    'invitations', coalesce((
      select jsonb_agg(jsonb_build_object('id', i.id, 'email', i.email, 'nom', i.nom_affiche, 'code', i.code, 'expire_le', i.expire_le) order by i.created_at desc)
      from public.invitations_caisse i where i.pharmacie_id = v_ph and i.utilise_le is null and i.expire_le > now()), '[]'::jsonb)
  );
end $$;

revoke execute on function public.creer_invitation(text, text) from public, anon;
revoke execute on function public.accepter_invitation(text) from public, anon;
revoke execute on function public.gerer_caisse(uuid, text) from public, anon;
revoke execute on function public.terminer_formation() from public, anon;
revoke execute on function public.equipe(uuid) from public, anon;
grant execute on function public.creer_invitation(text, text), public.accepter_invitation(text), public.gerer_caisse(uuid, text),
  public.terminer_formation(), public.equipe(uuid) to authenticated;

-- 5. Traçabilité : modifications de stock par compte, et qui a traité chaque réservation.
create or replace function public.journal_stock() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or new.pharmacie_id is distinct from public.my_pharmacie() then return new; end if;
  if tg_op = 'INSERT' or new.quantite is distinct from old.quantite or new.prix is distinct from old.prix then
    insert into public.journal_actions (pharmacie_id, profile_id, action, detail)
    values (new.pharmacie_id, auth.uid(), 'stock', jsonb_build_object('produit_id', new.produit_id, 'quantite', new.quantite, 'prix', new.prix));
  end if;
  return new;
end $$;
drop trigger if exists trg_journal_stock on public.stocks;
create trigger trg_journal_stock after insert or update on public.stocks for each row execute function public.journal_stock();

alter table public.reservations
  add column if not exists traite_par uuid references public.profiles(id) on delete set null,
  add column if not exists traite_le timestamptz;
create or replace function public.reservations_traite() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.statut is distinct from old.statut and auth.uid() is not null and new.pharmacie_id is not distinct from public.my_pharmacie() then
    new.traite_par := auth.uid(); new.traite_le := now();
  end if;
  return new;
end $$;
drop trigger if exists trg_resa_traite on public.reservations;
create trigger trg_resa_traite before update on public.reservations for each row execute function public.reservations_traite();

-- 6. Prix d'achat dans une table séparée (la table stocks est lisible par tous : jamais de prix d'achat dedans).
create table if not exists public.stocks_couts (
  pharmacie_id uuid not null references public.pharmacies(id) on delete cascade,
  produit_id uuid not null references public.produits(id) on delete cascade,
  prix_achat integer not null check (prix_achat >= 0),
  updated_at timestamptz not null default now(),
  primary key (pharmacie_id, produit_id)
);
alter table public.stocks_couts enable row level security;
drop policy if exists couts_promoteur on public.stocks_couts;
create policy couts_promoteur on public.stocks_couts for all
  using ((select public.is_admin()) or (pharmacie_id = (select public.my_pharmacie()) and (select public.est_promoteur())))
  with check ((select public.is_admin()) or (pharmacie_id = (select public.my_pharmacie()) and (select public.est_promoteur())));
revoke all on table public.stocks_couts from anon, authenticated;
grant select, insert, update, delete on table public.stocks_couts to authenticated;

-- 7. Clients, fidélisation, marge : 6 derniers mois, chiffres agrégés (jamais d'identité).
create or replace function public._stats_clients(p_ph uuid) returns jsonb
language sql stable security definer set search_path = public as $$
with debut as (select (date_trunc('month', now()) - interval '5 months')::date as d),
mois as (select g::date as m from generate_series((select d from debut), date_trunc('month', now())::date, interval '1 month') g),
base as (
  select r.client_id, r.statut, r.total, r.id, r.pharmacie_id, date_trunc('month', r.created_at)::date as mois
  from public.reservations r where (p_ph is null or r.pharmacie_id = p_ph)
),
cm as (select distinct client_id, mois from base),
prem as (select client_id, min(mois) as mois_premier from base group by client_id),
serie as (
  select m.m as mois,
    (select count(*) from cm where cm.mois = m.m)::int as clients,
    (select count(distinct b.client_id) from base b where b.mois = m.m and b.statut in ('retiree', 'payee'))::int as acheteurs,
    (select count(*) from prem where prem.mois_premier = m.m)::int as nouveaux,
    (select count(*) from cm a where a.mois = m.m and exists
       (select 1 from cm b2 where b2.client_id = a.client_id and b2.mois = (m.m - interval '1 month')::date))::int as fideles,
    (select count(*) from cm where cm.mois = (m.m - interval '1 month')::date)::int as clients_prec,
    coalesce((select sum(b.total) from base b where b.mois = m.m and b.statut in ('retiree', 'payee')), 0)::int as ca
  from mois m
),
marge as (
  select m.m as mois,
    coalesce(sum(ri.prix_unitaire * ri.quantite) filter (where c.prix_achat is not null), 0)::int as ca_couvert,
    coalesce(sum((ri.prix_unitaire - c.prix_achat) * ri.quantite) filter (where c.prix_achat is not null), 0)::int as marge
  from mois m
  left join base b on b.mois = m.m and b.statut in ('retiree', 'payee')
  left join public.reservation_items ri on ri.reservation_id = b.id
  left join public.stocks_couts c on c.pharmacie_id = b.pharmacie_id and c.produit_id = ri.produit_id
  group by m.m
)
select coalesce(jsonb_agg(jsonb_build_object(
  'mois', to_char(s.mois, 'YYYY-MM'), 'clients', s.clients, 'acheteurs', s.acheteurs, 'nouveaux', s.nouveaux,
  'fideles', s.fideles, 'clients_mois_precedent', s.clients_prec,
  'taux_retention', case when s.clients_prec > 0 then round(100.0 * s.fideles / s.clients_prec)::int end,
  'ca', s.ca, 'ca_couvert', mg.ca_couvert, 'marge', mg.marge
) order by s.mois), '[]'::jsonb)
from serie s join marge mg on mg.mois = s.mois
$$;
revoke execute on function public._stats_clients(uuid) from public, anon, authenticated;

create or replace function public.stats_clients(p_ph uuid default null) returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  if p_ph is null then
    if not public.is_admin() then raise exception 'Accès refusé'; end if;
  elsif not (public.is_admin() or (public.est_promoteur() and coalesce(p_ph = public.my_pharmacie(), false))) then
    raise exception 'Accès refusé';
  end if;
  return public._stats_clients(p_ph);
end $$;
revoke execute on function public.stats_clients(uuid) from public, anon;
grant execute on function public.stats_clients(uuid) to authenticated;

-- 8. Schéma BI en lecture seule (Power BI, Metabase, Looker Studio) : agrégats uniquement, aucune identité de client.
do $$
begin
  if not exists (select 1 from pg_roles where rolname = 'naxa_bi_lecture') then
    create role naxa_bi_lecture nologin;
  end if;
exception when insufficient_privilege then
  raise notice 'Création du rôle naxa_bi_lecture impossible ici : à faire depuis le tableau de bord Supabase.';
end $$;

create schema if not exists bi;
revoke all on schema bi from public, anon, authenticated;

create or replace view bi.activite_mensuelle as
select date_trunc('month', r.created_at)::date as mois, ph.nom as pharmacie, ph.quartier, ph.ville,
       count(*)::int as reservations,
       (count(*) filter (where r.statut in ('retiree', 'payee')))::int as retirees_payees,
       (count(*) filter (where r.statut in ('expiree', 'annulee')))::int as perdues,
       count(distinct r.client_id)::int as clients,
       coalesce(sum(r.total) filter (where r.statut in ('retiree', 'payee')), 0)::int as ca
from public.reservations r join public.pharmacies ph on ph.id = r.pharmacie_id
group by 1, 2, 3, 4;

create or replace view bi.recherches_quotidien as
select e.created_at::date as jour, e.type,
       count(*)::int as evenements,
       (count(*) filter (where e.resultats > 0))::int as avec_resultat,
       (count(*) filter (where e.resultats = 0))::int as sans_resultat
from public.evenements e group by 1, 2;

create or replace view bi.fidelisation_mensuelle as
with m as (select distinct client_id, date_trunc('month', created_at)::date as mois from public.reservations)
select a.mois, count(*)::int as clients, count(b.client_id)::int as fideles
from m a left join m b on b.client_id = a.client_id and b.mois = (a.mois - interval '1 month')::date
group by a.mois;

create or replace view bi.stock_pharmacies as
select ph.nom as pharmacie, ph.quartier, ph.ville, ph.actif, ph.stock_updated_at,
       (count(s.produit_id) filter (where s.quantite > 0))::int as produits_en_stock,
       (count(s.produit_id) filter (where s.quantite = 0))::int as produits_en_rupture
from public.pharmacies ph left join public.stocks s on s.pharmacie_id = ph.id
group by ph.id, ph.nom, ph.quartier, ph.ville, ph.actif, ph.stock_updated_at;

do $$
begin
  if exists (select 1 from pg_roles where rolname = 'naxa_bi_lecture') then
    grant usage on schema bi to naxa_bi_lecture;
    grant select on all tables in schema bi to naxa_bi_lecture;
  end if;
end $$;

-- 9. Envoi des rapports par e-mail : lecture réservée au serveur (clé service_role), jamais au navigateur.
alter table public.rapports add column if not exists envoye_le timestamptz;

create or replace function public.rapports_non_envoyes() returns table (
  rapport_id bigint, email text, portee text, pharmacie_nom text, periode text, du date, au date, texte text, contenu jsonb)
language sql stable security definer set search_path = public as $$
  select r.id, u.email::text, r.portee, ph.nom, r.periode, r.du, r.au, r.texte,
         r.contenu || jsonb_build_object('clients', public._stats_clients(case when r.portee = 'pharmacie' then r.pharmacie_id end))
  from public.rapports r
  left join public.pharmacies ph on ph.id = r.pharmacie_id
  join public.profiles p on (r.portee = 'pharmacie' and p.pharmacie_id = r.pharmacie_id and p.role = 'pharmacie' and p.niveau = 'promoteur' and p.statut = 'actif')
                         or (r.portee = 'admin' and p.role = 'admin')
  join auth.users u on u.id = p.id
  where r.envoye_le is null and u.email is not null
$$;

create or replace function public.marquer_rapport_envoye(p_id bigint) returns void
language sql security definer set search_path = public as $$
  update public.rapports set envoye_le = now() where id = p_id
$$;

revoke execute on function public.rapports_non_envoyes() from public, anon, authenticated;
revoke execute on function public.marquer_rapport_envoye(bigint) from public, anon, authenticated;
grant execute on function public.rapports_non_envoyes() to service_role;
grant execute on function public.marquer_rapport_envoye(bigint) to service_role;
