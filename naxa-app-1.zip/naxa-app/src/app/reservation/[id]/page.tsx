"use client";
import { useCallback, useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { supabaseBrowser } from "@/lib/supabase/client";
import { fcfa } from "@/lib/ranking";

type Resa = { id: string; statut: string; total: number; expires_at: string; paiement_ref: string | null; pharmacies: { nom: string; quartier: string | null } | null };

const LIBELLE: Record<string, string> = {
  en_attente: "En attente de la pharmacie", confirmee: "Confirmée par la pharmacie", payee: "Payée",
  retiree: "Retirée", expiree: "Expirée (non payée après 3 h)", annulee: "Annulée",
};

export default function Reservation() {
  const { id } = useParams<{ id: string }>();
  const [r, setR] = useState<Resa | null>(null);
  const [reste, setReste] = useState("");
  const [paiement, setPaiement] = useState<{ code_marchand: string; total: number } | null>(null);
  const [ref, setRef] = useState("");
  const [msg, setMsg] = useState("");

  const charger = useCallback(async () => {
    const { data } = await supabaseBrowser().from("reservations").select("id,statut,total,expires_at,paiement_ref,pharmacies(nom,quartier)").eq("id", id).single();
    setR(data as unknown as Resa);
  }, [id]);

  useEffect(() => { charger(); const t = setInterval(charger, 15000); return () => clearInterval(t); }, [charger]);

  useEffect(() => {
    if (!r) return;
    const maj = () => {
      const ms = new Date(r.expires_at).getTime() - Date.now();
      setReste(ms <= 0 ? "délai écoulé" : `${Math.floor(ms / 3600000)} h ${Math.floor((ms % 3600000) / 60000)} min`);
    };
    maj(); const t = setInterval(maj, 30000); return () => clearInterval(t);
  }, [r]);

  async function afficherPaiement() {
    const res = await fetch(`/api/pay/${id}`);
    if (res.ok) setPaiement(await res.json()); else setMsg("Paiement indisponible pour cette pharmacie. Payez sur place.");
  }
  async function declarer(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await supabaseBrowser().rpc("declare_payment", { p_id: id, p_ref: ref.trim() });
    setMsg(error ? "Référence non enregistrée. Réessayez." : "Référence envoyée. La pharmacie va confirmer votre paiement.");
    charger();
  }
  async function annuler() {
    const { error } = await supabaseBrowser().rpc("set_reservation_status", { p_id: id, p_statut: "annulee" });
    setMsg(error ? "Annulation impossible." : "Réservation annulée."); charger();
  }

  if (!r) return <main className="p-6">Chargement…</main>;
  const active = ["en_attente", "confirmee"].includes(r.statut);

  return (
    <main className="mx-auto max-w-lg space-y-4 px-4 py-8">
      <Link href="/" className="text-sm font-semibold underline underline-offset-4">← Accueil</Link>
      <h1 className="text-2xl font-extrabold">Réservation chez {r.pharmacies?.nom}</h1>
      <div className="carte space-y-1">
        <p><strong>Statut :</strong> {LIBELLE[r.statut] ?? r.statut}</p>
        <p><strong>Total :</strong> {fcfa(r.total)}</p>
        {active && <p><strong>Temps restant pour payer ou retirer :</strong> {reste}</p>}
        {active && <p className="text-sm text-slate-600">Sans paiement dans les 3 h, la réservation est annulée et le produit remis en vente.</p>}
      </div>

      {active && (
        <>
          <a className="btn btn-vert w-full" href={`/go/${id}`} target="_blank" rel="noreferrer">Envoyer ma réservation sur WhatsApp</a>
          <p className="text-sm text-slate-600">La pharmacie valide votre réservation par WhatsApp. Gardez ce message.</p>

          {!paiement ? (
            <button className="btn btn-clair w-full" onClick={afficherPaiement}>Payer en ligne (facultatif)</button>
          ) : (
            <form onSubmit={declarer} className="carte space-y-3">
              <p>Payez <strong>{fcfa(paiement.total)}</strong> avec le code marchand <strong className="text-xl">{paiement.code_marchand}</strong> (MTN MoMo ou Orange Money, menu « Paiement marchand »).</p>
              <label className="block text-sm font-semibold">Référence de la transaction reçue par SMS
                <input className="champ mt-1" required value={ref} onChange={(e) => setRef(e.target.value)} />
              </label>
              <button className="btn btn-vert w-full">J'ai payé</button>
            </form>
          )}
          <button className="btn btn-clair w-full" onClick={annuler}>Annuler la réservation</button>
        </>
      )}
      {["payee", "retiree"].includes(r.statut) && <Link className="btn btn-canari w-full" href={`/reservation/${id}/recu`}>Voir mon reçu</Link>}
      {msg && <p role="status" className="text-sm">{msg}</p>}
    </main>
  );
}
