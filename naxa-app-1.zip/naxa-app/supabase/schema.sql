-- NAXA : schéma Supabase (offre gratuite). À exécuter dans l'éditeur SQL.
-- Avant : activer l'extension pg_cron (Database > Extensions) pour l'expiration automatique des réservations.

create extension if not exists pg_trgm;
create extension if not exists unaccent;
create extension if not exists pgcrypto;

create type role_type as enum ('client', 'pharmacie', 'admin');
create type resa_statut as enum ('en_attente', 'confirmee', 'payee', 'retiree', 'expiree', 'annulee');

-- ---------- Tables ----------
create table pharmacies (
  id uuid primary key default gen_random_uuid(),
  nom text not null,
  ville text not null default 'Yaoundé',
  quartier text,
  adresse text,
  lat double precision not null,
  lng double precision not null,
  de_garde boolean not null default false,
  horaires text,
  actif boolean not null default true,
  stock_updated_at timestamptz,
  created_at timestamptz not null default now()
);

create table profiles (
  id uuid primary key references auth.users on delete cascade,
  role role_type not null default 'client',
  username text unique,
  pharmacie_id uuid references pharmacies(id),
  created_at timestamptz not null default now()
);

-- Données privées : jamais lisibles par un client (accès serveur uniquement, via la clé service).
create table pharmacie_privee (
  pharmacie_id uuid primary key references pharmacies(id) on delete cascade,
  whatsapp text not null,           -- format international sans + (ex. 2376XXXXXXXX)
  code_marchand text
);

create table produits (
  id uuid primary key default gen_random_uuid(),
  nom text not null,
  dci text not null default '',
  dosage text not null default '',
  forme text not null default '',
  nom_norm text,
  unique (nom, dosage, forme)
);

create or replace function produits_norm() returns trigger language plpgsql as $$
begin
  new.nom_norm := lower(unaccent(coalesce(new.nom,'') || ' ' || coalesce(new.dci,'') || ' ' || coalesce(new.dosage,'')));
  return new;
end $$;
create trigger trg_produits_norm before insert or update on produits
  for each row execute function produits_norm();
create index produits_nom_trgm on produits using gin (nom_norm gin_trgm_ops);

create table stocks (
  pharmacie_id uuid not null references pharmacies(id) on delete cascade,
  produit_id uuid not null references produits(id) on delete cascade,
  prix integer not null check (prix >= 0),            -- FCFA
  quantite integer not null default 0 check (quantite >= 0),
  date_peremption date,
  updated_at timestamptz not null default now(),
  primary key (pharmacie_id, produit_id)
);

create or replace function stocks_touch() returns trigger language plpgsql security definer set search_path = public as $$
begin
  new.updated_at := now();
  update pharmacies set stock_updated_at = now() where id = new.pharmacie_id;
  return new;
end $$;
create trigger trg_stocks_touch before insert or update on stocks
  for each row execute function stocks_touch();

create table reservations (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references auth.users,
  pharmacie_id uuid not null references pharmacies(id),
  statut resa_statut not null default 'en_attente',
  total integer not null default 0,
  expires_at timestamptz not null,
  paiement_ref text,
  created_at timestamptz not null default now()
);

create table reservation_items (
  reservation_id uuid not null references reservations(id) on delete cascade,
  produit_id uuid not null references produits(id),
  quantite integer not null check (quantite > 0),
  prix_unitaire integer not null,
  primary key (reservation_id, produit_id)
);

-- Création automatique du profil à l'inscription
create or replace function handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, role, username)
  values (new.id, 'client', split_part(new.email, '@', 1) || '_' || substr(new.id::text, 1, 4))
  on conflict do nothing;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- ---------- Sécurité (RLS) ----------
create or replace function is_admin() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'admin')
$$;
create or replace function my_pharmacie() returns uuid language sql stable security definer set search_path = public as $$
  select pharmacie_id from profiles where id = auth.uid()
$$;

alter table profiles enable row level security;
alter table pharmacies enable row level security;
alter table pharmacie_privee enable row level security;
alter table produits enable row level security;
alter table stocks enable row level security;
alter table reservations enable row level security;
alter table reservation_items enable row level security;

create policy profiles_self on profiles for select using (id = auth.uid() or is_admin());
create policy profiles_admin on profiles for all using (is_admin()) with check (is_admin());

create policy pharmacies_read on pharmacies for select using (actif or is_admin());
create policy pharmacies_admin on pharmacies for all using (is_admin()) with check (is_admin());

-- pharmacie_privee : aucune policy => inaccessible côté client (la clé service contourne la RLS)

create policy produits_read on produits for select using (true);
create policy produits_write on produits for insert with check (is_admin() or my_pharmacie() is not null);
create policy produits_update on produits for update using (is_admin() or my_pharmacie() is not null);

create policy stocks_read on stocks for select using (true);
create policy stocks_write on stocks for all
  using (pharmacie_id = my_pharmacie() or is_admin())
  with check (pharmacie_id = my_pharmacie() or is_admin());

create policy resa_read on reservations for select
  using (client_id = auth.uid() or pharmacie_id = my_pharmacie() or is_admin());
create policy resa_items_read on reservation_items for select
  using (exists (select 1 from reservations r where r.id = reservation_id
        and (r.client_id = auth.uid() or r.pharmacie_id = my_pharmacie() or is_admin())));
-- Aucune policy d'écriture sur reservations : tout passe par les fonctions ci-dessous.

-- ---------- Recherche : pharmacies qui ont le(s) médicament(s) en stock ----------
create or replace function search_pharmacies(p_terms text[], p_lat float8, p_lng float8, p_rayon_km float8 default 20)
returns table (
  pharmacie_id uuid, nom text, quartier text, adresse text, lat float8, lng float8,
  de_garde boolean, stock_updated_at timestamptz, distance_km float8,
  total_prix int, items jsonb, trouves int, demandes int
)
language sql stable as $$
  with termes as (
    select row_number() over () as n, lower(unaccent(trim(t))) as q
    from unnest(p_terms) t where length(trim(t)) > 1
  ),
  nb as (select count(*)::int as c from termes),
  cand as (
    select t.n, s.pharmacie_id, pr.id as produit_id, pr.nom, pr.dosage, s.prix, s.quantite,
           row_number() over (partition by t.n, s.pharmacie_id
                              order by similarity(pr.nom_norm, t.q) desc, s.prix asc) as rk
    from termes t
    join produits pr on pr.nom_norm % t.q or pr.nom_norm ilike '%' || t.q || '%'
    join stocks s on s.produit_id = pr.id and s.quantite > 0
  ),
  best as (select * from cand where rk = 1),
  agg as (
    select pharmacie_id, count(distinct n)::int as trouves, sum(prix)::int as total,
           jsonb_agg(jsonb_build_object('produit_id', produit_id, 'nom', nom, 'dosage', dosage,
                                        'prix', prix, 'quantite', quantite) order by n) as items
    from best group by pharmacie_id
  )
  select ph.id, ph.nom, ph.quartier, ph.adresse, ph.lat, ph.lng, ph.de_garde, ph.stock_updated_at,
         d.km, a.total, a.items, a.trouves, nb.c
  from agg a
  join pharmacies ph on ph.id = a.pharmacie_id and ph.actif
  cross join nb
  cross join lateral (
    select 6371 * 2 * asin(sqrt(
      power(sin(radians(ph.lat - p_lat) / 2), 2) +
      cos(radians(p_lat)) * cos(radians(ph.lat)) * power(sin(radians(ph.lng - p_lng) / 2), 2)
    )) as km
  ) d
  where d.km <= p_rayon_km
  order by (a.trouves = nb.c) desc, d.km;
$$;

-- ---------- Réservation : le stock est mis de côté pendant 3 h ----------
create or replace function reserve_stock(p_pharmacie uuid, p_items jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid; it jsonb; v_total int := 0; v_prix int; v_q int;
begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  if not exists (select 1 from pharmacies where id = p_pharmacie and actif) then
    raise exception 'Pharmacie indisponible';
  end if;
  insert into reservations (client_id, pharmacie_id, expires_at)
  values (auth.uid(), p_pharmacie, now() + interval '3 hours') returning id into v_id;

  for it in select * from jsonb_array_elements(p_items) loop
    v_q := coalesce((it->>'quantite')::int, 1);
    update stocks set quantite = quantite - v_q
     where pharmacie_id = p_pharmacie and produit_id = (it->>'produit_id')::uuid and quantite >= v_q
     returning prix into v_prix;
    if not found then raise exception 'Stock insuffisant pour un des produits'; end if;
    insert into reservation_items values (v_id, (it->>'produit_id')::uuid, v_q, v_prix);
    v_total := v_total + v_prix * v_q;
  end loop;

  update reservations set total = v_total where id = v_id;
  return v_id;
end $$;

create or replace function restore_stock(p_resa uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  update stocks s set quantite = s.quantite + ri.quantite
  from reservation_items ri, reservations r
  where r.id = p_resa and ri.reservation_id = r.id
    and s.pharmacie_id = r.pharmacie_id and s.produit_id = ri.produit_id;
end $$;

-- Changement de statut : pharmacie de la réservation, admin, ou client (annulation seulement)
create or replace function set_reservation_status(p_id uuid, p_statut resa_statut) returns void
language plpgsql security definer set search_path = public as $$
declare r reservations;
begin
  select * into r from reservations where id = p_id for update;
  if not found then raise exception 'Réservation introuvable'; end if;
  if not (is_admin() or r.pharmacie_id = my_pharmacie()
          or (r.client_id = auth.uid() and p_statut = 'annulee')) then
    raise exception 'Action non autorisée';
  end if;
  if r.statut in ('retiree', 'expiree', 'annulee') then raise exception 'Réservation déjà clôturée'; end if;
  if p_statut in ('annulee', 'expiree') then perform restore_stock(p_id); end if;
  update reservations set statut = p_statut where id = p_id;
end $$;

-- Le client déclare son paiement (référence de transaction) ; la pharmacie confirme ensuite « payee ».
create or replace function declare_payment(p_id uuid, p_ref text) returns void
language plpgsql security definer set search_path = public as $$
begin
  update reservations set paiement_ref = p_ref
   where id = p_id and client_id = auth.uid() and statut in ('en_attente', 'confirmee');
  if not found then raise exception 'Réservation introuvable ou close'; end if;
end $$;

-- Annulation automatique : non payée au bout de 3 h => annulée et stock remis.
create or replace function expire_reservations() returns int
language plpgsql security definer set search_path = public as $$
declare n int := 0; r record;
begin
  for r in select id from reservations
           where statut in ('en_attente', 'confirmee') and expires_at < now() for update skip locked
  loop
    perform restore_stock(r.id);
    update reservations set statut = 'expiree' where id = r.id;
    n := n + 1;
  end loop;
  return n;
end $$;

-- Planification toutes les 5 minutes (nécessite pg_cron activé) :
-- select cron.schedule('naxa-expire', '*/5 * * * *', $$select public.expire_reservations()$$);

-- Premier administrateur : après la première connexion, exécuter
-- update profiles set role = 'admin' where id = '<UUID-de-votre-compte>';

-- La pharmacie bascule elle-même son statut « de garde » (sans pouvoir modifier ses autres champs).
create or replace function set_garde(p_garde boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  if my_pharmacie() is null then raise exception 'Réservé aux pharmacies'; end if;
  update pharmacies set de_garde = p_garde where id = my_pharmacie();
end $$;
