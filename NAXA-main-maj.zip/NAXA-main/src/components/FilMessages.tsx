"use client";
import { useEffect, useRef, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/client";
import type { Msg } from "@/lib/messagerie";
const heure = (v: string) => new Intl.DateTimeFormat("fr-FR", { dateStyle: "short", timeStyle: "short" }).format(new Date(v));

/** Conversation partagée client / pharmacie. `moi` = rôle de l'utilisateur courant. */
export function FilMessages({ filId, moi, titre, onRetour }: { filId: string; moi: "client" | "pharmacie"; titre: string; onRetour: () => void }) {
  const [msgs, setMsgs] = useState<Msg[]>([]), [texte, setTexte] = useState(""), [erreur, setErreur] = useState(""), fin = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const sb = supabaseBrowser();
    (async () => {
      const { data } = await sb.from("messages_pharmacie").select("id,fil_id,expediteur,corps,created_at").eq("fil_id", filId).order("created_at");
      setMsgs((data ?? []) as Msg[]); await sb.rpc("marquer_fil_lu", { p_fil: filId });
    })();
    const canal = sb.channel("fil-" + filId).on("postgres_changes", { event: "INSERT", schema: "public", table: "messages_pharmacie", filter: `fil_id=eq.${filId}` }, (p) => {
      setMsgs((l) => (l.some((m) => m.id === (p.new as Msg).id) ? l : [...l, p.new as Msg])); void sb.rpc("marquer_fil_lu", { p_fil: filId });
    }).subscribe();
    return () => { void sb.removeChannel(canal); };
  }, [filId]);
  useEffect(() => { fin.current?.scrollIntoView({ block: "end" }); }, [msgs.length]);
  async function envoyer() {
    const corps = texte.trim(); if (!corps) return; setErreur("");
    const { error } = await supabaseBrowser().rpc("repondre_message", { p_fil: filId, p_corps: corps });
    if (error) return setErreur("Envoi impossible. Réessayez."); setTexte("");
  }
  return <section className="carte flex min-h-[60vh] flex-col">
    <div className="mb-3 flex items-center gap-3"><button type="button" onClick={onRetour} className="text-sm font-bold underline">← Retour</button><h2 className="truncate text-lg font-extrabold">{titre}</h2></div>
    <ol className="flex-1 space-y-2 overflow-y-auto">{msgs.map((m) => <li key={m.id} className={"max-w-[85%] rounded-2xl px-3 py-2 text-sm " + (m.expediteur === moi ? "ml-auto bg-naxa-canari" : "bg-slate-100")}><p>{m.corps}</p><p className="mt-1 text-[10px] text-slate-500">{heure(m.created_at)}</p></li>)}<div ref={fin} /></ol>
    {erreur && <p role="alert" className="text-sm text-red-700">{erreur}</p>}
    <div className="mt-3 flex gap-2"><input className="champ flex-1" value={texte} maxLength={1000} onChange={(e) => setTexte(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") void envoyer(); }} placeholder="Votre réponse…" aria-label="Votre réponse" /><button type="button" className="btn btn-canari" onClick={envoyer}>Envoyer</button></div>
  </section>;
}
