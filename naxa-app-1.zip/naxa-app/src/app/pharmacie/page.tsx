"use client";
import { useCallback, useEffect, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/client";
import { importerStock } from "@/lib/importStock";
import { fcfa } from "@/lib/ranking";
import { Logo } from "@/components/Logo";

type Ligne = { produit_id: string; prix: number; quantite: number; date_peremption: string | null; produits: { nom: string; dosage: string } | null };
type Resa = { id: string; statut: string; total: number; expires_at: string; paiement_ref: string | null; reservation_items: { quantite: number; produits: { nom: string } | null }[] };

export default function PanneauPharmacie() {
  const sb = supabaseBrowser();
  const [pid, setPid] = useState<string | null>(null);
  const [nom, setNom] = useState("");
  const [stock, setStock] = useState<Ligne[]>([]);
  const [resas, setResas] = useState<Resa[]>([]);
  const [filtre, setFiltre] = useState("");
  const [msg, setMsg] = useState("");
  const [enLigne, setEnLigne] = useState(true);

  const charger = useCallback(async (id: string) => {
    const [{ data: s }, { data: r }] = await Promise.all([
      sb.from("stocks").select("produit_id,prix,quantite,date_peremption,produits(nom,dosage)").eq("pharmacie_id", id).order("quantite"),
      sb.from("reservations").select("id,statut,total,expires_at,paiement_ref,reservation_items(quantite,produits(nom))").eq("pharmacie_id", id).in("statut", ["en_attente", "confirmee", "payee"]).order("created_at", { ascending: false }),
    ]);
    setStock((s ?? []) as unknown as Ligne[]);
    setResas((r ?? []) as unknown as Resa[]);
  }, [sb]);

  useEffect(() => {
    const maj = () => setEnLigne(navigator.onLine);
    maj(); addEventListener("online", maj); addEventListener("offline", maj);
    (async () => {
      const { data: u } = await sb.auth.getUser();
      const { data: p } = await sb.from("profiles").select("pharmacie_id").eq("id", u.user!.id).single();
      if (!p?.pharmacie_id) return setMsg("Ce compte n'est lié à aucune pharmacie.");
      setPid(p.pharmacie_id);
      const { data: ph } = await sb.from("pharmacies").select("nom").eq("id", p.pharmacie_id).single();
      setNom(ph?.nom ?? "");
      charger(p.pharmacie_id);
    })();
    const t = setInterval(() => pid && charger(pid), 20000);
    return () => { clearInterval(t); removeEventListener("online", maj); removeEventListener("offline", maj); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pid]);

  async function statut(id: string, s: string) {
    const { error } = await sb.rpc("set_reservation_status", { p_id: id, p_statut: s });
    setMsg(error ? "Action impossible." : "Réservation mise à jour."); pid && charger(pid);
  }
  async function maj(l: Ligne, champ: "prix" | "quantite", v: number) {
    const { error } = await sb.from("stocks").update({ [champ]: Math.max(0, Math.round(v)) }).eq("pharmacie_id", pid!).eq("produit_id", l.produit_id);
    setMsg(error ? "Modification non enregistrée (connexion ?)." : "Enregistré."); 
  }
  async function importer(f: File) {
    try { const r = await importerStock(f, pid!); setMsg(`${r.importes} produits importés, ${r.ignores} lignes ignorées.`); charger(pid!); }
    catch { setMsg("Import impossible. Colonnes attendues : nom, prix, quantité (dosage et péremption facultatifs)."); }
  }

  const vus = stock.filter((l) => (l.produits?.nom ?? "").toLowerCase().includes(filtre.toLowerCase()));
  const jours = (d: string | null) => (d ? Math.round((new Date(d).getTime() - Date.now()) / 86400000) : null);

  return (
    <main className="mx-auto max-w-4xl px-4 pb-16">
      <header className="-mx-4 mb-4 flex items-center justify-between bg-naxa-green-900 px-4 py-3 text-white">
        <Logo taille={32} /><span className="font-semibold">{nom}</span>
      </header>
      {!enLigne && <p role="status" className="mb-3 rounded-xl2 bg-naxa-canari px-4 py-2 font-semibold">Hors connexion : les modifications ne sont pas enregistrées. Reconnectez-vous avant de continuer.</p>}
      {msg && <p role="status" className="mb-3 text-sm">{msg}</p>}

      <section aria-labelledby="t-resa" className="space-y-3">
        <h1 id="t-resa" className="text-xl font-extrabold">Réservations en cours ({resas.length})</h1>
        {resas.length === 0 && <p className="text-slate-600">Aucune réservation en cours.</p>}
        {resas.map((r) => (
          <div key={r.id} className="carte space-y-2">
            <p className="font-bold">N° {r.id.slice(0, 8).toUpperCase()} · {fcfa(r.total)} · {r.statut.replace("_", " ")}</p>
            <p className="text-sm">{r.reservation_items.map((i) => `${i.quantite} × ${i.produits?.nom}`).join(", ")}</p>
            {r.paiement_ref && <p className="text-sm">Référence de paiement déclarée : <strong>{r.paiement_ref}</strong></p>}
            <div className="flex flex-wrap gap-2">
              {r.statut === "en_attente" && <button className="btn btn-vert !min-h-[40px]" onClick={() => statut(r.id, "confirmee")}>Confirmer</button>}
              {["en_attente", "confirmee"].includes(r.statut) && <button className="btn btn-canari !min-h-[40px]" onClick={() => statut(r.id, "payee")}>Paiement reçu</button>}
              {["confirmee", "payee"].includes(r.statut) && <button className="btn btn-vert !min-h-[40px]" onClick={() => statut(r.id, "retiree")}>Remise au client</button>}
              <button className="btn btn-clair !min-h-[40px]" onClick={() => statut(r.id, "annulee")}>Annuler</button>
            </div>
          </div>
        ))}
      </section>

      <section aria-labelledby="t-stock" className="mt-10 space-y-3">
        <h2 id="t-stock" className="text-xl font-extrabold">Mon stock</h2>
        <div className="flex flex-wrap gap-2">
          <input className="champ flex-1" placeholder="Rechercher un produit" value={filtre} onChange={(e) => setFiltre(e.target.value)} />
          <label className="btn btn-clair cursor-pointer">Importer Excel<input type="file" hidden accept=".xlsx,.xls,.csv" onChange={(e) => e.target.files?.[0] && importer(e.target.files[0])} /></label>
          <button className="btn btn-clair" onClick={async () => { await sb.rpc("set_garde", { p_garde: true }); setMsg("Pharmacie marquée de garde."); }}>Je suis de garde</button>
          <button className="btn btn-clair" onClick={async () => { await sb.rpc("set_garde", { p_garde: false }); setMsg("Garde terminée."); }}>Fin de garde</button>
        </div>
        <div className="overflow-x-auto carte !p-0">
          <table className="w-full text-sm">
            <thead className="bg-naxa-green-100 text-left"><tr><th className="p-3">Produit</th><th className="p-3">Quantité</th><th className="p-3">Prix (FCFA)</th><th className="p-3">Péremption</th></tr></thead>
            <tbody>
              {vus.map((l) => {
                const j = jours(l.date_peremption);
                return (
                  <tr key={l.produit_id} className="border-t">
                    <td className="p-3">{l.produits?.nom} {l.produits?.dosage}{l.quantite < 10 && <span className="ml-2 rounded-full bg-red-100 px-2 py-0.5 text-xs font-bold text-red-800">Stock bas</span>}</td>
                    <td className="p-3"><input aria-label="Quantité" type="number" min={0} defaultValue={l.quantite} className="w-20 rounded border p-1" onBlur={(e) => maj(l, "quantite", Number(e.target.value))} /></td>
                    <td className="p-3"><input aria-label="Prix" type="number" min={0} defaultValue={l.prix} className="w-24 rounded border p-1" onBlur={(e) => maj(l, "prix", Number(e.target.value))} /></td>
                    <td className="p-3">{l.date_peremption ?? "—"}{j !== null && j < 30 && <span className="ml-2 rounded-full bg-naxa-canari px-2 py-0.5 text-xs font-bold">Expire bientôt</span>}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </main>
  );
}
