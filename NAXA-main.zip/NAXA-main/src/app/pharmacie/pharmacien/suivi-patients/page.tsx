"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { PharmacienWorkspaceShell } from "@/components/pharmacie/PharmacienWorkspaceShell";
import { supabaseBrowser } from "@/lib/supabase/client";

type Share = { id: string; owner_user_id: string; measurement_type: string; granted_at: string; active: boolean; revoked_at: string | null };
type Measurement = { id: string; user_id: string; measurement_type: string; value_numeric: number | null; value_text: string | null; unit: string | null; measured_at: string; source: string; note: string | null };
type SharedAlert = { id: string; user_id: string; measurement_id: string; measurement_type: string; observed_value: number; alert_kind: "below_user_range" | "above_user_range"; created_at: string; read_at: string | null };
type ViewTab = "patients" | "mesures" | "alertes" | "partages";
type TrendPoint = { id: string; measured_at: string; value_numeric: number; unit: string | null };
const labels: Record<string, string> = {
  tension_systolique: "Tension systolique", tension_diastolique: "Tension diastolique",
  frequence_cardiaque: "Fréquence cardiaque", temperature: "Température",
  saturation_oxygene: "Saturation en oxygène", glycemie: "Glycémie", poids: "Poids",
  taille: "Taille", imc: "IMC", frequence_respiratoire: "Fréquence respiratoire",
  cholesterol_total: "Cholestérol total", sommeil_heures: "Sommeil", pas_jour: "Pas",
  activite_minutes: "Activité", hydratation_ml: "Hydratation", douleur_score: "Douleur (auto-déclarée)",
  humeur_score: "Humeur (auto-déclarée)", cycle_jour: "Cycle", medicament_pris: "Prise de traitement déclarée",
  symptome_note: "Note de symptôme", debit_expiratoire: "Débit expiratoire", ecg_note: "Note ECG",
  masse_grasse: "Masse grasse", masse_musculaire: "Masse musculaire", masse_osseuse: "Masse osseuse",
  cetonemie: "Cétonémie", acide_urique: "Acide urique", cholesterol_hdl: "Cholestérol HDL",
  cholesterol_ldl: "Cholestérol LDL", capacite_vitale: "Capacité vitale",
};
const dateLabel = (value: string) => new Date(value).toLocaleString("fr-FR", { dateStyle: "medium", timeStyle: "short" });
const patientLabel = (id: string) => `Patient ${id.slice(0, 8).toUpperCase()}`;

export default function PharmacienSuiviPatientsPage() {
  const sb = useMemo(() => supabaseBrowser(), []);
  const [recipientId, setRecipientId] = useState("");
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);
  const [shares, setShares] = useState<Share[]>([]);
  const [measurements, setMeasurements] = useState<Measurement[]>([]);
  const [alerts, setAlerts] = useState<SharedAlert[]>([]);
  const [alertError, setAlertError] = useState("");
  const [tab, setTab] = useState<ViewTab>("patients");
  const [selectedPatientId, setSelectedPatientId] = useState<string | null>(null);
  const [trendType, setTrendType] = useState("");
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("tous");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const loadSharedData = useCallback(async (userId: string) => {
    setBusy(true);
    setError("");
    const { data, error: shareError } = await sb.from("suivi_shares")
      .select("id,owner_user_id,measurement_type,granted_at,active,revoked_at")
      .eq("recipient_user_id", userId).eq("active", true).is("revoked_at", null)
      .order("granted_at", { ascending: false }).limit(500);
    if (shareError) {
      setShares([]); setMeasurements([]); setAlerts([]);setLastUpdated(new Date().toISOString());
      setError("Les partages ne sont pas accessibles. Vérifiez la migration 127, la migration 189, la vérification du professionnel et l’autorisation expérimentale du compte.");
      setBusy(false); return;
    }
    const activeShares = (data ?? []) as Share[];
    setShares(activeShares);
    const owners = [...new Set(activeShares.map(item => item.owner_user_id))];
    const types = [...new Set(activeShares.map(item => item.measurement_type))];
    if (!owners.length || !types.length) {
      setMeasurements([]);setAlerts([]);setAlertError("");setLastUpdated(new Date().toISOString());
      setNotice("Aucun patient ne partage actuellement de mesure avec ce compte.");
      setBusy(false); return;
    }
    const { data: rows, error: measurementError } = await sb.from("suivi_measurements")
      .select("id,user_id,measurement_type,value_numeric,value_text,unit,measured_at,source,note")
      .in("user_id", owners).in("measurement_type", types)
      .order("measured_at", { ascending: false }).limit(500);
    if (measurementError) {
      setMeasurements([]);
      setError("Les partages sont visibles mais les mesures restent bloquées par les droits serveur. Vérifiez la migration 189 et ses tests SQL.");
      setBusy(false); return;
    }
    const allowed = new Set(activeShares.map(item => `${item.owner_user_id}:${item.measurement_type}`));
    setMeasurements(((rows ?? []) as Measurement[]).filter(row => allowed.has(`${row.user_id}:${row.measurement_type}`)));
    const {data:alertRows,error:alertQueryError}=await sb.from("suivi_alerts").select("id,user_id,measurement_id,measurement_type,observed_value,alert_kind,created_at,read_at").in("user_id",owners).in("measurement_type",types).order("created_at",{ascending:false}).limit(200);
    if(alertQueryError){setAlerts([]);setAlertError("Les alertes partagées attendent la migration 192 ou les droits RLS correspondants.");}
    else{setAlerts(((alertRows??[]) as SharedAlert[]).filter(alert=>allowed.has(`${alert.user_id}:${alert.measurement_type}`)));setAlertError("");}
    setNotice("Données affichées uniquement pour les types de mesure explicitement partagés et encore actifs.");
    setLastUpdated(new Date().toISOString());
    setBusy(false);
  }, [sb]);

  const refresh = useCallback(async () => {
    setLoading(true); setError(""); setNotice("");
    const { data: auth, error: authError } = await sb.auth.getUser();
    if (authError || !auth.user) { setError("Connexion requise."); setLoading(false); return; }
    const { data: profile, error: profileError } = await sb.from("profiles")
      .select("actif,fonction_interne,pharmacie_id").eq("id", auth.user.id).maybeSingle();
    if (profileError || !profile || profile.actif !== true || profile.fonction_interne !== "pharmacien" || !profile.pharmacie_id) {
      setError("Accès réservé à un compte Pharmacien actif rattaché à une pharmacie."); setLoading(false); return;
    }
    const { data: pharmacy, error: pharmacyError } = await sb.from("pharmacies")
      .select("id,actif").eq("id", profile.pharmacie_id).maybeSingle();
    if (pharmacyError || !pharmacy || pharmacy.actif !== true) {
      setError("La pharmacie est inactive ; l’accès au suivi patient est bloqué."); setLoading(false); return;
    }
    setRecipientId(auth.user.id);
    await loadSharedData(auth.user.id);
    setLoading(false);
  }, [sb, loadSharedData]);

  useEffect(() => { void refresh(); }, [refresh]);
  useEffect(() => {
    if (!recipientId) return;
    const channel=sb.channel("pharmacien-suivi-partages")
      .on("postgres_changes",{event:"*",schema:"public",table:"suivi_measurements"},()=>{void loadSharedData(recipientId);})
      .on("postgres_changes",{event:"*",schema:"public",table:"suivi_alerts"},()=>{void loadSharedData(recipientId);})
      .subscribe();
    const poll=window.setInterval(()=>{void loadSharedData(recipientId);},30000);
    return ()=>{window.clearInterval(poll);void sb.removeChannel(channel);};
  },[sb,recipientId,loadSharedData]);
  const owners = [...new Set(shares.map(item => item.owner_user_id))];
  const types = [...new Set(shares.map(item => item.measurement_type))].sort();
  const filteredAlerts=alerts.filter(alert=>{
    const q=search.trim().toLowerCase();
    const patientMatch=!q||patientLabel(alert.user_id).toLowerCase().includes(q)||alert.user_id.toLowerCase().includes(q);
    return patientMatch&&(typeFilter==="tous"||alert.measurement_type===typeFilter);
  });
  const filteredMeasurements = measurements.filter(row => {
    const query = search.trim().toLowerCase();
    const patientMatch = !query || patientLabel(row.user_id).toLowerCase().includes(query) || row.user_id.toLowerCase().includes(query);
    const typeMatch = typeFilter === "tous" || row.measurement_type === typeFilter;
    return patientMatch && typeMatch;
  });
  const selectedPatient = selectedPatientId && owners.includes(selectedPatientId) ? selectedPatientId : null;
  const trendTypes = selectedPatient
    ? [...new Set(measurements.filter(row => row.user_id === selectedPatient && row.value_numeric !== null).map(row => row.measurement_type))].sort()
    : [];
  const activeTrendType = trendTypes.includes(trendType) ? trendType : (trendTypes[0] ?? "");
  const trendPoints: TrendPoint[] = selectedPatient && activeTrendType
    ? measurements
        .filter((row): row is Measurement & { value_numeric: number } => row.user_id === selectedPatient && row.measurement_type === activeTrendType && row.value_numeric !== null)
        .sort((a, b) => a.measured_at.localeCompare(b.measured_at))
        .slice(-20)
    : [];
  const trendValues = trendPoints.map(point => point.value_numeric);
  const trendMin = trendValues.length ? Math.min(...trendValues) : 0;
  const trendMax = trendValues.length ? Math.max(...trendValues) : 0;
  const trendRange = trendMax - trendMin || 1;
  const trendCoordinates = trendPoints.map((point, index) => ({
    x: trendPoints.length <= 1 ? 300 : 24 + (index * 552) / (trendPoints.length - 1),
    y: 142 - ((point.value_numeric - trendMin) / trendRange) * 112,
  }));
  const trendPolyline = trendCoordinates.map(point => `${point.x},${point.y}`).join(" ");
  const measurementsByPatient = owners.map(owner => ({
    owner,
    shareCount: shares.filter(item => item.owner_user_id === owner).length,
    latest: measurements.filter(item => item.user_id === owner).sort((a, b) => b.measured_at.localeCompare(a.measured_at))[0] ?? null,
  })).filter(row => !search.trim() || patientLabel(row.owner).toLowerCase().includes(search.trim().toLowerCase()) || row.owner.toLowerCase().includes(search.trim().toLowerCase()));

  return <PharmacienWorkspaceShell activeTab="dispositifs" onNavigate={section => {
    if (section === "dashboard") window.location.href = "/pharmacie/pharmacien";
    else if (section === "dispositifs") window.location.href = "/pharmacie/pharmacien/suivi-patients";
    else window.location.href = `/pharmacie/pharmacien/${section}`;
  }}>
    <header className="flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-[#0B3D26] px-4 py-4 text-white">
      <div><a href="/pharmacie/pharmacien" className="text-sm text-emerald-100 hover:text-white">← Espace Pharmacien</a><h1 className="mt-1 text-2xl font-black">Suivi des patients</h1><p className="mt-1 text-sm text-emerald-100">Mesures partagées, consentement et traçabilité des accès.</p></div>
      <div className="flex flex-col items-end gap-1"><button type="button" onClick={() => void refresh()} disabled={loading || busy} className="min-h-10 rounded-xl border border-white/30 px-4 py-2 text-sm font-bold disabled:opacity-50">Actualiser</button><span className="text-xs text-emerald-100">{lastUpdated ? `Mis à jour ${new Date(lastUpdated).toLocaleTimeString("fr-FR")}` : "Mise à jour en attente"}</span></div>
    </header>
    <section className="carte space-y-3"><div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4"><div className="rounded-xl bg-slate-50 p-3"><p className="text-sm text-slate-600">Patients partageant des mesures</p><p className="text-2xl font-black">{owners.length}</p></div><div className="rounded-xl bg-slate-50 p-3"><p className="text-sm text-slate-600">Types partagés</p><p className="text-2xl font-black">{types.length}</p></div><div className="rounded-xl bg-slate-50 p-3"><p className="text-sm text-slate-600">Mesures visibles</p><p className="text-2xl font-black">{measurements.length}</p></div><div className="rounded-xl bg-slate-50 p-3"><p className="text-sm text-slate-600">Alertes partagées</p><p className="text-2xl font-black">{alerts.length}</p></div></div>
      <p className="text-sm text-slate-600">Les identités sont masquées par défaut. NAXA affiche les mesures partagées sans poser de diagnostic ni recommander de posologie.</p>
    </section>
    {notice && <p role="status" className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-900">{notice}</p>}
    {error && <div role="alert" className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-950"><b>Accès ou chargement limité</b><p className="mt-1">{error}</p></div>}
    <section className="carte space-y-4">
      <div className="flex flex-wrap gap-2" role="tablist" aria-label="Onglets du suivi patient">
        {([{id:"patients",label:"Patients partagés"},{id:"mesures",label:"Mesures"},{id:"alertes",label:"Alertes"},{id:"partages",label:"Partages et accès"}] as const).map(item=><button key={item.id} type="button" role="tab" aria-selected={tab===item.id} onClick={()=>setTab(item.id)} className={`min-h-10 rounded-xl px-4 py-2 text-sm font-bold ${tab===item.id ? "bg-[#0B3D26] text-white" : "bg-slate-100 text-slate-700"}`}>{item.label}</button>)}
      </div>
      <div className="grid gap-3 sm:grid-cols-[1fr_16rem]"><label className="block text-sm font-semibold">Rechercher un patient partagé<input className="champ mt-1 w-full" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Identifiant anonymisé"/></label>{(tab==="mesures"||tab==="alertes") && <label className="block text-sm font-semibold">Type de mesure<select className="champ mt-1 w-full" value={typeFilter} onChange={e=>setTypeFilter(e.target.value)}><option value="tous">Tous les types partagés</option>{types.map(type=><option key={type} value={type}>{labels[type] ?? type}</option>)}</select></label>}</div>
      {loading ? <p className="rounded-xl bg-slate-50 p-4 text-sm">Chargement des partages autorisés…</p> : <>
        {tab==="patients" && (measurementsByPatient.length ? <div className="space-y-3">{measurementsByPatient.map(patient=><article key={patient.owner} className="rounded-xl border border-slate-200 p-4"><div className="flex flex-wrap items-start justify-between gap-2"><div><h2 className="font-extrabold">{patientLabel(patient.owner)}</h2><p className="text-sm text-slate-600">{patient.shareCount} type(s) partagé(s)</p></div><button type="button" className="btn btn-clair" onClick={()=>{setSelectedPatientId(patient.owner);setSearch(patientLabel(patient.owner));setTypeFilter("tous");setTab("mesures");}}>Ouvrir le dossier</button></div>{patient.latest ? <p className="mt-3 rounded-lg bg-slate-50 p-3 text-sm">Dernière mesure reçue : <b>{labels[patient.latest.measurement_type] ?? patient.latest.measurement_type}</b> · {dateLabel(patient.latest.measured_at)}</p> : <p className="mt-3 text-sm text-slate-500">Aucune mesure disponible pour les types partagés.</p>}</article>)}</div> : <p className="rounded-xl border border-dashed border-slate-300 p-5 text-sm text-slate-600">Aucun patient correspondant ou aucun partage actif.</p>)}
        {tab==="mesures" && <>
          {selectedPatient && <section className="rounded-xl border border-emerald-200 bg-emerald-50 p-4 space-y-3">
            <div className="flex flex-wrap items-start justify-between gap-2"><div><h2 className="font-extrabold text-emerald-950">Dossier partagé · {patientLabel(selectedPatient)}</h2><p className="text-sm text-emerald-900">Évolution des valeurs numériques partagées, triées par date. Les graphiques décrivent les données reçues et ne constituent pas une interprétation médicale.</p></div><button type="button" className="btn btn-clair" onClick={() => setSelectedPatientId(null)}>Fermer le dossier</button></div>
            {trendTypes.length > 0 ? <>
              <label className="block text-sm font-semibold">Mesure à visualiser<select className="champ mt-1 w-full sm:max-w-sm" value={activeTrendType} onChange={event => setTrendType(event.target.value)}>{trendTypes.map(type => <option key={type} value={type}>{labels[type] ?? type}</option>)}</select></label>
              {trendPoints.length > 1 ? <div className="rounded-xl border border-emerald-100 bg-white p-3">
                <div className="flex flex-wrap justify-between gap-2 text-sm"><span>Minimum observé : <b>{trendMin}</b></span><span>Maximum observé : <b>{trendMax}</b></span><span>{trendPoints.length} dernières valeurs</span></div>
                <svg viewBox="0 0 600 180" role="img" aria-label={`Évolution des ${labels[activeTrendType] ?? activeTrendType} pour ${patientLabel(selectedPatient)}`} className="mt-3 h-44 w-full">
                  <line x1="24" y1="142" x2="576" y2="142" stroke="#cbd5e1" strokeWidth="1" />
                  <line x1="24" y1="30" x2="576" y2="30" stroke="#e2e8f0" strokeWidth="1" />
                  <polyline points={trendPolyline} fill="none" stroke="#0F6B3F" strokeWidth="3" strokeLinejoin="round" strokeLinecap="round" />
                  {trendCoordinates.map((point, index) => <circle key={trendPoints[index].id} cx={point.x} cy={point.y} r="4" fill="#0F6B3F"><title>{`${trendPoints[index].value_numeric} ${trendPoints[index].unit ?? ""} — ${dateLabel(trendPoints[index].measured_at)}`}</title></circle>)}
                </svg>
                <div className="flex justify-between gap-2 text-xs text-slate-500"><span>{dateLabel(trendPoints[0].measured_at)}</span><span>{dateLabel(trendPoints[trendPoints.length - 1].measured_at)}</span></div>
              </div> : <p className="rounded-lg bg-white p-3 text-sm text-slate-700">Il faut au moins deux mesures numériques partagées pour tracer une évolution. Une seule valeur ne permet pas de conclure à une tendance.</p>}
            </> : <p className="rounded-lg bg-white p-3 text-sm text-slate-700">Aucune mesure numérique partagée n’est disponible pour tracer une courbe. Les mesures textuelles restent consultables dans la liste.</p>}
          </section>}
          {filteredMeasurements.length ? <div className="space-y-3">{filteredMeasurements.map(row=><article key={row.id} className="rounded-xl border border-slate-200 p-4"><div className="flex flex-wrap items-start justify-between gap-2"><div><b>{labels[row.measurement_type] ?? row.measurement_type}</b><p className="text-sm text-slate-600">{patientLabel(row.user_id)} · {dateLabel(row.measured_at)}</p></div><span className="rounded-lg bg-slate-100 px-3 py-2 text-sm font-bold">{row.value_numeric !== null ? `${row.value_numeric}${row.unit ? " " + row.unit : ""}` : row.value_text || "Valeur non renseignée"}</span></div>{row.note && <p className="mt-3 text-sm text-slate-600">Note partagée : {row.note}</p>}<p className="mt-2 text-xs text-slate-500">Source enregistrée : {row.source}</p><button type="button" className="mt-3 text-sm font-bold underline" onClick={() => {setSelectedPatientId(row.user_id);setTrendType(row.measurement_type);}}>Afficher l’évolution de ce patient</button></article>)}</div> : <p className="rounded-xl border border-dashed border-slate-300 p-5 text-sm text-slate-600">Aucune mesure ne correspond aux filtres. Les mesures restent visibles seulement tant que le partage et le consentement sont actifs.</p>}
        </>}
        {tab==="alertes" && <div className="space-y-3"><p className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-950">Ces alertes signalent uniquement un écart par rapport à une plage choisie par le patient. Elles ne constituent ni un diagnostic ni un seuil médical défini par NAXA.</p>{alertError&&<p role="status" className="rounded-lg border border-amber-200 p-3 text-sm">{alertError}</p>}{filteredAlerts.length ? filteredAlerts.map(alert=><article key={alert.id} className="rounded-xl border border-slate-200 p-4"><div className="flex flex-wrap items-start justify-between gap-2"><div><b>{alert.alert_kind==="below_user_range"?"Sous la plage choisie par le patient":"Au-dessus de la plage choisie par le patient"}</b><p className="text-sm text-slate-600">{patientLabel(alert.user_id)} · {labels[alert.measurement_type]??alert.measurement_type}</p><p className="text-xs text-slate-500">{dateLabel(alert.created_at)}</p></div><span className="rounded-lg bg-slate-100 px-3 py-2 text-sm font-bold">{alert.observed_value}</span></div><p className="mt-2 text-xs text-slate-500">Alerte non traitée par le pharmacien : la modification du statut de lecture reste réservée au compte patient.</p></article>) : <p className="rounded-xl border border-dashed border-slate-300 p-5 text-sm text-slate-600">Aucune alerte partagée ne correspond aux filtres.</p>}</div>}
        {tab==="partages" && (shares.length ? <div className="space-y-2">{shares.map(share=><article key={share.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 p-3"><div><b>{patientLabel(share.owner_user_id)}</b><p className="text-sm text-slate-600">{labels[share.measurement_type] ?? share.measurement_type}</p><p className="text-xs text-slate-500">Partage accordé le {dateLabel(share.granted_at)}</p></div><span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-900">Actif</span></article>)}</div> : <p className="rounded-xl border border-dashed border-slate-300 p-5 text-sm text-slate-600">Aucun partage actif. Le patient conserve le contrôle de son consentement et peut révoquer le partage depuis son compte.</p>)}
      </>}
    </section>
    <p className="px-1 text-xs text-slate-500">Le module reste soumis à la vérification professionnelle et à l’autorisation expérimentale existante du suivi connecté. Les données se rafraîchissent via Realtime lorsque disponible et par vérification périodique toutes les 30 secondes. Les alertes affichées sont uniquement celles qui sont liées à des mesures partagées et restent soumises à la migration 192. Le suivi des prescriptions patient exige encore un consentement distinct et un raccordement dédié.</p>
  </PharmacienWorkspaceShell>;
}
