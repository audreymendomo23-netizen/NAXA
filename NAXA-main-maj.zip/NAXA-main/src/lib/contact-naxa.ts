export const NAXA_EMAIL = "naxa.home@gmail.com";
export const NAXA_WHATSAPP = "237681972237"; // 681 97 22 37, indicatif Cameroun
export const lienGmail = (nom: string) =>
  `mailto:${NAXA_EMAIL}?subject=${encodeURIComponent("Demande d'aide NAXA")}&body=${encodeURIComponent(`Bonjour l'équipe NAXA,\n\nJe suis ${nom || "un client NAXA"} et j'ai besoin d'aide :\n\n`)}`;
export const lienWhatsApp = (nom: string) =>
  `https://wa.me/${NAXA_WHATSAPP}?text=${encodeURIComponent(`Bonjour NAXA, je suis ${nom || "un client"} et j'ai besoin d'aide avec l'application.`)}`;
